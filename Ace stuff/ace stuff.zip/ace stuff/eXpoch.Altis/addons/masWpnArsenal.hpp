///////////////////////////////////////////////////////////////////////////////
	// Shemags
	///////////////////////////////////////////////////////////////////////////////
	class G_mas_wpn_gog								{ traderRank = 0; loadoutRank = 0; quality = 1; price = 10; };
	class G_mas_wpn_gog_d							{ traderRank = 0; loadoutRank = 0; quality = 1; price = 10; };
	class G_mas_wpn_gog_m							{ traderRank = 0; loadoutRank = 0; quality = 1; price = 10; };
	class G_mas_wpn_gog_md							{ traderRank = 0; loadoutRank = 0; quality = 1; price = 10; };
	class G_mas_wpn_gog_g							{ traderRank = 0; loadoutRank = 0; quality = 1; price = 10; };
	class G_mas_wpn_gog_gd							{ traderRank = 0; loadoutRank = 0; quality = 1; price = 10; };
	class G_mas_wpn_mask							{ traderRank = 0; loadoutRank = 0; quality = 1; price = 10; };
	class G_mas_wpn_mask_b							{ traderRank = 0; loadoutRank = 0; quality = 1; price = 10; };
	class G_mas_wpn_wrap							{ traderRank = 0; loadoutRank = 0; quality = 1; price = 10; };
	class G_mas_wpn_wrap_f							{ traderRank = 0; loadoutRank = 0; quality = 1; price = 10; };
	class G_mas_wpn_wrap_t							{ traderRank = 0; loadoutRank = 0; quality = 1; price = 10; };
	class G_mas_wpn_wrap_b							{ traderRank = 0; loadoutRank = 0; quality = 1; price = 10; };
	class G_mas_wpn_wrap_c							{ traderRank = 0; loadoutRank = 0; quality = 1; price = 10; };
	class G_mas_wpn_wrap_g							{ traderRank = 0; loadoutRank = 0; quality = 1; price = 10; };
	class G_mas_wpn_wrap_gog						{ traderRank = 0; loadoutRank = 0; quality = 1; price = 10; };
	class G_mas_wpn_wrap_gog_f						{ traderRank = 0; loadoutRank = 0; quality = 1; price = 10; };
	class G_mas_wpn_wrap_gog_t						{ traderRank = 0; loadoutRank = 0; quality = 1; price = 10; };
	class G_mas_wpn_wrap_gog_b						{ traderRank = 0; loadoutRank = 0; quality = 1; price = 10; };
	class G_mas_wpn_wrap_gog_c						{ traderRank = 0; loadoutRank = 0; quality = 1; price = 10; };
	class G_mas_wpn_wrap_gog_g						{ traderRank = 0; loadoutRank = 0; quality = 1; price = 10; };
	class G_mas_wpn_wrap_mask						{ traderRank = 0; loadoutRank = 0; quality = 1; price = 10; };
	class G_mas_wpn_wrap_mask_t						{ traderRank = 0; loadoutRank = 0; quality = 1; price = 10; };
	class G_mas_wpn_wrap_mask_f						{ traderRank = 0; loadoutRank = 0; quality = 1; price = 10; };
	class G_mas_wpn_wrap_mask_b						{ traderRank = 0; loadoutRank = 0; quality = 1; price = 10; };
	class G_mas_wpn_wrap_mask_c						{ traderRank = 0; loadoutRank = 0; quality = 1; price = 10; };
	class G_mas_wpn_wrap_mask_g						{ traderRank = 0; loadoutRank = 0; quality = 1; price = 10; };
	class G_mas_wpn_bala							{ traderRank = 0; loadoutRank = 0; quality = 1; price = 10; };
	class G_mas_wpn_bala_b							{ traderRank = 0; loadoutRank = 0; quality = 1; price = 10; };
	class G_mas_wpn_bala_t							{ traderRank = 0; loadoutRank = 0; quality = 1; price = 10; };
	class G_mas_wpn_bala_gog						{ traderRank = 0; loadoutRank = 0; quality = 1; price = 10; };
	class G_mas_wpn_bala_gog_b						{ traderRank = 0; loadoutRank = 0; quality = 1; price = 10; };
	class G_mas_wpn_bala_gog_t						{ traderRank = 0; loadoutRank = 0; quality = 1; price = 10; };
	class G_mas_wpn_bala_mask						{ traderRank = 0; loadoutRank = 0; quality = 1; price = 10; };
	class G_mas_wpn_bala_mask_b						{ traderRank = 0; loadoutRank = 0; quality = 1; price = 10; };
	class G_mas_wpn_bala_mask_t						{ traderRank = 0; loadoutRank = 0; quality = 1; price = 10; };
	class G_mas_wpn_shemag							{ traderRank = 0; loadoutRank = 1; quality = 1; price = 10; };
	class G_mas_wpn_shemag_r						{ traderRank = 0; loadoutRank = 1; quality = 1; price = 10; };
	class G_mas_wpn_shemag_w						{ traderRank = 0; loadoutRank = 1; quality = 1; price = 10; };
	class G_mas_wpn_shemag_gog						{ traderRank = 0; loadoutRank = 1; quality = 1; price = 10; };
	class G_mas_wpn_shemag_mask						{ traderRank = 0; loadoutRank = 1; quality = 1; price = 10; };
	class G_mas_wpn_gasmask							{ traderRank = 0; loadoutRank = 1; quality = 1; price = 10; };
	
	///////////////////////////////////////////////////////////////////////////////
	// Pointer Attachments
	///////////////////////////////////////////////////////////////////////////////
	class acc_mas_flash_gun 						{ traderRank = 0; loadoutRank = 1; quality = 1; price = 40; };
	class acc_mas_pointer_gun_IR 					{ traderRank = 0; loadoutRank = 1; quality = 1; price = 50; };
	class acc_mas_pointer_IR 						{ traderRank = 0; loadoutRank = 1; quality = 1; price = 50; };
	class acc_mas_pointer_IR_b 						{ traderRank = 0; loadoutRank = 1; quality = 1; price = 50; };
	class acc_mas_pointer_IR_top 					{ traderRank = 0; loadoutRank = 1; quality = 1; price = 50; };
	class acc_mas_pointer_IR_top_b 					{ traderRank = 0; loadoutRank = 1; quality = 1; price = 50; };
	class acc_mas_pointer_IR2 						{ traderRank = 0; loadoutRank = 1; quality = 1; price = 50; };
	class acc_mas_pointer_IR2_top 					{ traderRank = 0; loadoutRank = 1; quality = 1; price = 50; };
	class acc_mas_pointer_IR2c 						{ traderRank = 0; loadoutRank = 1; quality = 1; price = 50; };
	class acc_mas_pointer_IR2c_top					{ traderRank = 0; loadoutRank = 1; quality = 1; price = 50; };
	
	///////////////////////////////////////////////////////////////////////////////
	// Muzzle Attachments
	///////////////////////////////////////////////////////////////////////////////
	class muzzle_mas_snds_L 						{ traderRank = 5; loadoutRank = 4; quality = 1; price = 40; };
	class muzzle_mas_snds_LM 						{ traderRank = 5; loadoutRank = 4; quality = 1; price = 40; };
	class muzzle_mas_snds_C 						{ traderRank = 5; loadoutRank = 4; quality = 2; price = 50; };
	class muzzle_mas_snds_MP5SD6 					{ traderRank = 5; loadoutRank = 4; quality = 2; price = 50; };
	class muzzle_mas_snds_M 						{ traderRank = 5; loadoutRank = 4; quality = 2; price = 50; };
	class muzzle_mas_snds_Mc 						{ traderRank = 5; loadoutRank = 4; quality = 2; price = 50; };
	class muzzle_mas_snds_MP7 						{ traderRank = 5; loadoutRank = 4; quality = 2; price = 50; };
	class muzzle_mas_snds_AK 						{ traderRank = 5; loadoutRank = 4; quality = 2; price = 50; };
	class muzzle_mas_snds_SM 						{ traderRank = 5; loadoutRank = 4; quality = 2; price = 100; };
	class muzzle_mas_snds_SMc 						{ traderRank = 5; loadoutRank = 4; quality = 2; price = 100; };
	class muzzle_mas_snds_SH 						{ traderRank = 5; loadoutRank = 4; quality = 2; price = 100; };
	class muzzle_mas_snds_SHc 						{ traderRank = 5; loadoutRank = 4; quality = 2; price = 100; };
	class muzzle_mas_snds_SV 						{ traderRank = 5; loadoutRank = 4; quality = 2; price = 200; };
	class muzzle_mas_snds_SVc 						{ traderRank = 5; loadoutRank = 4; quality = 2; price = 200; };
	class muzzle_mas_snds_SVD 						{ traderRank = 5; loadoutRank = 4; quality = 2; price = 100; };
	class muzzle_mas_snds_KSVK 						{ traderRank = 5; loadoutRank = 4; quality = 2; price = 200; };	
	
	///////////////////////////////////////////////////////////////////////////////
	// Optic Attachments
	///////////////////////////////////////////////////////////////////////////////
	class optic_mas_DMS								{ traderRank = 0; loadoutRank = 4; quality = 1; price = 150; };
	class optic_mas_DMS_c							{ traderRank = 0; loadoutRank = 4; quality = 1; price = 150; };
	class optic_mas_Holosight_blk					{ traderRank = 0; loadoutRank = 4; quality = 1; price = 50; };
	class optic_mas_Holosight_camo					{ traderRank = 0; loadoutRank = 4; quality = 1; price = 50; };
	class optic_mas_Arco_blk						{ traderRank = 0; loadoutRank = 4; quality = 1; price = 100; };
	class optic_mas_Arco_camo						{ traderRank = 0; loadoutRank = 4; quality = 1; price = 100; };
	class optic_mas_Hamr_camo						{ traderRank = 0; loadoutRank = 4; quality = 1; price = 100; };
	class optic_mas_Aco_camo						{ traderRank = 0; loadoutRank = 4; quality = 1; price = 50; };
	class optic_mas_ACO_grn_camo					{ traderRank = 0; loadoutRank = 4; quality = 1; price = 50; };
	class optic_mas_MRCO_camo						{ traderRank = 0; loadoutRank = 4; quality = 1; price = 100; };
	class optic_mas_zeiss							{ traderRank = 0; loadoutRank = 4; quality = 3; price = 300; };
	class optic_mas_zeiss_c							{ traderRank = 0; loadoutRank = 4; quality = 3; price = 300; };
	class optic_mas_zeiss_eo						{ traderRank = 0; loadoutRank = 4; quality = 3; price = 400; };
	class optic_mas_zeiss_eo_c						{ traderRank = 0; loadoutRank = 4; quality = 3; price = 400; };
	class optic_mas_acog							{ traderRank = 0; loadoutRank = 4; quality = 3; price = 200; };
	class optic_mas_acog_c							{ traderRank = 0; loadoutRank = 4; quality = 3; price = 200; };
	class optic_mas_acog_eo							{ traderRank = 0; loadoutRank = 4; quality = 3; price = 200; };
	class optic_mas_acog_eo_c						{ traderRank = 0; loadoutRank = 4; quality = 3; price = 200; };
	class optic_mas_acog_rd							{ traderRank = 0; loadoutRank = 4; quality = 3; price = 200; };
	class optic_mas_acog_rd_c						{ traderRank = 0; loadoutRank = 4; quality = 3; price = 200; };
	class optic_mas_handle							{ traderRank = 0; loadoutRank = 4; quality = 2; price = 100; };
	class optic_mas_aim								{ traderRank = 0; loadoutRank = 4; quality = 2; price = 150; };
	class optic_mas_aim_c							{ traderRank = 0; loadoutRank = 4; quality = 2; price = 150; };
	class optic_mas_PSO								{ traderRank = 0; loadoutRank = 4; quality = 3; price = 300; };
	class optic_mas_PSO_c							{ traderRank = 0; loadoutRank = 4; quality = 3; price = 300; };
	class optic_mas_PSO_eo							{ traderRank = 0; loadoutRank = 4; quality = 3; price = 300; };
	class optic_mas_PSO_eo_c						{ traderRank = 0; loadoutRank = 4; quality = 3; price = 300; };
	class optic_mas_PSO_nv							{ traderRank = 0; loadoutRank = 4; quality = 2; price = 500; };
	class optic_mas_PSO_nv_c						{ traderRank = 0; loadoutRank = 4; quality = 2; price = 500; };
	class optic_mas_PSO_nv_eo						{ traderRank = 0; loadoutRank = 4; quality = 2; price = 500; };
	class optic_mas_PSO_nv_eo_c						{ traderRank = 0; loadoutRank = 4; quality = 2; price = 500; };
	class optic_mas_PSO_day							{ traderRank = 0; loadoutRank = 4; quality = 3; price = 300; };
	class optic_mas_PSO_nv_day						{ traderRank = 0; loadoutRank = 4; quality = 2; price = 500; };
	class optic_mas_term							{ traderRank = 0; loadoutRank = 4; quality = 3; price = 600; };
	class optic_mas_MRD								{ traderRank = 0; loadoutRank = 4; quality = 1; price = 50; };
	class optic_mas_LRPS							{ traderRank = 0; loadoutRank = 4; quality = 3; price = 300; };
	class optic_mas_kobra							{ traderRank = 0; loadoutRank = 4; quality = 2; price = 250; };
	class optic_mas_kobra_c							{ traderRank = 0; loadoutRank = 4; quality = 2; price = 250; };
	class optic_mas_nspu							{ traderRank = 0; loadoutRank = 4; quality = 2; price = 250; };
	class optic_mas_goshawk							{ traderRank = 0; loadoutRank = 4; quality = 2; price = 150; };
	class optic_mas_PSO_kv							{ traderRank = 0; loadoutRank = 4; quality = 2; price = 250; };
	class optic_mas_PSO_kv_c						{ traderRank = 0; loadoutRank = 4; quality = 2; price = 250; };	
	
	///////////////////////////////////////////////////////////////////////////////
	// Navigation
	///////////////////////////////////////////////////////////////////////////////
	class NVGoggles_mas_h							{ traderRank = 5; loadoutRank = 4; quality = 2; price = 250; };
	//class Rangefinder_mas_h							{ traderRank = 0; loadoutRank = 4; quality = 2; price = 250; };
	//class Laserdesignator_mas_h						{ traderRank = 0; loadoutRank = 4; quality = 3; price = 950; };	
	
	///////////////////////////////////////////////////////////////////////////////
	// Backpacks
	///////////////////////////////////////////////////////////////////////////////
	class B_mas_m_Bergen_us							{ traderRank = 0; loadoutRank = 4; quality = 2; price = 200; };
	class B_mas_m_Bergen_us_g						{ traderRank = 0; loadoutRank = 4; quality = 2; price = 200; };
	class B_mas_m_Bergen_us_m						{ traderRank = 0; loadoutRank = 4; quality = 2; price = 200; };
	class B_mas_m_Bergen_us_b						{ traderRank = 0; loadoutRank = 4; quality = 2; price = 200; };
	class B_mas_m_Bergen_us_w						{ traderRank = 0; loadoutRank = 4; quality = 2; price = 200; };
	class B_mas_m_Bergen_acr						{ traderRank = 0; loadoutRank = 4; quality = 2; price = 200; };
	class B_mas_m_Bergen_acr_c						{ traderRank = 0; loadoutRank = 4; quality = 2; price = 200; };
	class B_mas_m_Bergen_acr_g						{ traderRank = 0; loadoutRank = 4; quality = 2; price = 200; };
	class B_mas_m_Bergen_acr_w						{ traderRank = 0; loadoutRank = 4; quality = 2; price = 200; };
	class B_mas_m_Bergen_rpg						{ traderRank = 0; loadoutRank = 4; quality = 2; price = 200; };
	class B_mas_m_Bergen_rpg_b						{ traderRank = 0; loadoutRank = 4; quality = 2; price = 200; };
	class B_mas_m_Bergen_al							{ traderRank = 0; loadoutRank = 4; quality = 2; price = 200; };
	class B_mas_AssaultPack_mul						{ traderRank = 0; loadoutRank = 4; quality = 1; price = 90; };
	class B_mas_Kitbag_mul							{ traderRank = 0; loadoutRank = 4; quality = 3; price = 200; };
	class B_mas_Bergen_mul							{ traderRank = 0; loadoutRank = 4; quality = 2; price = 200; };
	class B_mas_AssaultPack_des						{ traderRank = 0; loadoutRank = 4; quality = 1; price = 90; };
	class B_mas_Kitbag_des							{ traderRank = 0; loadoutRank = 4; quality = 3; price = 200; };
	class B_mas_Bergen_des							{ traderRank = 0; loadoutRank = 4; quality = 2; price = 200; };
	class B_mas_AssaultPack_black					{ traderRank = 0; loadoutRank = 4; quality = 1; price = 90; };
	class B_mas_Kitbag_black						{ traderRank = 0; loadoutRank = 4; quality = 3; price = 200; };
	class B_mas_Bergen_black						{ traderRank = 0; loadoutRank = 4; quality = 2; price = 200; };
	class B_mas_AssaultPack_wint					{ traderRank = 0; loadoutRank = 4; quality = 1; price = 90; };
	class B_mas_Kitbag_wint							{ traderRank = 0; loadoutRank = 4; quality = 3; price = 200; };
	class B_mas_Bergen_wint							{ traderRank = 0; loadoutRank = 4; quality = 2; price = 200; };
	class B_mas_AssaultPack_rng						{ traderRank = 0; loadoutRank = 4; quality = 1; price = 90; };
	class B_mas_Kitbag_rng							{ traderRank = 0; loadoutRank = 4; quality = 3; price = 200; };
	class B_mas_Bergen_rng							{ traderRank = 0; loadoutRank = 4; quality = 2; price = 200; };
	class O_mas_Bergen_flo							{ traderRank = 0; loadoutRank = 4; quality = 2; price = 200; };
	class O_mas_Bergen_blk							{ traderRank = 0; loadoutRank = 4; quality = 2; price = 200; };
	class O_mas_Bergen_rtan							{ traderRank = 0; loadoutRank = 4; quality = 2; price = 200; };	
	
	///////////////////////////////////////////////////////////////////////////////
	// Ammunition
	///////////////////////////////////////////////////////////////////////////////
	class 30Rnd_mas_556x45_Stanag					{ traderRank = 0; loadoutRank = 100; quality = 1; price = 20; };
	class 30Rnd_mas_556x45_T_Stanag					{ traderRank = 0; loadoutRank = 100; quality = 2; price = 20; };
	class 200Rnd_mas_556x45_Stanag					{ traderRank = 0; loadoutRank = 100; quality = 1; price = 30; };
	class 200Rnd_mas_556x45_T_Stanag				{ traderRank = 0; loadoutRank = 100; quality = 2; price = 30; };
	class 100Rnd_mas_762x51_Stanag					{ traderRank = 0; loadoutRank = 100; quality = 1; price = 30; };
	class 100Rnd_mas_762x51_T_Stanag				{ traderRank = 0; loadoutRank = 100; quality = 2; price = 40; };
	class 100Rnd_mas_762x54_mag						{ traderRank = 0; loadoutRank = 100; quality = 1; price = 30; };
	class 100Rnd_mas_762x54_T_mag					{ traderRank = 0; loadoutRank = 100; quality = 2; price = 40; };
	class 100Rnd_mas_762x39_mag						{ traderRank = 0; loadoutRank = 100; quality = 1; price = 30; };
	class 100Rnd_mas_762x39_T_mag					{ traderRank = 0; loadoutRank = 100; quality = 2; price = 40; };
	class 30Rnd_mas_545x39_mag						{ traderRank = 0; loadoutRank = 100; quality = 1; price = 20; };
	class 30Rnd_mas_545x39_T_mag					{ traderRank = 0; loadoutRank = 100; quality = 2; price = 20; };
	class 100Rnd_mas_545x39_mag						{ traderRank = 0; loadoutRank = 100; quality = 1; price = 25; };
	class 100Rnd_mas_545x39_T_mag					{ traderRank = 0; loadoutRank = 100; quality = 2; price = 25; };
	class 20Rnd_mas_762x51_Stanag					{ traderRank = 0; loadoutRank = 100; quality = 1; price = 20; };
	class 20Rnd_mas_762x51_T_Stanag					{ traderRank = 0; loadoutRank = 100; quality = 2; price = 20; };
	class 5Rnd_mas_762x51_Stanag					{ traderRank = 0; loadoutRank = 100; quality = 1; price = 20; };
	class 5Rnd_mas_762x51_T_Stanag					{ traderRank = 0; loadoutRank = 100; quality = 2; price = 20; };
	class 10Rnd_mas_338_Stanag						{ traderRank = 0; loadoutRank = 100; quality = 1; price = 30; };
	class 10Rnd_mas_338_T_Stanag					{ traderRank = 0; loadoutRank = 100; quality = 2; price = 30; };
	class 30Rnd_mas_762x39_mag						{ traderRank = 0; loadoutRank = 100; quality = 1; price = 20; };
	class 30Rnd_mas_762x39_T_mag					{ traderRank = 0; loadoutRank = 100; quality = 2; price = 20; };
	class 10Rnd_mas_762x54_mag						{ traderRank = 0; loadoutRank = 100; quality = 1; price = 25; };
	class 10Rnd_mas_762x54_T_mag					{ traderRank = 0; loadoutRank = 100; quality = 2; price = 25; };
	class 5Rnd_mas_127x99_Stanag					{ traderRank = 0; loadoutRank = 100; quality = 1; price = 50; };
	class 5Rnd_mas_127x99_T_Stanag					{ traderRank = 0; loadoutRank = 100; quality = 2; price = 50; };
	class 5Rnd_mas_127x108_mag						{ traderRank = 0; loadoutRank = 100; quality = 1; price = 40; };
	class 5Rnd_mas_127x108_T_mag					{ traderRank = 0; loadoutRank = 100; quality = 2; price = 40; };
	class 30Rnd_mas_9x21_Stanag						{ traderRank = 0; loadoutRank = 100; quality = 1; price = 10; };
	class 30Rnd_mas_9x21d_Stanag					{ traderRank = 0; loadoutRank = 100; quality = 1; price = 10; };
	class 12Rnd_mas_45acp_Mag						{ traderRank = 0; loadoutRank = 100; quality = 1; price = 7; };
	class 10Rnd_mas_45acp_Mag						{ traderRank = 0; loadoutRank = 100; quality = 1; price = 7; };
	class 8Rnd_mas_45acp_Mag						{ traderRank = 0; loadoutRank = 100; quality = 1; price = 6; };
	class 15Rnd_mas_9x21_Mag						{ traderRank = 0; loadoutRank = 100; quality = 1; price = 9; };
	class 17Rnd_mas_9x21_Mag						{ traderRank = 0; loadoutRank = 100; quality = 1; price = 9; };
	class 13Rnd_mas_9x21_Mag						{ traderRank = 0; loadoutRank = 100; quality = 1; price = 9; };
	class 8Rnd_mas_9x18_mag							{ traderRank = 0; loadoutRank = 100; quality = 1; price = 7; };
	class 7Rnd_mas_12Gauge_Slug						{ traderRank = 0; loadoutRank = 100; quality = 1; price = 10; };
	class 7Rnd_mas_12Gauge_Pellets					{ traderRank = 0; loadoutRank = 100; quality = 1; price = 10; };
	class 10Rnd_mas_12Gauge_Slug					{ traderRank = 0; loadoutRank = 100; quality = 1; price = 10; };
	class 10Rnd_mas_12Gauge_Pellets					{ traderRank = 0; loadoutRank = 100; quality = 1; price = 10; };
	class 64Rnd_mas_9x18_mag						{ traderRank = 0; loadoutRank = 100; quality = 1; price = 20; };
	class 20Rnd_mas_765x17_Mag						{ traderRank = 0; loadoutRank = 100; quality = 1; price = 20; };
	class 25Rnd_mas_9x19_Mag						{ traderRank = 0; loadoutRank = 100; quality = 1; price = 20; };
	class 40Rnd_mas_46x30_Mag						{ traderRank = 0; loadoutRank = 100; quality = 1; price = 30; };
	class 20Rnd_mas_12Gauge_Slug					{ traderRank = 0; loadoutRank = 100; quality = 1; price = 20; };
	class 20Rnd_mas_12Gauge_Pellets					{ traderRank = 0; loadoutRank = 100; quality = 1; price = 20; };
	class 150Rnd_mas_556x45_Stanag					{ traderRank = 0; loadoutRank = 100; quality = 1; price = 30; };
	class 150Rnd_mas_556x45_T_Stanag				{ traderRank = 0; loadoutRank = 100; quality = 2; price = 30; };
	class 30Rnd_mas_9x39_mag						{ traderRank = 0; loadoutRank = 100; quality = 2; price = 40; };
	class 20Rnd_mas_9x39_mag						{ traderRank = 0; loadoutRank = 100; quality = 2; price = 30; };	
	
	///////////////////////////////////////////////////////////////////////////////
	// Pistols
	///////////////////////////////////////////////////////////////////////////////
	class hgun_mas_mp7p_F 							{ traderRank = 0; loadoutRank = 4; quality = 2; price = 300; };
	class hgun_mas_uzi_F 							{ traderRank = 0; loadoutRank = 4; quality = 2; price = 300; };
	class hgun_mas_sa61_F 							{ traderRank = 0; loadoutRank = 4; quality = 2; price = 300; };
	class hgun_mas_m9_F 							{ traderRank = 0; loadoutRank = 4; quality = 1; price = 50; };
	class hgun_mas_bhp_F 							{ traderRank = 0; loadoutRank = 4; quality = 1; price = 50; };
	class hgun_mas_glock_F 							{ traderRank = 0; loadoutRank = 4; quality = 2; price = 50; };
	class hgun_mas_p226_F 							{ traderRank = 0; loadoutRank = 4; quality = 2; price = 50; };
	class hgun_mas_acp_F 							{ traderRank = 0; loadoutRank = 4; quality = 2; price = 80; };
	class hgun_mas_usp_F 							{ traderRank = 0; loadoutRank = 4; quality = 2; price = 80; };
	class hgun_mas_usp_l_F 							{ traderRank = 0; loadoutRank = 4; quality = 2; price = 80; };
	class hgun_mas_glocksf_F 						{ traderRank = 0; loadoutRank = 4; quality = 2; price = 80; };
	class hgun_mas_grach_F 							{ traderRank = 0; loadoutRank = 4; quality = 1; price = 65; };
	class hgun_mas_mak_F 							{ traderRank = 0; loadoutRank = 4; quality = 1; price = 60; };
	class hgun_mas_mak_F_sd 						{ traderRank = 0; loadoutRank = 4; quality = 1; price = 60; };	
	
	///////////////////////////////////////////////////////////////////////////////
	// Sub Machine Guns
	///////////////////////////////////////////////////////////////////////////////
	class arifle_mas_mp40 							{ traderRank = 0; loadoutRank = 4; quality = 1; price = 250; };
	class arifle_mas_mp40_o 						{ traderRank = 0; loadoutRank = 4; quality = 1; price = 250; };
	class arifle_mas_sten 							{ traderRank = 0; loadoutRank = 4; quality = 1; price = 250; };
	class arifle_mas_m1014 							{ traderRank = 0; loadoutRank = 4; quality = 2; price = 300; };
	class arifle_mas_aa12 							{ traderRank = 0; loadoutRank = 4; quality = 2; price = 400; };
	class arifle_mas_m79 							{ traderRank = 0; loadoutRank = 4; quality = 2; price = 400; };
	class arifle_mas_mp5 							{ traderRank = 0; loadoutRank = 4; quality = 2; price = 400; };
	class arifle_mas_mp5_v 							{ traderRank = 0; loadoutRank = 4; quality = 2; price = 400; };
	class arifle_mas_mp5_d 							{ traderRank = 0; loadoutRank = 4; quality = 2; price = 500; };
	class arifle_mas_mp5sd_ds 						{ traderRank = 0; loadoutRank = 4; quality = 2; price = 600; };
	class hgun_mas_mp7_F 							{ traderRank = 0; loadoutRank = 4; quality = 2; price = 300; };
	class arifle_mas_bizon 							{ traderRank = 0; loadoutRank = 4; quality = 1; price = 450; };
	class arifle_mas_saiga 							{ traderRank = 0; loadoutRank = 4; quality = 2; price = 300; };	
	
	///////////////////////////////////////////////////////////////////////////////
	// Light Machine Guns
	///////////////////////////////////////////////////////////////////////////////
	class arifle_mas_m27							{ traderRank = 0; loadoutRank = 4; quality = 2; price = 550; };
	class arifle_mas_m27m							{ traderRank = 0; loadoutRank = 4; quality = 2; price = 550; };
	class arifle_mas_m27_v							{ traderRank = 0; loadoutRank = 4; quality = 2; price = 550; };
	class arifle_mas_m27m_v							{ traderRank = 0; loadoutRank = 4; quality = 2; price = 550; };
	class arifle_mas_m27_d							{ traderRank = 0; loadoutRank = 4; quality = 2; price = 550; };
	class arifle_mas_m27m_d							{ traderRank = 0; loadoutRank = 4; quality = 2; price = 550; };
	class LMG_mas_Mk200_F							{ traderRank = 0; loadoutRank = 4; quality = 3; price = 600; };
	class LMG_mas_M249_F							{ traderRank = 0; loadoutRank = 4; quality = 3; price = 800; };
	class LMG_mas_M249_F_v							{ traderRank = 0; loadoutRank = 4; quality = 3; price = 800; };
	class LMG_mas_M249_F_d							{ traderRank = 0; loadoutRank = 4; quality = 3; price = 800; };
	class LMG_mas_M249a_F							{ traderRank = 0; loadoutRank = 4; quality = 3; price = 800; };
	class LMG_mas_Mk48_F							{ traderRank = 0; loadoutRank = 4; quality = 3; price = 1200; };
	class LMG_mas_Mk48_F_v							{ traderRank = 0; loadoutRank = 4; quality = 3; price = 1200; };
	class LMG_mas_Mk48_F_d							{ traderRank = 0; loadoutRank = 4; quality = 3; price = 1200; };
	class LMG_mas_M240_F							{ traderRank = 0; loadoutRank = 4; quality = 3; price = 1200; };
	class LMG_mas_mg3_F								{ traderRank = 0; loadoutRank = 4; quality = 3; price = 1200; };
	class LMG_mas_M60_F								{ traderRank = 0; loadoutRank = 4; quality = 3; price = 1200; };
	class LMG_mas_m72_F								{ traderRank = 0; loadoutRank = 4; quality = 2; price = 600; };
	class LMG_mas_rpk_F								{ traderRank = 0; loadoutRank = 4; quality = 2; price = 600; };
	class LMG_mas_pkm_F								{ traderRank = 0; loadoutRank = 4; quality = 3; price = 1200; };
	class LMG_mas_pech_F							{ traderRank = 0; loadoutRank = 4; quality = 3; price = 1200; };	
	
	///////////////////////////////////////////////////////////////////////////////
	// Assault Rifles
	///////////////////////////////////////////////////////////////////////////////
	class arifle_mas_hk416							{ traderRank = 0; loadoutRank = 4; quality = 1; price = 350; };
	class arifle_mas_hk416_gl						{ traderRank = 0; loadoutRank = 4; quality = 2; price = 450; };
	class arifle_mas_hk416_m203						{ traderRank = 0; loadoutRank = 4; quality = 2; price = 450; };
	class arifle_mas_hk416_v						{ traderRank = 0; loadoutRank = 4; quality = 1; price = 350; };
	class arifle_mas_hk416_gl_v						{ traderRank = 0; loadoutRank = 4; quality = 2; price = 450; };
	class arifle_mas_hk416_m203_v					{ traderRank = 0; loadoutRank = 4; quality = 2; price = 450; };
	class arifle_mas_hk416_d						{ traderRank = 0; loadoutRank = 4; quality = 1; price = 350; };
	class arifle_mas_hk416_gl_d						{ traderRank = 0; loadoutRank = 4; quality = 2; price = 450; };
	class arifle_mas_hk416_m203_d					{ traderRank = 0; loadoutRank = 4; quality = 2; price = 450; };
	class arifle_mas_hk416c							{ traderRank = 0; loadoutRank = 4; quality = 1; price = 300; };
	class arifle_mas_hk416_m203c					{ traderRank = 0; loadoutRank = 4; quality = 2; price = 400; };
	class arifle_mas_hk416c_v						{ traderRank = 0; loadoutRank = 4; quality = 1; price = 300; };
	class arifle_mas_hk416_m203c_v					{ traderRank = 0; loadoutRank = 4; quality = 2; price = 400; };
	class arifle_mas_hk416c_d						{ traderRank = 0; loadoutRank = 4; quality = 1; price = 300; };
	class arifle_mas_hk416_m203c_d					{ traderRank = 0; loadoutRank = 4; quality = 2; price = 400; };
	class arifle_mas_m4								{ traderRank = 0; loadoutRank = 4; quality = 1; price = 350; };
	class arifle_mas_m4_gl							{ traderRank = 0; loadoutRank = 4; quality = 2; price = 450; };
	class arifle_mas_m4_m203						{ traderRank = 0; loadoutRank = 4; quality = 2; price = 450; };
	class arifle_mas_m4_v							{ traderRank = 0; loadoutRank = 4; quality = 1; price = 350; };
	class arifle_mas_m4_gl_v						{ traderRank = 0; loadoutRank = 4; quality = 2; price = 450; };
	class arifle_mas_m4_m203_v						{ traderRank = 0; loadoutRank = 4; quality = 2; price = 450; };
	class arifle_mas_m4_d							{ traderRank = 0; loadoutRank = 4; quality = 1; price = 350; };
	class arifle_mas_m4_gl_d						{ traderRank = 0; loadoutRank = 4; quality = 2; price = 450; };
	class arifle_mas_m4_m203_d						{ traderRank = 0; loadoutRank = 4; quality = 2; price = 450; };
	class arifle_mas_m4vlt							{ traderRank = 0; loadoutRank = 4; quality = 1; price = 400; };
	class arifle_mas_m4c							{ traderRank = 0; loadoutRank = 4; quality = 1; price = 300; };
	class arifle_mas_m4_m203c						{ traderRank = 0; loadoutRank = 4; quality = 2; price = 400; };
	class arifle_mas_m4c_v							{ traderRank = 0; loadoutRank = 4; quality = 1; price = 300; };
	class arifle_mas_m4_m203c_v						{ traderRank = 0; loadoutRank = 4; quality = 2; price = 400; };
	class arifle_mas_m4c_d							{ traderRank = 0; loadoutRank = 4; quality = 1; price = 300; };
	class arifle_mas_m4_m203c_d						{ traderRank = 0; loadoutRank = 4; quality = 2; price = 400; };
	class arifle_mas_m16							{ traderRank = 0; loadoutRank = 4; quality = 2; price = 500; };
	class arifle_mas_m16_gl							{ traderRank = 0; loadoutRank = 4; quality = 2; price = 600; };
	class arifle_mas_l119							{ traderRank = 0; loadoutRank = 4; quality = 1; price = 350; };
	class arifle_mas_l119c							{ traderRank = 0; loadoutRank = 4; quality = 1; price = 300; };
	class arifle_mas_l119_gl						{ traderRank = 0; loadoutRank = 4; quality = 2; price = 450; };
	class arifle_mas_l119_m203						{ traderRank = 0; loadoutRank = 4; quality = 2; price = 450; };
	class arifle_mas_l119_v							{ traderRank = 0; loadoutRank = 4; quality = 1; price = 350; };
	class arifle_mas_l119c_v						{ traderRank = 0; loadoutRank = 4; quality = 1; price = 300; };
	class arifle_mas_l119_gl_v						{ traderRank = 0; loadoutRank = 4; quality = 2; price = 450; };
	class arifle_mas_l119_m203_v					{ traderRank = 0; loadoutRank = 4; quality = 2; price = 450; };
	class arifle_mas_l119_d							{ traderRank = 0; loadoutRank = 4; quality = 1; price = 350; };
	class arifle_mas_l119c_d						{ traderRank = 0; loadoutRank = 4; quality = 1; price = 300; };
	class arifle_mas_l119_gl_d						{ traderRank = 0; loadoutRank = 4; quality = 2; price = 450; };
	class arifle_mas_l119_m203_d					{ traderRank = 0; loadoutRank = 4; quality = 2; price = 450; };
	class arifle_mas_g36c							{ traderRank = 0; loadoutRank = 4; quality = 1; price = 400; };
	class arifle_mas_mk16							{ traderRank = 0; loadoutRank = 4; quality = 1; price = 350; };
	class arifle_mas_mk16_gl						{ traderRank = 0; loadoutRank = 4; quality = 2; price = 450; };
	class arifle_mas_mk16_l							{ traderRank = 0; loadoutRank = 4; quality = 1; price = 400; };
	class arifle_mas_mk16_l_gl						{ traderRank = 0; loadoutRank = 4; quality = 2; price = 450; };
	class arifle_mas_mk17							{ traderRank = 0; loadoutRank = 4; quality = 1; price = 450; };
	class arifle_mas_mk17_gl						{ traderRank = 0; loadoutRank = 4; quality = 2; price = 550; };
	class arifle_mas_arx							{ traderRank = 0; loadoutRank = 4; quality = 1; price = 350; };
	class arifle_mas_arx_gl							{ traderRank = 0; loadoutRank = 4; quality = 2; price = 450; };
	class arifle_mas_arx_l							{ traderRank = 0; loadoutRank = 4; quality = 1; price = 400; };
	class arifle_mas_arx_l_gl						{ traderRank = 0; loadoutRank = 4; quality = 2; price = 450; };
	class arifle_mas_g3								{ traderRank = 0; loadoutRank = 4; quality = 1; price = 500; };
	class arifle_mas_g3_m203						{ traderRank = 0; loadoutRank = 4; quality = 2; price = 600; };
	class arifle_mas_g3s							{ traderRank = 0; loadoutRank = 4; quality = 1; price = 500; };
	class arifle_mas_g3s_m203						{ traderRank = 0; loadoutRank = 4; quality = 2; price = 600; };
	class arifle_mas_fal							{ traderRank = 0; loadoutRank = 4; quality = 1; price = 500; };
	class arifle_mas_fal_m203						{ traderRank = 0; loadoutRank = 4; quality = 2; price = 600; };
	class arifle_mas_ak_74m							{ traderRank = 0; loadoutRank = 4; quality = 1; price = 450; };
	class arifle_mas_ak_74m_gl						{ traderRank = 0; loadoutRank = 4; quality = 2; price = 550; };
	class arifle_mas_ak_74m_c						{ traderRank = 0; loadoutRank = 4; quality = 2; price = 400; };
	class arifle_mas_ak_74m_gl_c					{ traderRank = 0; loadoutRank = 4; quality = 2; price = 500; };
	class arifle_mas_aks74							{ traderRank = 0; loadoutRank = 4; quality = 1; price = 450; };
	class arifle_mas_aks74_gl						{ traderRank = 0; loadoutRank = 4; quality = 2; price = 550; };
	class arifle_mas_ak74							{ traderRank = 0; loadoutRank = 4; quality = 2; price = 400; };
	class arifle_mas_ak74_gl						{ traderRank = 0; loadoutRank = 4; quality = 2; price = 500; };
	class arifle_mas_ak_74m_sf						{ traderRank = 0; loadoutRank = 4; quality = 1; price = 450; };
	class arifle_mas_ak_74m_sf_gl					{ traderRank = 0; loadoutRank = 4; quality = 2; price = 550; };
	class arifle_mas_ak_74m_sf_c					{ traderRank = 0; loadoutRank = 4; quality = 1; price = 400; };
	class arifle_mas_ak_74m_sf_gl_c					{ traderRank = 0; loadoutRank = 4; quality = 2; price = 500; };
	class arifle_mas_aks_74_sf						{ traderRank = 0; loadoutRank = 4; quality = 1; price = 450; };
	class arifle_mas_aks_74_sf_gl					{ traderRank = 0; loadoutRank = 4; quality = 2; price = 550; };
	class arifle_mas_ak12_sf						{ traderRank = 0; loadoutRank = 4; quality = 1; price = 350; };
	class arifle_mas_ak12_sf_gl						{ traderRank = 0; loadoutRank = 4; quality = 2; price = 450; };
	class arifle_mas_akms							{ traderRank = 0; loadoutRank = 4; quality = 2; price = 300; };
	class arifle_mas_akms_gl						{ traderRank = 0; loadoutRank = 4; quality = 2; price = 400; };
	class arifle_mas_akms_c							{ traderRank = 0; loadoutRank = 4; quality = 2; price = 300; };
	class arifle_mas_akms_gl_c						{ traderRank = 0; loadoutRank = 4; quality = 2; price = 400; };
	class arifle_mas_akm							{ traderRank = 0; loadoutRank = 4; quality = 2; price = 300; };
	class arifle_mas_akm_gl							{ traderRank = 0; loadoutRank = 4; quality = 2; price = 400; };
	class arifle_mas_m70							{ traderRank = 0; loadoutRank = 4; quality = 1; price = 450; };
	class arifle_mas_m70_gl							{ traderRank = 0; loadoutRank = 4; quality = 2; price = 550; };
	class arifle_mas_m70ab							{ traderRank = 0; loadoutRank = 4; quality = 1; price = 450; };
	class arifle_mas_m70ab_gl						{ traderRank = 0; loadoutRank = 4; quality = 2; price = 550; };
	class arifle_mas_asval							{ traderRank = 0; loadoutRank = 4; quality = 2; price = 650; };
	class arifle_mas_asval_ds						{ traderRank = 0; loadoutRank = 4; quality = 2; price = 650; };
	class arifle_mas_aks74u							{ traderRank = 0; loadoutRank = 4; quality = 2; price = 300; };
	class arifle_mas_aks74u_c						{ traderRank = 0; loadoutRank = 4; quality = 2; price = 350; };

	///////////////////////////////////////////////////////////////////////////////
	// Sniper Rifles
	///////////////////////////////////////////////////////////////////////////////
	class arifle_mas_hk417c 						{ traderRank = 0; loadoutRank = 4; quality = 2; price = 650; };
	class arifle_mas_hk417_m203c					{ traderRank = 0; loadoutRank = 4; quality = 3; price = 750; };
	class arifle_mas_hk417c_v						{ traderRank = 0; loadoutRank = 4; quality = 2; price = 650; };
	class arifle_mas_hk417_m203c_v					{ traderRank = 0; loadoutRank = 4; quality = 3; price = 750; };
	class arifle_mas_hk417c_d						{ traderRank = 0; loadoutRank = 4; quality = 2; price = 650; };
	class arifle_mas_hk417_m203c_d					{ traderRank = 0; loadoutRank = 4; quality = 3; price = 750; };
	class arifle_mas_m14							{ traderRank = 0; loadoutRank = 4; quality = 3; price = 750; };
	class arifle_mas_lee							{ traderRank = 0; loadoutRank = 4; quality = 3; price = 750; };
	class srifle_mas_hk417							{ traderRank = 0; loadoutRank = 4; quality = 2; price = 700; };
	class srifle_mas_hk417_v						{ traderRank = 0; loadoutRank = 4; quality = 2; price = 700; };
	class srifle_mas_hk417_d						{ traderRank = 0; loadoutRank = 4; quality = 2; price = 700; };
	class srifle_mas_sr25							{ traderRank = 0; loadoutRank = 4; quality = 2; price = 700; };
	class srifle_mas_sr25_v							{ traderRank = 0; loadoutRank = 4; quality = 2; price = 700; };
	class srifle_mas_sr25_d							{ traderRank = 0; loadoutRank = 4; quality = 2; price = 700; };
	class srifle_mas_ebr							{ traderRank = 0; loadoutRank = 4; quality = 2; price = 700; };
	class srifle_mas_mk17s							{ traderRank = 0; loadoutRank = 4; quality = 2; price = 700; };
	class srifle_mas_m110							{ traderRank = 5; loadoutRank = 4; quality = 2; price = 800; };
	class srifle_mas_m107 						{ traderRank = 5; loadoutRank = 4; quality = 3; price = 1000; };
	class srifle_mas_m107_v 						{ traderRank = 5; loadoutRank = 4; quality = 3; price = 1000; };
	class srifle_mas_m107_d 						{ traderRank = 5; loadoutRank = 4; quality = 3; price = 1000; };
	class srifle_mas_m24							{ traderRank = 5; loadoutRank = 4; quality = 2; price = 750; };
	class srifle_mas_m24_v							{ traderRank = 5; loadoutRank = 4; quality = 2; price = 750; };
	class srifle_mas_m24_d							{ traderRank = 5; loadoutRank = 4; quality = 2; price = 750; };
	class srifle_mas_lrr							{ traderRank = 5; loadoutRank = 4; quality = 2; price = 8000; };
	class srifle_mas_m91							{ traderRank = 5; loadoutRank = 4; quality = 2; price = 700; };
	class srifle_mas_svd							{ traderRank = 5; loadoutRank = 4; quality = 2; price = 800; };
	class srifle_mas_vss							{ traderRank = 5; loadoutRank = 4; quality = 2; price = 750; };
	class srifle_mas_ksvk 							{ traderRank = 5; loadoutRank = 4; quality = 3; price = 8000; };
	class srifle_mas_ksvk_c 						{ traderRank = 5; loadoutRank = 4; quality = 3; price = 8000; };	
	// Redo for blackmarket traders
	///////////////////////////////////////////////////////////////////////////////
	// Launchers
	///////////////////////////////////////////////////////////////////////////////
	class mas_launch_maaws_F 						{ traderRank = 5; loadoutRank = 100; quality = 1; price = 7500; sellPrice = 1000;  }; 
	class mas_launch_smaw_F 						{ traderRank = 5; loadoutRank = 100; quality = 1; price = 7500; sellPrice = 1000;  }; 
	class mas_launch_NLAW_F 						{ traderRank = 5; loadoutRank = 100; quality = 1; price = 7500; sellPrice = 1000;  }; 
	class mas_launch_LAW_F 							{ traderRank = 5; loadoutRank = 100; quality = 1; price = 7500; sellPrice = 1000;  }; 
	class mas_launch_M136_F 						{ traderRank = 5; loadoutRank = 100; quality = 1; price = 7500; sellPrice = 1000;  }; 
	class mas_launch_TitanS_F 						{ traderRank = 5; loadoutRank = 100; quality = 1; price = 7500; sellPrice = 1000;  }; 
	class mas_launch_RPG7_F 						{ traderRank = 5; loadoutRank = 100; quality = 1; price = 7500; sellPrice = 1000;  }; 
	class mas_launch_RPG18_F 						{ traderRank = 5; loadoutRank = 100; quality = 1; price = 7500; sellPrice = 1000;  }; 
	class mas_launch_Metis_F 						{ traderRank = 5; loadoutRank = 100; quality = 1; price = 7500; sellPrice = 1000;  }; 
	class mas_launch_pzf60_F 						{ traderRank = 5; loadoutRank = 100; quality = 1; price = 7500; sellPrice = 1000;  }; 
	class mas_launch_Stinger_F 						{ traderRank = 5; loadoutRank = 100; quality = 1; price = 7500; sellPrice = 1000;  }; 
	class mas_launch_Strela_F 						{ traderRank = 5; loadoutRank = 100; quality = 1; price = 7500; sellPrice = 1000;  }; 
	
	///////////////////////////////////////////////////////////////////////////////
	// Launcher Ammo
	///////////////////////////////////////////////////////////////////////////////
	class mas_MAAWS									{ traderRank = 5; loadoutRank = 100; quality = 1; price = 2000; sellPrice = 275;  }; 
	class mas_MAAWS_HE								{ traderRank = 5; loadoutRank = 100; quality = 1; price = 2000; sellPrice = 275;  }; 
	class mas_SMAW									{ traderRank = 5; loadoutRank = 100; quality = 1; price = 2000; sellPrice = 275;  }; 
	class mas_SMAW_HE								{ traderRank = 5; loadoutRank = 100; quality = 1; price = 2000; sellPrice = 275;  }; 
	class mas_SMAW_NE								{ traderRank = 5; loadoutRank = 100; quality = 1; price = 2000; sellPrice = 275;  }; 
	class mas_NLAW									{ traderRank = 5; loadoutRank = 100; quality = 1; price = 2000; sellPrice = 275;  }; 
	class mas_NLAW_HE								{ traderRank = 5; loadoutRank = 100; quality = 1; price = 2000; sellPrice = 275;  }; 
	class NLAW_F									{ traderRank = 5; loadoutRank = 100; quality = 1; price = 2000; sellPrice = 275;  }; 
	class mas_LAW									{ traderRank = 5; loadoutRank = 100; quality = 1; price = 2000; sellPrice = 275;  }; 
	class mas_M136									{ traderRank = 5; loadoutRank = 100; quality = 1; price = 2000; sellPrice = 275;  }; 
	class mas_M136_HE								{ traderRank = 5; loadoutRank = 100; quality = 1; price = 2000; sellPrice = 275;  }; 
	class mas_TitanS								{ traderRank = 5; loadoutRank = 100; quality = 1; price = 2000; sellPrice = 275;  }; 
	class mas_TitanS_HE								{ traderRank = 5; loadoutRank = 100; quality = 1; price = 2000; sellPrice = 275;  }; 
	class Titan_AT									{ traderRank = 5; loadoutRank = 100; quality = 1; price = 2000; sellPrice = 275;  }; 
	class Titan_AP									{ traderRank = 5; loadoutRank = 100; quality = 1; price = 2000; sellPrice = 275;  }; 
	class mas_PG7V									{ traderRank = 5; loadoutRank = 100; quality = 1; price = 2000; sellPrice = 275;  }; 
	class mas_OG7									{ traderRank = 5; loadoutRank = 100; quality = 1; price = 2000; sellPrice = 275;  }; 
	class mas_PG7L									{ traderRank = 5; loadoutRank = 100; quality = 1; price = 2000; sellPrice = 275;  }; 
	class mas_PG7VR									{ traderRank = 5; loadoutRank = 100; quality = 1; price = 2000; sellPrice = 275;  }; 
	class mas_TBG7V									{ traderRank = 5; loadoutRank = 100; quality = 1; price = 2000; sellPrice = 275;  }; 
	class mas_PG18									{ traderRank = 5; loadoutRank = 100; quality = 1; price = 2000; sellPrice = 275;  }; 
	class mas_Metis									{ traderRank = 5; loadoutRank = 100; quality = 1; price = 2000; sellPrice = 275;  }; 
	class mas_Metis_HE								{ traderRank = 5; loadoutRank = 100; quality = 1; price = 2000; sellPrice = 275;  }; 
	class mas_pzf60									{ traderRank = 5; loadoutRank = 100; quality = 1; price = 2000; sellPrice = 275;  }; 
	class mas_Stinger								{ traderRank = 5; loadoutRank = 100; quality = 1; price = 2000; sellPrice = 275;  }; 
	class Titan_AA									{ traderRank = 5; loadoutRank = 100; quality = 1; price = 2000; sellPrice = 275;  }; 
	class mas_Strela								{ traderRank = 5; loadoutRank = 100; quality = 1; price = 2000; sellPrice = 275;  };
	