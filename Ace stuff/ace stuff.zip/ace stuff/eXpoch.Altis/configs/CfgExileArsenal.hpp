// traderRank = 0; loadoutRank = 0; this controls the customization items as well as the trader items based on rank of player.
	class Exile_Uniform_BambiOverall				{ traderRank = 0; loadoutRank = 0; quality = 1; price = 1; sellPrice = 1; };

	///////////////////////////////////////////////////////////////////////////////
	// Best Friend's
	///////////////////////////////////////////////////////////////////////////////
	class Fin_sand_F									{ traderRank = 0; loadoutRank = 100; quality = 1; price = 1000; };
	class Fin_blackwhite_F								{ traderRank = 0; loadoutRank = 100; quality = 1; price = 1500; };
	class Fin_ocherwhite_F								{ traderRank = 0; loadoutRank = 100; quality = 1; price = 1750; };
	class Fin_tricolour_F								{ traderRank = 0; loadoutRank = 100; quality = 1; price = 4000; };
	class Alsatian_Sand_F								{ traderRank = 0; loadoutRank = 100; quality = 1; price = 2000; };
	class Alsatian_Black_F								{ traderRank = 0; loadoutRank = 100; quality = 1; price = 3500; };
	class Alsatian_Sandblack_F							{ traderRank = 0; loadoutRank = 100; quality = 1; price = 2750; };
	
	///////////////////////////////////////////////////////////////////////////////
	// Civillian Clothing
	///////////////////////////////////////////////////////////////////////////////
	class U_C_Journalist 							{ traderRank = 0; loadoutRank = 0; quality = 1; price = 20; };
	class U_C_Poloshirt_blue 						{ traderRank = 0; loadoutRank = 0; quality = 1; price = 20; };
	class U_C_Poloshirt_burgundy 					{ traderRank = 0; loadoutRank = 0; quality = 1; price = 20; };
	class U_C_Poloshirt_salmon 						{ traderRank = 0; loadoutRank = 0; quality = 1; price = 20; };
	class U_C_Poloshirt_stripped 					{ traderRank = 0; loadoutRank = 0; quality = 1; price = 20; };
	class U_C_Poloshirt_tricolour 					{ traderRank = 0; loadoutRank = 0; quality = 1; price = 20; };
	class U_C_Poor_1 								{ traderRank = 0; loadoutRank = 0; quality = 1; price = 20; };
	class U_C_Poor_2 								{ traderRank = 0; loadoutRank = 0; quality = 1; price = 20; };
	class U_C_Poor_shorts_1 						{ traderRank = 0; loadoutRank = 0; quality = 1; price = 20; };
	class U_C_Scientist 							{ traderRank = 0; loadoutRank = 0; quality = 1; price = 20; };
	class U_OrestesBody 							{ traderRank = 0; loadoutRank = 0; quality = 1; price = 40; };
	class U_Rangemaster 							{ traderRank = 0; loadoutRank = 0; quality = 1; price = 40; };
	class U_NikosAgedBody 							{ traderRank = 0; loadoutRank = 0; quality = 1; price = 40; };
	class U_NikosBody 								{ traderRank = 0; loadoutRank = 0; quality = 1; price = 40; };
	class U_Competitor 								{ traderRank = 0; loadoutRank = 0; quality = 1; price = 40; };

	///////////////////////////////////////////////////////////////////////////////
	// Soldier Uniforms
	///////////////////////////////////////////////////////////////////////////////
	class U_B_CombatUniform_mcam 					{ traderRank = 0; loadoutRank = 1; quality = 2; price = 40; };
	class U_B_CombatUniform_mcam_tshirt 			{ traderRank = 0; loadoutRank = 1; quality = 2; price = 40; };
	class U_B_CombatUniform_mcam_vest 				{ traderRank = 0; loadoutRank = 1; quality = 2; price = 40; };
	class U_B_CombatUniform_mcam_worn 				{ traderRank = 0; loadoutRank = 1; quality = 2; price = 40; };
	class U_B_CTRG_1 								{ traderRank = 0; loadoutRank = 1; quality = 2; price = 40; };
	class U_B_CTRG_2 								{ traderRank = 0; loadoutRank = 1; quality = 2; price = 40; };
	class U_B_CTRG_3								{ traderRank = 0; loadoutRank = 1; quality = 2; price = 40; };
	class U_I_CombatUniform 						{ traderRank = 0; loadoutRank = 1; quality = 2; price = 40; };
	class U_I_CombatUniform_shortsleeve				{ traderRank = 0; loadoutRank = 1; quality = 2; price = 40; };
	class U_I_CombatUniform_tshirt					{ traderRank = 0; loadoutRank = 1; quality = 2; price = 40; };
	class U_I_OfficerUniform						{ traderRank = 0; loadoutRank = 1; quality = 2; price = 40; };
	class U_O_CombatUniform_ocamo 					{ traderRank = 0; loadoutRank = 1; quality = 2; price = 40; };
	class U_O_CombatUniform_oucamo 					{ traderRank = 0; loadoutRank = 1; quality = 2; price = 40; };
	class U_O_OfficerUniform_ocamo 					{ traderRank = 0; loadoutRank = 2; quality = 3; price = 80; };
	class U_B_SpecopsUniform_sgg 					{ traderRank = 0; loadoutRank = 2; quality = 3; price = 80; };
	class U_O_SpecopsUniform_blk 					{ traderRank = 0; loadoutRank = 2; quality = 3; price = 80; };
	class U_O_SpecopsUniform_ocamo 					{ traderRank = 0; loadoutRank = 2; quality = 3; price = 80; };
	class U_I_G_Story_Protagonist_F 				{ traderRank = 0; loadoutRank = 2; quality = 3; price = 100; };
	class Exile_Uniform_Woodland 					{ traderRank = 0; loadoutRank = 2; quality = 3; price = 150; };

	///////////////////////////////////////////////////////////////////////////////
	// Guerilla Uniforms
	///////////////////////////////////////////////////////////////////////////////
	class U_C_HunterBody_grn						{ traderRank = 0; loadoutRank = 3; quality = 2; price = 40; };
	class U_IG_Guerilla1_1							{ traderRank = 0; loadoutRank = 3; quality = 2; price = 40; };
	class U_IG_Guerilla2_1							{ traderRank = 0; loadoutRank = 3; quality = 2; price = 60; };
	class U_IG_Guerilla2_2							{ traderRank = 0; loadoutRank = 3; quality = 2; price = 40; };
	class U_IG_Guerilla2_3							{ traderRank = 0; loadoutRank = 3; quality = 2; price = 40; };
	class U_IG_Guerilla3_1							{ traderRank = 0; loadoutRank = 3; quality = 2; price = 40; };
	class U_BG_Guerilla2_1							{ traderRank = 0; loadoutRank = 3; quality = 2; price = 40; };
	class U_IG_Guerilla3_2							{ traderRank = 0; loadoutRank = 3; quality = 2; price = 40; };
	class U_BG_Guerrilla_6_1						{ traderRank = 0; loadoutRank = 3; quality = 2; price = 60; };
	class U_BG_Guerilla1_1							{ traderRank = 0; loadoutRank = 3; quality = 2; price = 40; };
	class U_BG_Guerilla2_2							{ traderRank = 0; loadoutRank = 3; quality = 2; price = 40; };
	class U_BG_Guerilla2_3							{ traderRank = 0; loadoutRank = 3; quality = 2; price = 40; };
	class U_BG_Guerilla3_1							{ traderRank = 0; loadoutRank = 3; quality = 2; price = 40; };
	class U_BG_leader								{ traderRank = 0; loadoutRank = 3; quality = 3; price = 40; };
	class U_IG_leader								{ traderRank = 0; loadoutRank = 3; quality = 3; price = 40; };
	class U_I_G_resistanceLeader_F					{ traderRank = 0; loadoutRank = 3; quality = 3; price = 100; };

	///////////////////////////////////////////////////////////////////////////////
	// Ghillie Suits
	///////////////////////////////////////////////////////////////////////////////
	class U_B_FullGhillie_ard						{ traderRank = 0; loadoutRank = 3; quality = 4; price = 150; };
	class U_B_FullGhillie_lsh						{ traderRank = 0; loadoutRank = 3; quality = 4; price = 150; };
	class U_B_FullGhillie_sard						{ traderRank = 0; loadoutRank = 3; quality = 4; price = 150; };
	class U_B_GhillieSuit							{ traderRank = 0; loadoutRank = 3; quality = 3; price = 100; };
	class U_I_FullGhillie_ard						{ traderRank = 0; loadoutRank = 3; quality = 4; price = 150; };
	class U_I_FullGhillie_lsh						{ traderRank = 0; loadoutRank = 3; quality = 4; price = 150; };
	class U_I_FullGhillie_sard						{ traderRank = 0; loadoutRank = 4; quality = 4; price = 150; };
	class U_I_GhillieSuit							{ traderRank = 0; loadoutRank = 4; quality = 3; price = 100; };
	class U_O_FullGhillie_ard						{ traderRank = 0; loadoutRank = 4; quality = 6; price = 150; };
	class U_O_FullGhillie_lsh						{ traderRank = 0; loadoutRank = 4; quality = 6; price = 150; };
	class U_O_FullGhillie_sard						{ traderRank = 0; loadoutRank = 4; quality = 6; price = 150; };
	class U_O_GhillieSuit							{ traderRank = 0; loadoutRank = 4; quality = 5; price = 100; };

	///////////////////////////////////////////////////////////////////////////////
	// Wet Suits
	///////////////////////////////////////////////////////////////////////////////
	class U_I_Wetsuit								{ traderRank = 0; loadoutRank = 4; quality = 3; price = 80; };
	class U_O_Wetsuit								{ traderRank = 0; loadoutRank = 4; quality = 3; price = 80; };
	class U_B_Wetsuit								{ traderRank = 0; loadoutRank = 4; quality = 3; price = 80; };
	class U_B_survival_uniform						{ traderRank = 0; loadoutRank = 4; quality = 3; price = 80; };
	
	///////////////////////////////////////////////////////////////////////////////
	// Keesha's Klothing
	///////////////////////////////////////////////////////////////////////////////
	class U_BasicBodyFemale 							{ traderRank = 0; loadoutRank = 100; quality = 1; price = 250000; };
	class V_F0_EPOCH 									{ traderRank = 0; loadoutRank = 0; quality = 1; price = 2250; };
	class V_F1_EPOCH 									{ traderRank = 0; loadoutRank = 0; quality = 1; price = 2500; };
	class V_F2_EPOCH 									{ traderRank = 0; loadoutRank = 0; quality = 1; price = 2750; };
	class V_F3_EPOCH 									{ traderRank = 0; loadoutRank = 0; quality = 1; price = 3000; };
	class V_F4_EPOCH 									{ traderRank = 0; loadoutRank = 0; quality = 1; price = 3250; };
	class V_F5_EPOCH 									{ traderRank = 0; loadoutRank = 0; quality = 1; price = 3500; };
	class V_F41_EPOCH 									{ traderRank = 0; loadoutRank = 0; quality = 1; price = 1500; };
	class U_Wetsuit_Uniform 							{ traderRank = 0; loadoutRank = 4; quality = 1; price = 15000; };
	class U_Wetsuit_White 								{ traderRank = 0; loadoutRank = 3; quality = 1; price = 10000; };
	class U_Wetsuit_Blue 								{ traderRank = 0; loadoutRank = 3; quality = 1; price = 12500; };
	class U_Wetsuit_Purp 								{ traderRank = 0; loadoutRank = 3; quality = 1; price = 13000; };
	class U_Wetsuit_Camo 								{ traderRank = 0; loadoutRank = 3; quality = 1; price = 25000; };
	class U_ghillie1_uniform 							{ traderRank = 0; loadoutRank = 2; quality = 1; price = 150; };
	class U_ghillie2_uniform 							{ traderRank = 0; loadoutRank = 2; quality = 1; price = 150; };
	class U_ghillie3_uniform 							{ traderRank = 0; loadoutRank = 2; quality = 1; price = 150; };
	class U_CamoBlue_uniform 							{ traderRank = 0; loadoutRank = 1; quality = 1; price = 150; };
	class U_CamoBrn_uniform 							{ traderRank = 0; loadoutRank = 1; quality = 1; price = 150; };
	class U_CamoRed_uniform 							{ traderRank = 0; loadoutRank = 1; quality = 1; price = 150; };
	class eXpoch_U_camo_pinkpolka 						{ traderRank = 0; loadoutRank = 2; quality = 1; price = 150; };
	class eXpoch_U_camo_pink 							{ traderRank = 0; loadoutRank = 1; quality = 1; price = 150; };
	class eXpoch_U_camo_outback 						{ traderRank = 0; loadoutRank = 2; quality = 1; price = 150; };
	class eXpoch_U_camo_lumberjack 						{ traderRank = 0; loadoutRank = 3; quality = 1; price = 150; };
	class eXpoch_U_camo_bubblegum 						{ traderRank = 0; loadoutRank = 1; quality = 1; price = 150; };
	class eXpoch_U_camo_biker 							{ traderRank = 0; loadoutRank = 4; quality = 1; price = 150; };
	class eXpoch_U_camo_aloha 							{ traderRank = 0; loadoutRank = 2; quality = 1; price = 150; };
	
	///////////////////////////////////////////////////////////////////////////////
	// Bandolliers
	///////////////////////////////////////////////////////////////////////////////
	class V_BandollierB_blk							{ traderRank = 0; loadoutRank = 0; quality = 1; price = 20; };
	class V_BandollierB_cbr							{ traderRank = 0; loadoutRank = 0; quality = 1; price = 20; };
	class V_BandollierB_khk							{ traderRank = 0; loadoutRank = 0; quality = 1; price = 20; };
	class V_BandollierB_oli							{ traderRank = 0; loadoutRank = 0; quality = 1; price = 20; };
	class V_BandollierB_rgr							{ traderRank = 0; loadoutRank = 0; quality = 1; price = 20; };

	///////////////////////////////////////////////////////////////////////////////
	// Chestrigs
	///////////////////////////////////////////////////////////////////////////////
	class V_Chestrig_blk 							{ traderRank = 0; loadoutRank = 1; quality = 1; price = 30; };
	class V_Chestrig_khk 							{ traderRank = 0; loadoutRank = 1; quality = 1; price = 30; };
	class V_Chestrig_oli 							{ traderRank = 0; loadoutRank = 1; quality = 1; price = 30; };
	class V_Chestrig_rgr 							{ traderRank = 0; loadoutRank = 1; quality = 1; price = 30; };

	///////////////////////////////////////////////////////////////////////////////
	// Vests
	///////////////////////////////////////////////////////////////////////////////
	class V_Press_F									{ traderRank = 0; loadoutRank = 0; quality = 1; price = 10; };
	class V_Rangemaster_belt						{ traderRank = 0; loadoutRank = 0; quality = 1; price = 6; };
	class V_TacVest_blk								{ traderRank = 0; loadoutRank = 1; quality = 2; price = 50; };
	class V_TacVest_blk_POLICE						{ traderRank = 0; loadoutRank = 1; quality = 3; price = 50; };
	class V_TacVest_brn								{ traderRank = 0; loadoutRank = 1; quality = 2; price = 50; };
	class V_TacVest_camo							{ traderRank = 0; loadoutRank = 1; quality = 2; price = 50; };
	class V_TacVest_khk								{ traderRank = 0; loadoutRank = 1; quality = 2; price = 50; };
	class V_TacVest_oli								{ traderRank = 0; loadoutRank = 1; quality = 2; price = 50; };
	class V_TacVestCamo_khk							{ traderRank = 0; loadoutRank = 1; quality = 2; price = 50; };
	class V_TacVestIR_blk							{ traderRank = 0; loadoutRank = 1; quality = 2; price = 50; };
	class V_I_G_resistanceLeader_F					{ traderRank = 0; loadoutRank = 1; quality = 2; price = 50; };

	///////////////////////////////////////////////////////////////////////////////
	// Harnesses
	///////////////////////////////////////////////////////////////////////////////
	class V_HarnessO_brn							{ traderRank = 0; loadoutRank = 2; quality = 1; price = 40; };
	class V_HarnessO_gry							{ traderRank = 0; loadoutRank = 2; quality = 1; price = 40; };
	class V_HarnessOGL_brn							{ traderRank = 0; loadoutRank = 2; quality = 1; price = 30; };
	class V_HarnessOGL_gry							{ traderRank = 0; loadoutRank = 2; quality = 1; price = 30; };
	class V_HarnessOSpec_brn						{ traderRank = 0; loadoutRank = 2; quality = 1; price = 40; };
	class V_HarnessOSpec_gry						{ traderRank = 0; loadoutRank = 2; quality = 1; price = 40; };

	///////////////////////////////////////////////////////////////////////////////
	// Plate Carriers
	///////////////////////////////////////////////////////////////////////////////
	class V_PlateCarrier1_blk 						{ traderRank = 0; loadoutRank = 3; quality = 1; price = 80; };
	class V_PlateCarrier1_rgr 						{ traderRank = 0; loadoutRank = 3; quality = 1; price = 80; };
	class V_PlateCarrier2_rgr 						{ traderRank = 0; loadoutRank = 3; quality = 2; price = 100; };
	class V_PlateCarrier3_rgr 						{ traderRank = 0; loadoutRank = 3; quality = 2; price = 100; };
	class V_PlateCarrierGL_blk 						{ traderRank = 0; loadoutRank = 3; quality = 6; price = 500; };
	class V_PlateCarrierGL_mtp 						{ traderRank = 0; loadoutRank = 3; quality = 6; price = 500; };
	class V_PlateCarrierGL_rgr 						{ traderRank = 0; loadoutRank = 3; quality = 6; price = 500; };
	class V_PlateCarrierH_CTRG 						{ traderRank = 0; loadoutRank = 3; quality = 2; price = 100; };
	class V_PlateCarrierIA1_dgtl 					{ traderRank = 0; loadoutRank = 3; quality = 2; price = 80; };
	class V_PlateCarrierIA2_dgtl 					{ traderRank = 0; loadoutRank = 3; quality = 2; price = 100; };
	class V_PlateCarrierIAGL_dgtl 					{ traderRank = 0; loadoutRank = 3; quality = 3; price = 400; };
	class V_PlateCarrierIAGL_oli 					{ traderRank = 0; loadoutRank = 3; quality = 3; price = 400; };
	class V_PlateCarrierL_CTRG 						{ traderRank = 0; loadoutRank = 3; quality = 2; price = 100; };
	class V_PlateCarrierSpec_blk 					{ traderRank = 0; loadoutRank = 4; quality = 5; price = 200; };
	class V_PlateCarrierSpec_mtp 					{ traderRank = 0; loadoutRank = 4; quality = 5; price = 200; };
	class V_PlateCarrierSpec_rgr 					{ traderRank = 0; loadoutRank = 4; quality = 5; price = 200; };

	///////////////////////////////////////////////////////////////////////////////
	// Caps
	///////////////////////////////////////////////////////////////////////////////
	class H_Cap_blk 								{ traderRank = 0; loadoutRank = 0; quality = 1; price = 6; };
	class H_Cap_blk_Raven 							{ traderRank = 0; loadoutRank = 0; quality = 1; price = 6; };
	class H_Cap_blu 								{ traderRank = 0; loadoutRank = 0; quality = 1; price = 6; };
	class H_Cap_brn_SPECOPS 						{ traderRank = 0; loadoutRank = 0; quality = 1; price = 6; };
	class H_Cap_grn 								{ traderRank = 0; loadoutRank = 0; quality = 1; price = 6; };
	class H_Cap_headphones 							{ traderRank = 0; loadoutRank = 0; quality = 1; price = 6; };
	class H_Cap_khaki_specops_UK 					{ traderRank = 0; loadoutRank = 0; quality = 1; price = 6; };
	class H_Cap_oli 								{ traderRank = 0; loadoutRank = 0; quality = 1; price = 6; };
	class H_Cap_press 								{ traderRank = 0; loadoutRank = 0; quality = 1; price = 6; };
	class H_Cap_red 								{ traderRank = 0; loadoutRank = 0; quality = 1; price = 6; };
	class H_Cap_tan 								{ traderRank = 0; loadoutRank = 0; quality = 1; price = 6; };
	class H_Cap_tan_specops_US 						{ traderRank = 0; loadoutRank = 0; quality = 1; price = 6; };
	
	///////////////////////////////////////////////////////////////////////////////
	// Masks
	///////////////////////////////////////////////////////////////////////////////
	class clown_mask_epoch								{ traderRank = 0; loadoutRank = 0; quality = 1; price = 700; };
	
	///////////////////////////////////////////////////////////////////////////////
	// Glasses
	///////////////////////////////////////////////////////////////////////////////
	class G_Spectacles			 		{ traderRank = 0; loadoutRank = 0; quality = 1; price = 6; };
	class G_Spectacles_Tinted			{ traderRank = 0; loadoutRank = 0; quality = 1; price = 6; };
	class G_Combat			 			{ traderRank = 0; loadoutRank = 2; quality = 1; price = 6; };
	class G_Lowprofile			 		{ traderRank = 0; loadoutRank = 2; quality = 1; price = 6; };
	class G_Shades_Black			 	{ traderRank = 0; loadoutRank = 0; quality = 1; price = 6; };
	class G_Shades_Green			 	{ traderRank = 0; loadoutRank = 0; quality = 1; price = 6; };
	class G_Shades_Red			 		{ traderRank = 0; loadoutRank = 0; quality = 1; price = 6; };
	class G_Squares			 			{ traderRank = 0; loadoutRank = 2; quality = 1; price = 6; };
	class G_Squares_Tinted			 	{ traderRank = 0; loadoutRank = 2; quality = 1; price = 6; };
	class G_Sport_BlackWhite			{ traderRank = 0; loadoutRank = 1; quality = 1; price = 6; };
	class G_Sport_Blackyellow			{ traderRank = 0; loadoutRank = 1; quality = 1; price = 6; };
	class G_Sport_Greenblack			{ traderRank = 0; loadoutRank = 1; quality = 1; price = 6; };
	class G_Sport_Checkered			 	{ traderRank = 0; loadoutRank = 1; quality = 1; price = 6; };
	class G_Sport_Red			 		{ traderRank = 0; loadoutRank = 1; quality = 1; price = 6; };
	class G_Tactical_Black			 	{ traderRank = 0; loadoutRank = 1; quality = 1; price = 6; };
	class G_Aviator			 			{ traderRank = 0; loadoutRank = 1; quality = 1; price = 6; };
	class G_Lady_Mirror			 		{ traderRank = 0; loadoutRank = 0; quality = 1; price = 6; };
	class G_Lady_Dark			 		{ traderRank = 0; loadoutRank = 0; quality = 1; price = 6; };
	class G_Lady_Red			 		{ traderRank = 0; loadoutRank = 0; quality = 1; price = 6; };
	class G_Lady_Blue			 		{ traderRank = 0; loadoutRank = 0; quality = 1; price = 6; };
	class G_Diving			 			{ traderRank = 0; loadoutRank = 3; quality = 1; price = 6; };
	class G_B_Diving			 		{ traderRank = 0; loadoutRank = 3; quality = 1; price = 6; };
	class G_O_Diving			 		{ traderRank = 0; loadoutRank = 3; quality = 1; price = 6; };
	class G_I_Diving			 		{ traderRank = 0; loadoutRank = 3; quality = 1; price = 6; };
	class G_Goggles_VR			 		{ traderRank = 0; loadoutRank = 5; quality = 1; price = 6; };
	class G_Balaclava_blk			 	{ traderRank = 0; loadoutRank = 3; quality = 2; price = 10; };
	class G_Balaclava_oli			 	{ traderRank = 0; loadoutRank = 3; quality = 2; price = 10; };
	class G_Balaclava_combat			{ traderRank = 0; loadoutRank = 3; quality = 2; price = 10; };
	class G_Balaclava_lowprofile		{ traderRank = 0; loadoutRank = 3; quality = 2; price = 10; };
	class G_Bandanna_blk			 	{ traderRank = 0; loadoutRank = 1; quality = 1; price = 6; };
	class G_Bandanna_oli			 	{ traderRank = 0; loadoutRank = 1; quality = 1; price = 6; };
	class G_Bandanna_khk			 	{ traderRank = 0; loadoutRank = 1; quality = 1; price = 6; };
	class G_Bandanna_tan			 	{ traderRank = 0; loadoutRank = 1; quality = 1; price = 6; };
	class G_Bandanna_beast			 	{ traderRank = 0; loadoutRank = 1; quality = 1; price = 6; };
	class G_Bandanna_shades			 	{ traderRank = 0; loadoutRank = 1; quality = 1; price = 6; };
	class G_Bandanna_sport			 	{ traderRank = 0; loadoutRank = 1; quality = 1; price = 6; };
	class G_Bandanna_aviator			{ traderRank = 0; loadoutRank = 1; quality = 1; price = 6; };
	class G_Shades_Blue			 		{ traderRank = 0; loadoutRank = 1; quality = 1; price = 6; };
	class G_Sport_Blackred			 	{ traderRank = 0; loadoutRank = 1; quality = 1; price = 6; };
	class G_Tactical_Clear			 	{ traderRank = 0; loadoutRank = 1; quality = 1; price = 6; };
	class G_Balaclava_TI_blk_F			{ traderRank = 0; loadoutRank = 1; quality = 2; price = 15; };
	class G_Balaclava_TI_tna_F			{ traderRank = 0; loadoutRank = 1; quality = 2; price = 15; };
	class G_Balaclava_TI_G_blk_F		{ traderRank = 0; loadoutRank = 1; quality = 2; price = 15; };
	class G_Balaclava_TI_G_tna_F		{ traderRank = 0; loadoutRank = 1; quality = 2; price = 15; };
	class G_Combat_Goggles_tna_F		{ traderRank = 0; loadoutRank = 1; quality = 1; price = 6; };

	///////////////////////////////////////////////////////////////////////////////
	// Military Caps
	///////////////////////////////////////////////////////////////////////////////
	class H_MilCap_blue 							{ traderRank = 0; loadoutRank = 4; quality = 1; price = 8; };
	class H_MilCap_dgtl 							{ traderRank = 0; loadoutRank = 4; quality = 1; price = 8; };
	class H_MilCap_mcamo 							{ traderRank = 0; loadoutRank = 4; quality = 1; price = 8; };
	class H_MilCap_ocamo 							{ traderRank = 0; loadoutRank = 4; quality = 1; price = 8; };
	class H_MilCap_oucamo 							{ traderRank = 0; loadoutRank = 4; quality = 1; price = 8; };
	class H_MilCap_rucamo 							{ traderRank = 0; loadoutRank = 4; quality = 1; price = 8; };

	///////////////////////////////////////////////////////////////////////////////
	// Beanies
	///////////////////////////////////////////////////////////////////////////////
	class H_Watchcap_blk 							{ traderRank = 0; loadoutRank = 2; quality = 1; price = 6; };
	class H_Watchcap_camo 							{ traderRank = 0; loadoutRank = 2; quality = 1; price = 6; };
	class H_Watchcap_khk 							{ traderRank = 0; loadoutRank = 2; quality = 1; price = 6; };
	class H_Watchcap_sgg 							{ traderRank = 0; loadoutRank = 2; quality = 1; price = 6; };

	///////////////////////////////////////////////////////////////////////////////
	// Bandannas
	///////////////////////////////////////////////////////////////////////////////
	class H_Bandanna_camo							{ traderRank = 0; loadoutRank = 0; quality = 1; price = 4; };
	class H_Bandanna_cbr							{ traderRank = 0; loadoutRank = 0; quality = 1; price = 4; };
	class H_Bandanna_gry							{ traderRank = 0; loadoutRank = 0; quality = 1; price = 4; };
	class H_Bandanna_khk							{ traderRank = 0; loadoutRank = 0; quality = 1; price = 4; };
	class H_Bandanna_khk_hs							{ traderRank = 0; loadoutRank = 0; quality = 1; price = 4; };
	class H_Bandanna_mcamo							{ traderRank = 0; loadoutRank = 0; quality = 1; price = 4; };
	class H_Bandanna_sgg							{ traderRank = 0; loadoutRank = 0; quality = 1; price = 4; };
	class H_Bandanna_surfer							{ traderRank = 0; loadoutRank = 0; quality = 1; price = 4; };

	///////////////////////////////////////////////////////////////////////////////
	// Boonie Hats
	///////////////////////////////////////////////////////////////////////////////
	class H_Booniehat_dgtl							{ traderRank = 0; loadoutRank = 0; quality = 1; price = 6; };
	class H_Booniehat_dirty							{ traderRank = 0; loadoutRank = 0; quality = 1; price = 6; };
	class H_Booniehat_grn							{ traderRank = 0; loadoutRank = 0; quality = 1; price = 6; };
	class H_Booniehat_indp							{ traderRank = 0; loadoutRank = 0; quality = 1; price = 6; };
	class H_Booniehat_khk							{ traderRank = 0; loadoutRank = 0; quality = 1; price = 6; };
	class H_Booniehat_khk_hs						{ traderRank = 0; loadoutRank = 0; quality = 1; price = 6; };
	class H_Booniehat_mcamo							{ traderRank = 0; loadoutRank = 0; quality = 1; price = 6; };
	class H_Booniehat_tan							{ traderRank = 0; loadoutRank = 0; quality = 1; price = 6; };

	///////////////////////////////////////////////////////////////////////////////
	// Hats
	///////////////////////////////////////////////////////////////////////////////
	class H_Hat_blue								{ traderRank = 0; loadoutRank = 0; quality = 1; price = 6; };
	class H_Hat_brown								{ traderRank = 0; loadoutRank = 0; quality = 1; price = 6; };
	class H_Hat_camo								{ traderRank = 0; loadoutRank = 0; quality = 1; price = 6; };
	class H_Hat_checker								{ traderRank = 0; loadoutRank = 0; quality = 1; price = 6; };
	class H_Hat_grey								{ traderRank = 0; loadoutRank = 0; quality = 1; price = 6; };
	class H_Hat_tan									{ traderRank = 0; loadoutRank = 0; quality = 1; price = 6; };
	class H_StrawHat								{ traderRank = 0; loadoutRank = 0; quality = 1; price = 6; };
	class H_StrawHat_dark							{ traderRank = 0; loadoutRank = 0; quality = 1; price = 6; };
	class Exile_Headgear_SantaHat					{ traderRank = 0; loadoutRank = 0; quality = 1; price = 10; };
	class Exile_Headgear_SafetyHelmet				{ traderRank = 0; loadoutRank = 0; quality = 1; price = 20; };

	///////////////////////////////////////////////////////////////////////////////
	// Berets
	///////////////////////////////////////////////////////////////////////////////
	class H_Beret_02								{ traderRank = 0; loadoutRank = 3; quality = 2; price = 6; };
	class H_Beret_blk								{ traderRank = 0; loadoutRank = 3; quality = 2; price = 6; };
	class H_Beret_blk_POLICE						{ traderRank = 0; loadoutRank = 3; quality = 2; price = 6; };
	class H_Beret_brn_SF							{ traderRank = 0; loadoutRank = 3; quality = 2; price = 6; };
	class H_Beret_Colonel							{ traderRank = 0; loadoutRank = 3; quality = 3; price = 8; };
	class H_Beret_grn								{ traderRank = 0; loadoutRank = 3; quality = 2; price = 6; };
	class H_Beret_grn_SF							{ traderRank = 0; loadoutRank = 3; quality = 2; price = 6; };
	class H_Beret_ocamo								{ traderRank = 0; loadoutRank = 3; quality = 2; price = 6; };
	class H_Beret_red								{ traderRank = 0; loadoutRank = 3; quality = 2; price = 6; };

	///////////////////////////////////////////////////////////////////////////////
	// Shemags
	///////////////////////////////////////////////////////////////////////////////
	class H_Shemag_khk								{ traderRank = 0; loadoutRank = 3; quality = 1; price = 10; };
	class H_Shemag_olive							{ traderRank = 0; loadoutRank = 3; quality = 1; price = 10; };
	class H_Shemag_olive_hs							{ traderRank = 0; loadoutRank = 3; quality = 1; price = 10; };
	class H_Shemag_tan								{ traderRank = 0; loadoutRank = 3; quality = 1; price = 10; };
	class H_ShemagOpen_khk							{ traderRank = 0; loadoutRank = 3; quality = 1; price = 10; };
	class H_ShemagOpen_tan							{ traderRank = 0; loadoutRank = 3; quality = 1; price = 10; };
	class H_TurbanO_blk								{ traderRank = 0; loadoutRank = 3; quality = 1; price = 10; };

	///////////////////////////////////////////////////////////////////////////////
	// Light Helmets
	///////////////////////////////////////////////////////////////////////////////
	class H_HelmetB_light							{ traderRank = 0; loadoutRank = 5; quality = 2; price = 20; };
	class H_HelmetB_light_black						{ traderRank = 0; loadoutRank = 5; quality = 2; price = 20; };
	class H_HelmetB_light_desert					{ traderRank = 0; loadoutRank = 5; quality = 2; price = 20; };
	class H_HelmetB_light_grass						{ traderRank = 0; loadoutRank = 5; quality = 2; price = 20; };
	class H_HelmetB_light_sand						{ traderRank = 0; loadoutRank = 5; quality = 2; price = 20; };
	class H_HelmetB_light_snakeskin					{ traderRank = 0; loadoutRank = 5; quality = 2; price = 20; };

	///////////////////////////////////////////////////////////////////////////////
	// Helmets
	///////////////////////////////////////////////////////////////////////////////
	class H_HelmetIA								{ traderRank = 0; loadoutRank = 5; quality = 3; price = 40; };
	class H_HelmetIA_camo							{ traderRank = 0; loadoutRank = 5; quality = 3; price = 40; };
	class H_HelmetIA_net							{ traderRank = 0; loadoutRank = 5; quality = 3; price = 40; };
	class H_HelmetB									{ traderRank = 0; loadoutRank = 5; quality = 3; price = 60; };
	class H_HelmetB_black							{ traderRank = 0; loadoutRank = 5; quality = 3; price = 60; };
	class H_HelmetB_camo							{ traderRank = 0; loadoutRank = 5; quality = 3; price = 80; }; // This one is awesome!
	class H_HelmetB_desert							{ traderRank = 0; loadoutRank = 5; quality = 3; price = 60; };
	class H_HelmetB_grass							{ traderRank = 0; loadoutRank = 5; quality = 3; price = 60; };
	class H_HelmetB_paint							{ traderRank = 0; loadoutRank = 5; quality = 3; price = 60; };
	class H_HelmetB_plain_blk						{ traderRank = 0; loadoutRank = 5; quality = 3; price = 60; };
	class H_HelmetB_sand							{ traderRank = 0; loadoutRank = 5; quality = 3; price = 60; };
	class H_HelmetB_snakeskin						{ traderRank = 0; loadoutRank = 5; quality = 3; price = 60; };

	///////////////////////////////////////////////////////////////////////////////
	// Spec Ops Helmets
	///////////////////////////////////////////////////////////////////////////////
	class H_HelmetSpecB								{ traderRank = 0; loadoutRank = 6; quality = 4; price = 80; };
	class H_HelmetSpecB_blk							{ traderRank = 0; loadoutRank = 6; quality = 4; price = 80; };
	class H_HelmetSpecB_paint1						{ traderRank = 0; loadoutRank = 6; quality = 4; price = 80; };
	class H_HelmetSpecB_paint2						{ traderRank = 0; loadoutRank = 6; quality = 4; price = 80; };

	///////////////////////////////////////////////////////////////////////////////
	// Super Helmets
	///////////////////////////////////////////////////////////////////////////////
	class H_HelmetO_ocamo							{ traderRank = 0; loadoutRank = 7; quality = 5; price = 150; };
	class H_HelmetO_oucamo							{ traderRank = 0; loadoutRank = 7; quality = 5; price = 150; };
	class H_HelmetSpecO_blk							{ traderRank = 0; loadoutRank = 7; quality = 5; price = 100; };
	class H_HelmetSpecO_ocamo						{ traderRank = 0; loadoutRank = 7; quality = 5; price = 100; };
	class H_HelmetLeaderO_ocamo						{ traderRank = 0; loadoutRank = 7; quality = 5; price = 200; };
	class H_HelmetLeaderO_oucamo					{ traderRank = 0; loadoutRank = 7; quality = 5; price = 200; };

	///////////////////////////////////////////////////////////////////////////////
	// Pointer Attachments
	///////////////////////////////////////////////////////////////////////////////
	class acc_flashlight 							{ traderRank = 0; loadoutRank = 0; quality = 1; price = 4; };
	class acc_pointer_IR 							{ traderRank = 0; loadoutRank = 0; quality = 1; price = 10; };

	///////////////////////////////////////////////////////////////////////////////
	// Bitpod Attachments
	///////////////////////////////////////////////////////////////////////////////
	class bipod_01_F_blk	 						{ traderRank = 0; loadoutRank = 1; quality = 2; price = 10; };
	class bipod_01_F_mtp	 						{ traderRank = 0; loadoutRank = 1; quality = 2; price = 10; };
	class bipod_01_F_snd	 						{ traderRank = 0; loadoutRank = 1; quality = 2; price = 10; };
	class bipod_02_F_blk	 						{ traderRank = 0; loadoutRank = 1; quality = 2; price = 10; };
	class bipod_02_F_hex	 						{ traderRank = 0; loadoutRank = 1; quality = 2; price = 10; };
	class bipod_02_F_tan	 						{ traderRank = 0; loadoutRank = 1; quality = 2; price = 10; };
	class bipod_03_F_blk	 						{ traderRank = 0; loadoutRank = 1; quality = 2; price = 10; };
	class bipod_03_F_oli	 						{ traderRank = 0; loadoutRank = 1; quality = 2; price = 10; };

	///////////////////////////////////////////////////////////////////////////////
	// Muzzle Attachments
	///////////////////////////////////////////////////////////////////////////////
	class muzzle_snds_338_black 					{ traderRank = 5; loadoutRank = 5; quality = 5; price = 50; };
	class muzzle_snds_338_green 					{ traderRank = 5; loadoutRank = 5; quality = 5; price = 50; };
	class muzzle_snds_338_sand 						{ traderRank = 5; loadoutRank = 5; quality = 5; price = 50; };
	class muzzle_snds_93mmg 						{ traderRank = 5; loadoutRank = 5; quality = 4; price = 50; };
	class muzzle_snds_93mmg_tan 					{ traderRank = 5; loadoutRank = 5; quality = 4; price = 50; };
	class muzzle_snds_acp 							{ traderRank = 5; loadoutRank = 5; quality = 1; price = 10; };
	class muzzle_snds_B 							{ traderRank = 5; loadoutRank = 5; quality = 3; price = 20; };
	class muzzle_snds_H 							{ traderRank = 5; loadoutRank = 5; quality = 2; price = 20; };
	class muzzle_snds_H_MG 							{ traderRank = 5; loadoutRank = 5; quality = 2; price = 20; };
	class muzzle_snds_H_SW 							{ traderRank = 5; loadoutRank = 5; quality = 2; price = 20; };
	class muzzle_snds_L 							{ traderRank = 5; loadoutRank = 5; quality = 1; price = 10; };
	class muzzle_snds_M 							{ traderRank = 5; loadoutRank = 5; quality = 1; price = 10; };
	class muzzle_sr25S_epoch 							{ traderRank = 5; loadoutRank = 100; quality = 1; price = 250; };

	///////////////////////////////////////////////////////////////////////////////
	// UAVS
	///////////////////////////////////////////////////////////////////////////////
	class I_UavTerminal								{ traderRank = 5; loadoutRank = 10; quality = 4; price = 750; };
	class I_UAV_01_backpack_F						{ traderRank = 5; loadoutRank = 10; quality = 4; price = 3000; };

	///////////////////////////////////////////////////////////////////////////////
	// Static MGs
	///////////////////////////////////////////////////////////////////////////////
	class O_HMG_01_weapon_F 						{ traderRank = 5; loadoutRank = 100; quality = 4; price = 5000; };
	class O_HMG_01_support_F 						{ traderRank = 5; loadoutRank = 100; quality = 4; price = 1000; };
	// Does not seem to work with HMG01, only the lower version does
	//class O_HMG_01_support_high_F 				{ traderRank = 5; loadoutRank = 100; quality = QUALITY_LEVEL_9000; price = 5000; };

	///////////////////////////////////////////////////////////////////////////////
	// Optic Attachments
	///////////////////////////////////////////////////////////////////////////////
	class optic_Aco									{ traderRank = 0; loadoutRank = 2; quality = 1; price = 70; };
	class optic_ACO_grn								{ traderRank = 0; loadoutRank = 2; quality = 1; price = 70; };
	class optic_ACO_grn_smg							{ traderRank = 0; loadoutRank = 2; quality = 1; price = 70; };
	class optic_Aco_smg								{ traderRank = 0; loadoutRank = 2; quality = 1; price = 70; };
	class optic_AMS									{ traderRank = 0; loadoutRank = 2; quality = 5; price = 300; };
	class optic_AMS_khk								{ traderRank = 0; loadoutRank = 2; quality = 5; price = 300; };
	class optic_AMS_snd								{ traderRank = 0; loadoutRank = 2; quality = 5; price = 300; };
	class optic_Arco								{ traderRank = 0; loadoutRank = 2; quality = 1; price = 100; };
	class optic_DMS									{ traderRank = 0; loadoutRank = 2; quality = 2; price = 150; };
	class optic_Hamr								{ traderRank = 0; loadoutRank = 2; quality = 3; price = 200; };
	class optic_Holosight							{ traderRank = 0; loadoutRank = 2; quality = 1; price = 50; };
	class optic_Holosight_smg						{ traderRank = 0; loadoutRank = 2; quality = 1; price = 50; };
	class optic_KHS_blk								{ traderRank = 0; loadoutRank = 2; quality = 4; price = 300; };
	class optic_KHS_hex								{ traderRank = 0; loadoutRank = 2; quality = 4; price = 300; };
	class optic_KHS_old								{ traderRank = 0; loadoutRank = 2; quality = 4; price = 300; };
	class optic_KHS_tan								{ traderRank = 0; loadoutRank = 2; quality = 4; price = 300; };
	class optic_LRPS								{ traderRank = 0; loadoutRank = 2; quality = 5; price = 300; };
	class optic_MRCO								{ traderRank = 0; loadoutRank = 2; quality = 1; price = 100; };
	class optic_MRD									{ traderRank = 0; loadoutRank = 2; quality = 1; price = 10; };
	class optic_Nightstalker						{ traderRank = 5; loadoutRank = 2; quality = 6; price = 1000; };
	class optic_NVS									{ traderRank = 5; loadoutRank = 2; quality = 4; price = 500; };
	class optic_SOS									{ traderRank = 0; loadoutRank = 2; quality = 2; price = 200; };
	class optic_tws									{ traderRank = 5; loadoutRank = 10; quality = QUALITY_LEVEL_9000; price = 1500; };
	class optic_tws_mg								{ traderRank = 5; loadoutRank = 10; quality = QUALITY_LEVEL_9000; price = 1500; };
	class optic_Yorris								{ traderRank = 0; loadoutRank = 2; quality = 1; price = 10; };
	class Elcan_epoch 									{ traderRank = 0; loadoutRank = 100; quality = 1; price = 150; };
	class Elcan_reflex_epoch 							{ traderRank = 0; loadoutRank = 100; quality = 1; price = 150; };
	
	///////////////////////////////////////////////////////////////////////////////
	// Metals and Gems
	///////////////////////////////////////////////////////////////////////////////
	class eXpoch_ItemBriefcaseE 						{ traderRank = 10; loadoutRank = 100; quality = 1; price = 50; };
	class eXpoch_ItemBriefcaseGold100oz					{ traderRank = 10; loadoutRank = 100; quality = 1; price = 10000; sellPrice = 10000;};
	class eXpoch_ItemGoldBar10oz 						{ traderRank = 10; loadoutRank = 100; quality = 1; price = 1000; sellPrice = 1000;};
	class eXpoch_ItemGoldBar 							{ traderRank = 10; loadoutRank = 100; quality = 1; price = 100; sellPrice = 100;};
	class eXpoch_PartOreGold 							{ traderRank = 10; loadoutRank = 100; quality = 1; price = 10; };
	class eXpoch_ItemSilverBar 							{ traderRank = 10; loadoutRank = 100; quality = 1; price = 10; sellPrice = 10;};
	class eXpoch_PartOreSilver 							{ traderRank = 100; loadoutRank = 100; quality = 1; price = 7; };
	class eXpoch_PartOre 								{ traderRank = 100; loadoutRank = 100; quality = 1; price = 5; };
	class eXpoch_ItemAluminumBar 						{ traderRank = 0; loadoutRank = 100; quality = 1; price = 2; };
	class eXpoch_ItemCopperBar 							{ traderRank = 0; loadoutRank = 100; quality = 1; price = 1; };
	class eXpoch_ItemTinBar 							{ traderRank = 0; loadoutRank = 100; quality = 1; price = 1; };
	class eXpoch_ItemEmptyTin 							{ traderRank = 100; loadoutRank = 100; quality = 1; price = 20; };
	
	class eXpoch_ItemTopaz 								{ traderRank = 100; loadoutRank = 100; quality = 1; price = 1000000;  sellPrice = 100000;};
	class eXpoch_ItemOnyx 								{ traderRank = 100; loadoutRank = 100; quality = 1; price = 1000000;  sellPrice = 100000;};
	class eXpoch_ItemSapphire 							{ traderRank = 100; loadoutRank = 100; quality = 1; price = 1000000;  sellPrice = 100000;};
	class eXpoch_ItemAmethyst 							{ traderRank = 100; loadoutRank = 100; quality = 1; price = 1000000;  sellPrice = 100000;};
	class eXpoch_ItemEmerald 							{ traderRank = 100; loadoutRank = 100; quality = 1; price = 1000000;  sellPrice = 100000;};
	class eXpoch_ItemCitrine 							{ traderRank = 100; loadoutRank = 100; quality = 1; price = 1000000;  sellPrice = 100000;};
	class eXpoch_ItemRuby 								{ traderRank = 100; loadoutRank = 100; quality = 1; price = 1000000;  sellPrice = 100000;};
	class eXpoch_ItemQuartz 							{ traderRank = 100; loadoutRank = 100; quality = 1; price = 1000000;  sellPrice = 100000;};
	class eXpoch_ItemJade 								{ traderRank = 100; loadoutRank = 100; quality = 1; price = 1000000;  sellPrice = 100000;};
	class eXpoch_ItemGarnet 							{ traderRank = 100; loadoutRank = 100; quality = 1; price = 1000000;  sellPrice = 100000;};
	
	///////////////////////////////////////////////////////////////////////////////
	// Hardware
	///////////////////////////////////////////////////////////////////////////////
	class Exile_Item_Rope							{ traderRank = 0; loadoutRank = 100; quality = 1; price = 20; };
	class Exile_Item_DuctTape						{ traderRank = 0; loadoutRank = 100; quality = 1; price = 300; };
	class Exile_Item_ExtensionCord					{ traderRank = 0; loadoutRank = 100; quality = 1; price = 40; };
	class Exile_Item_FuelCanisterEmpty				{ traderRank = 0; loadoutRank = 100; quality = 1; price = 40; };
	class Exile_Item_JunkMetal						{ traderRank = 0; loadoutRank = 100; quality = 1; price = 400; };
	class Exile_Item_LightBulb						{ traderRank = 0; loadoutRank = 100; quality = 1; price = 20; };
	class Exile_Item_MetalBoard						{ traderRank = 0; loadoutRank = 100; quality = 1; price = 600; };
	class Exile_Item_MetalHedgehogKit				{ traderRank = 0; loadoutRank = 100; quality = 1; price = 1200; };
	class Exile_Item_SafeKit						{ traderRank = 0; loadoutRank = 100; quality = 4; price = 25000; };
	class Exile_Item_CodeLock						{ traderRank = 0; loadoutRank = 100; quality = 1; price = 5000; };
	class Exile_Item_Laptop							{ traderRank = 5; loadoutRank = 100; quality = 2; price = 9000; };
	class Exile_Item_BaseCameraKit					{ traderRank = 10; loadoutRank = 100; quality = 2; price = 5000; };
	class Exile_Item_CamoTentKit					{ traderRank = 0; loadoutRank = 100; quality = 1; price = 250; };
	class Exile_Item_MetalPole						{ traderRank = 0; loadoutRank = 100; quality = 1; price = 800; };
	class Exile_Item_MetalScrews					{ traderRank = 0; loadoutRank = 100; quality = 1; price = 100; };
	class Exile_Item_MetalWire						{ traderRank = 0; loadoutRank = 100; quality = 1; price = 100; };
	class Exile_Item_Cement							{ traderRank = 5; loadoutRank = 100; quality = 1; price = 60; };
	class Exile_Item_Sand							{ traderRank = 5; loadoutRank = 100; quality = 1; price = 60; };
	class Exile_Item_CarWheel						{ traderRank = 0; loadoutRank = 100; quality = 1; price = 1000; };
	
	class CSGAS 									{ traderRank = 0; loadoutRank = 100; quality = 1; price = 20; };
	class eXpoch_ItemKiloHemp 							{ traderRank = 10; loadoutRank = 100; quality = 1; price = 5000; };
	class eXpoch_ItemMixOil 							{ traderRank = 0; loadoutRank = 100; quality = 1; price = 100; };
	class eXpoch_EnergyPack 							{ traderRank = 0; loadoutRank = 100; quality = 1; price = 20; };
	class eXpoch_EnergyPackLg 						{ traderRank = 0; loadoutRank = 100; quality = 1; price = 20; };
	class eXpoch_CircuitParts 							{ traderRank = 5; loadoutRank = 100; quality = 1; price = 2000; };
	class eXpoch_ItemLockbox 							{ traderRank = 0; loadoutRank = 100; quality = 1; price = 5000; };
	class eXpoch_ItemSafe 								{ traderRank = 5; loadoutRank = 100; quality = 1; price = 25000; };
	class eXpoch_KitTiPi 								{ traderRank = 0; loadoutRank = 100; quality = 1; price = 1250; };
	class eXpoch_KitShelf 								{ traderRank = 0; loadoutRank = 100; quality = 1; price = 750; };
	class eXpoch_lighter_epoch 							{ traderRank = 0; loadoutRank = 100; quality = 1; price = 250; };
	class eXpoch_ItemBarrelF 							{ traderRank = 5; loadoutRank = 100; quality = 1; price = 20; };
	class eXpoch_ItemBarrelE 							{ traderRank = 5; loadoutRank = 100; quality = 1; price = 20; };
	class eXpoch_ItemPipe 								{ traderRank = 0; loadoutRank = 100; quality = 1; price = 800; };
	class eXpoch_ItemPlywoodPack 						{ traderRank = 0; loadoutRank = 100; quality = 1; price = 20; };
	class eXpoch_ItemComboLock 							{ traderRank = 0; loadoutRank = 100; quality = 1; price = 5000; };
	class eXpoch_PartPlankPack 							{ traderRank = 0; loadoutRank = 100; quality = 1; price = 20; };
	class eXpoch_CinderBlocks 							{ traderRank = 0; loadoutRank = 100; quality = 1; price = 20; };
	class eXpoch_MortarBucket 							{ traderRank = 0; loadoutRank = 100; quality = 1; price = 20; };
	class eXpoch_ItemRock 								{ traderRank = 0; loadoutRank = 100; quality = 1; price = 20; };
	class eXpoch_ItemStick 								{ traderRank = 0; loadoutRank = 100; quality = 1; price = 20; };
	class eXpoch_ItemRope 								{ traderRank = 0; loadoutRank = 100; quality = 1; price = 20; };
	class eXpoch_ItemPacked 							{ traderRank = 10; loadoutRank = 100; quality = 1; price = 20; };
	class eXpoch_ItemSolar 								{ traderRank = 0; loadoutRank = 100; quality = 1; price = 20; };
	class eXpoch_ItemCables 							{ traderRank = 0; loadoutRank = 100; quality = 1; price = 20; };
	class eXpoch_ItemBattery 							{ traderRank = 0; loadoutRank = 100; quality = 1; price = 20; };
	class eXpoch_ItemScraps 							{ traderRank = 0; loadoutRank = 100; quality = 1; price = 400; };
	class eXpoch_ItemCorrugated 						{ traderRank = 0; loadoutRank = 100; quality = 1; price = 750; };
	class eXpoch_ItemCorrugatedLg 						{ traderRank = 0; loadoutRank = 100; quality = 1; price = 1500; };
	class eXpoch_WoodLog_EPOCH 							{ traderRank = 0; loadoutRank = 100; quality = 1; price = 20; };
	class eXpoch_PaintCanBlk 							{ traderRank = 5; loadoutRank = 100; quality = 1; price = 200; };
	class eXpoch_PaintCanBlu 							{ traderRank = 5; loadoutRank = 100; quality = 1; price = 200; };
	class eXpoch_PaintCanBrn 							{ traderRank = 5; loadoutRank = 100; quality = 1; price = 200; };
	class eXpoch_PaintCanGrn 							{ traderRank = 5; loadoutRank = 100; quality = 1; price = 200; };
	class eXpoch_PaintCanOra 							{ traderRank = 5; loadoutRank = 100; quality = 1; price = 200; };
	class eXpoch_PaintCanPur 							{ traderRank = 5; loadoutRank = 100; quality = 1; price = 200; };
	class eXpoch_PaintCanRed 							{ traderRank = 5; loadoutRank = 100; quality = 1; price = 200; };
	class eXpoch_PaintCanTeal 							{ traderRank = 5; loadoutRank = 100; quality = 1; price = 200; };
	class eXpoch_PaintCanYel 							{ traderRank = 5; loadoutRank = 100; quality = 1; price = 200; };
	class eXpoch_KitSpikeTrap 							{ traderRank = 5; loadoutRank = 100; quality = 1; price = 20; };
	class eXpoch_KitMetalTrap 							{ traderRank = 5; loadoutRank = 100; quality = 1; price = 20; };
	class eXpoch_KitStudWall 							{ traderRank = 0; loadoutRank = 100; quality = 1; price = 20; };
	class eXpoch_KitLargeWoodWall 						{ traderRank = 5; loadoutRank = 100; quality = 1; price = 20; };
	class eXpoch_KitLargeCorrugatedWall 				{ traderRank = 10; loadoutRank = 100; quality = 1; price = 20; };
	class eXpoch_KitLargeWoodWallDoorway 				{ traderRank = 10; loadoutRank = 100; quality = 1; price = 20; };
	class eXpoch_KitLargeCorrugatedWallDoorway 			{ traderRank = 10; loadoutRank = 100; quality = 1; price = 20; };
	class eXpoch_KitLargeWoodWallwDoor 					{ traderRank = 10; loadoutRank = 100; quality = 1; price = 20; };
	class eXpoch_KitLargeCorrugatedWallwDoor 			{ traderRank = 10; loadoutRank = 100; quality = 1; price = 20; };
	class eXpoch_KitLargeWoodWallwDoorwLock 			{ traderRank = 10; loadoutRank = 100; quality = 1; price = 20; };
	class eXpoch_KitLargeCorrugatedWallwDoorwLock 		{ traderRank = 10; loadoutRank = 100; quality = 1; price = 20; };
	class eXpoch_KitWoodFloor 							{ traderRank = 0; loadoutRank = 100; quality = 1; price = 20; };
	class eXpoch_KitMetalFloor 							{ traderRank = 5; loadoutRank = 100; quality = 1; price = 20; };
	class eXpoch_KitWoodStairs 							{ traderRank = 0; loadoutRank = 100; quality = 1; price = 20; };
	class eXpoch_KitWoodStairs2 						{ traderRank = 5; loadoutRank = 100; quality = 1; price = 20; };
	class eXpoch_KitWoodTower 							{ traderRank = 100; loadoutRank = 100; quality = 1; price = 20; };
	class eXpoch_KitWoodRamp 							{ traderRank = 5; loadoutRank = 100; quality = 1; price = 20; };
	class eXpoch_KitTankTrap 							{ traderRank = 5; loadoutRank = 100; quality = 1; price = 20; };
	class eXpoch_KitHesco3 								{ traderRank = 0; loadoutRank = 100; quality = 1; price = 20; };
	class eXpoch_KitWoodLadder 							{ traderRank = 0; loadoutRank = 100; quality = 1; price = 20; };
	class eXpoch_KitFoundation 							{ traderRank = 0; loadoutRank = 100; quality = 1; price = 20; };
	class eXpoch_KitWoodFoundation 						{ traderRank = 0; loadoutRank = 100; quality = 1; price = 20; };
	class eXpoch_KitSolarGen 							{ traderRank = 5; loadoutRank = 100; quality = 1; price = 20; };
	class eXpoch_KitPlotPole 							{ traderRank = 100; loadoutRank = 100; quality = 1; price = 20; };
	class eXpoch_KitHalfCinderWall 						{ traderRank = 0; loadoutRank = 100; quality = 1; price = 20; };
	class eXpoch_KitCinderWall 							{ traderRank = 0; loadoutRank = 100; quality = 1; price = 20; };
	class eXpoch_KitCinderWallGarage 					{ traderRank = 0; loadoutRank = 100; quality = 1; price = 20; };
	
	///////////////////////////////////////////////////////////////////////////////
	// Food
	///////////////////////////////////////////////////////////////////////////////
	class Exile_Item_EMRE							{ traderRank = 0; loadoutRank = 100; quality = 3; price = 54; }; //75, 60
	class Exile_Item_GloriousKnakworst				{ traderRank = 0; loadoutRank = 100; quality = 3; price = 40; }; //60, 30
	class Exile_Item_Surstromming					{ traderRank = 0; loadoutRank = 100; quality = 3; price = 34; }; //55, 25
	class Exile_Item_SausageGravy					{ traderRank = 0; loadoutRank = 100; quality = 3; price = 30; }; //50, 25
	class Exile_Item_Catfood						{ traderRank = 0; loadoutRank = 100; quality = 2; price = 24; }; //40, 40
	class Exile_Item_ChristmasTinner				{ traderRank = 0; loadoutRank = 100; quality = 3; price = 20; }; //40, 60
	class Exile_Item_BBQSandwich					{ traderRank = 0; loadoutRank = 100; quality = 3; price = 20; }; //40, 60
	class Exile_Item_MacasCheese					{ traderRank = 0; loadoutRank = 100; quality = 3; price = 20; }; //40, 60
	class Exile_Item_Dogfood						{ traderRank = 0; loadoutRank = 100; quality = 2; price = 18; }; //30, 30
	class Exile_Item_BeefParts						{ traderRank = 0; loadoutRank = 100; quality = 2; price = 18; }; //30, 30
	class Exile_Item_Cheathas						{ traderRank = 0; loadoutRank = 100; quality = 2; price = 18; }; //30, 30
	class Exile_Item_Noodles						{ traderRank = 0; loadoutRank = 100; quality = 1; price = 14; }; //25, 50
	class Exile_Item_SeedAstics						{ traderRank = 0; loadoutRank = 100; quality = 1; price = 12; }; //20, 40
	class Exile_Item_Raisins						{ traderRank = 0; loadoutRank = 100; quality = 1; price = 10; }; //15, 30
	class Exile_Item_Moobar							{ traderRank = 0; loadoutRank = 100; quality = 1; price = 8; }; //10, 30
	class Exile_Item_InstantCoffee					{ traderRank = 0; loadoutRank = 100; quality = 1; price = 20; }; //5, 10
	class Exile_Item_Can_Empty						{ traderRank = 0; loadoutRank = 100; quality = 1; price = 1; sellPrice = 1; };
	
	class eXpoch_sardines_epoch 						{ traderRank = 0; loadoutRank = 100; quality = 1; price = 24; };
	class eXpoch_meatballs_epoch 						{ traderRank = 0; loadoutRank = 100; quality = 1; price = 60; };
	class eXpoch_scam_epoch 							{ traderRank = 0; loadoutRank = 100; quality = 1; price = 40; };
	class eXpoch_sweetcorn_epoch 						{ traderRank = 0; loadoutRank = 100; quality = 1; price = 18; };
	class eXpoch_FoodMeeps 								{ traderRank = 0; loadoutRank = 100; quality = 1; price = 10; };
	class eXpoch_FoodSnooter 							{ traderRank = 0; loadoutRank = 100; quality = 1; price = 10; };
	class eXpoch_FoodWalkNSons 							{ traderRank = 0; loadoutRank = 100; quality = 1; price = 20; };
	class eXpoch_Poppy 									{ traderRank = 0; loadoutRank = 100; quality = 1; price = 35; };
	class eXpoch_Goldenseal 							{ traderRank = 0; loadoutRank = 100; quality = 1; price = 45; };
	class eXpoch_Pumpkin 								{ traderRank = 0; loadoutRank = 100; quality = 1; price = 30; };
	class eXpoch_ItemCoolerE 							{ traderRank = 5; loadoutRank = 100; quality = 1; price = 50; };
	class eXpoch_ItemCooler0 							{ traderRank = 5; loadoutRank = 100; quality = 1; price = 200; };
	class eXpoch_ItemCooler1 							{ traderRank = 5; loadoutRank = 100; quality = 1; price = 225; };
	class eXpoch_ItemCooler2 							{ traderRank = 5; loadoutRank = 100; quality = 1; price = 250; };
	class eXpoch_ItemCooler3 							{ traderRank = 5; loadoutRank = 100; quality = 1; price = 275; };
	class eXpoch_ItemCooler4 							{ traderRank = 5; loadoutRank = 100; quality = 1; price = 300; };
	
	///////////////////////////////////////////////////////////////////////////////
	// Hunting and Fishing
	///////////////////////////////////////////////////////////////////////////////
	class eXpoch_ItemBurlap 							{ traderRank = 0; loadoutRank = 100; quality = 1; price = 200; };
	class eXpoch_ItemTrout 								{ traderRank = 0; loadoutRank = 100; quality = 1; price = 50; };
	class eXpoch_ItemSeaBass 							{ traderRank = 0; loadoutRank = 100; quality = 1; price = 75; };
	class eXpoch_ItemTuna 								{ traderRank = 0; loadoutRank = 100; quality = 1; price = 100; };
	class eXpoch_ItemTroutCooked 						{ traderRank = 10; loadoutRank = 100; quality = 1; price = 80; };
	class eXpoch_ItemSeaBassCooked 						{ traderRank = 10; loadoutRank = 100; quality = 1; price = 150; };
	class eXpoch_ItemTunaCooked 						{ traderRank = 10; loadoutRank = 100; quality = 1; price = 200; };
	class eXpoch_FoodBioMeat 							{ traderRank = 0; loadoutRank = 100; quality = 1; price = 50; };
	class eXpoch_Pelt_EPOCH 							{ traderRank = 0; loadoutRank = 100; quality = 1; price = 100; };
	class eXpoch_Venom_EPOCH 							{ traderRank = 0; loadoutRank = 100; quality = 1; price = 30; };
	class eXpoch_SnakeCarcass_EPOCH 					{ traderRank = 0; loadoutRank = 100; quality = 1; price = 40; };
	class eXpoch_SnakeMeat_EPOCH 						{ traderRank = 0; loadoutRank = 100; quality = 1; price = 50; };
	class eXpoch_RabbitCarcass_EPOCH 					{ traderRank = 0; loadoutRank = 100; quality = 1; price = 50; };
	class eXpoch_CookedRabbit_EPOCH 					{ traderRank = 10; loadoutRank = 100; quality = 1; price = 70; };
	class eXpoch_ChickenCarcass_EPOCH 					{ traderRank = 0; loadoutRank = 100; quality = 1; price = 60; };
	class eXpoch_CookedChicken_EPOCH 					{ traderRank = 10; loadoutRank = 100; quality = 1; price = 80; };
	class eXpoch_GoatCarcass_EPOCH 						{ traderRank = 0; loadoutRank = 100; quality = 1; price = 70; };
	class eXpoch_DogCarcass_EPOCH 						{ traderRank = 0; loadoutRank = 100; quality = 1; price = 70; };
	class eXpoch_CookedGoat_EPOCH 						{ traderRank = 10; loadoutRank = 100; quality = 1; price = 100; };
	class eXpoch_CookedDog_EPOCH 						{ traderRank = 10; loadoutRank = 100; quality = 1; price = 100; };
	class eXpoch_SheepCarcass_EPOCH 					{ traderRank = 0; loadoutRank = 100; quality = 1; price = 70; };
	class eXpoch_CookedSheep_EPOCH 						{ traderRank = 10; loadoutRank = 100; quality = 1; price = 100; };
	
	///////////////////////////////////////////////////////////////////////////////
	// Drinks
	///////////////////////////////////////////////////////////////////////////////
	class Exile_Item_PlasticBottleCoffee	 		{ traderRank = 0; loadoutRank = 100; quality = 3; price = 70; sellPrice = 10; };//100, 60
	class Exile_Item_PowerDrink						{ traderRank = 0; loadoutRank = 100; quality = 3; price = 60; }; //95, 10
	class Exile_Item_PlasticBottleFreshWater 		{ traderRank = 10; loadoutRank = 100; quality = 2; price = 50; sellPrice = 4; }; //80, 15
	class Exile_Item_Beer 							{ traderRank = 5; loadoutRank = 100; quality = 1; price = 50; }; //75, 30
	class Exile_Item_EnergyDrink					{ traderRank = 5; loadoutRank = 100; quality = 1; price = 40; }; //75, 20
	class Exile_Item_ChocolateMilk					{ traderRank = 5; loadoutRank = 100; quality = 1; price = 25; }; //75, 20
	class Exile_Item_MountainDupe					{ traderRank = 5; loadoutRank = 100; quality = 1; price = 30; }; //50, 20
	class Exile_Item_PlasticBottleEmpty				{ traderRank = 0; loadoutRank = 100; quality = 1; price = 4; };
	class eXpoch_ItemSodaAlpineDude 					{ traderRank = 0; loadoutRank = 100; quality = 1; price = 30; };
	class eXpoch_honey_epoch 							{ traderRank = 0; loadoutRank = 100; quality = 1; price = 50; };
	class eXpoch_emptyjar_epoch 						{ traderRank = 0; loadoutRank = 100; quality = 1; price = 20; };
	class eXpoch_ItemSodaRbull 							{ traderRank = 0; loadoutRank = 100; quality = 1; price = 40; };
	class eXpoch_ItemSodaOrangeSherbet 					{ traderRank = 0; loadoutRank = 100; quality = 1; price = 30; };
	class eXpoch_ItemSodaPurple 						{ traderRank = 0; loadoutRank = 100; quality = 1; price = 30; };
	class eXpoch_ItemSodaMocha 							{ traderRank = 0; loadoutRank = 100; quality = 1; price = 40; };
	class eXpoch_ItemSodaBurst 							{ traderRank = 0; loadoutRank = 100; quality = 1; price = 30; };
	class eXpoch_WhiskeyNoodle 							{ traderRank = 0; loadoutRank = 100; quality = 1; price = 50; };

	///////////////////////////////////////////////////////////////////////////////
	// First Aid
	///////////////////////////////////////////////////////////////////////////////	
	class Exile_Item_InstaDoc                       { traderRank = 0; loadoutRank = 100; quality = 5; price = 1250; };
	class Exile_Item_Vishpirin						{ traderRank = 0; loadoutRank = 100; quality = 3; price = 300; };
	class Exile_Item_Bandage	                    { traderRank = 0; loadoutRank = 100; quality = 2; price = 100; };
	class Exile_Item_Heatpack	                    { traderRank = 0; loadoutRank = 100; quality = 1; price = 50; };
	
	class Exile_Item_Defibrillator				{ traderRank = 100; loadoutRank = 100; quality = 1; price = 7500; };
	
	class eXpoch_FAK 									{ traderRank = 100; loadoutRank = 100; quality = 1; price = 1000; };
	class eXpoch_Towelette 								{ traderRank = 0; loadoutRank = 100; quality = 1; price = 100; };
	class eXpoch_HeatPack 								{ traderRank = 0; loadoutRank = 100; quality = 1; price = 50; };
	class eXpoch_ColdPack 								{ traderRank = 0; loadoutRank = 100; quality = 1; price = 50; };
	
	///////////////////////////////////////////////////////////////////////////////
	// Tools
	///////////////////////////////////////////////////////////////////////////////
	class Exile_Item_Matches 						{ traderRank = 0; loadoutRank = 100; quality = 1; price = 60; };
	class Exile_Item_CookingPot						{ traderRank = 0; loadoutRank = 100; quality = 2; price = 80; };
	class Exile_Melee_Axe							{ traderRank = 0; loadoutRank = 100; quality = 2; price = 100; };
	class Exile_Melee_SledgeHammmer					{ traderRank = 0; loadoutRank = 100; quality = 3; price = 500; };
	class Exile_Item_CanOpener						{ traderRank = 0; loadoutRank = 100; quality = 1; price = 80; };
	class Exile_Item_Handsaw						{ traderRank = 0; loadoutRank = 100; quality = 2; price = 500; };
	class Exile_Item_Pliers							{ traderRank = 0; loadoutRank = 100; quality = 2; price = 350; };
	class Exile_Item_Grinder						{ traderRank = 0; loadoutRank = 100; quality = 2; price = 1250; };
	class Exile_Item_Foolbox						{ traderRank = 0; loadoutRank = 100; quality = 2; price = 4000; };
	class Exile_Item_CordlessScrewdriver			{ traderRank = 0; loadoutRank = 100; quality = 1; price = 750; };
	class Exile_Item_FireExtinguisher				{ traderRank = 0; loadoutRank = 100; quality = 1; price = 650; };
	class Exile_Item_Hammer							{ traderRank = 0; loadoutRank = 100; quality = 1; price = 600; };
	class Exile_Item_OilCanister					{ traderRank = 0; loadoutRank = 100; quality = 1; price = 1750; };
	class Exile_Item_Screwdriver					{ traderRank = 0; loadoutRank = 100; quality = 1; price = 250; };
	class Exile_Item_Shovel							{ traderRank = 0; loadoutRank = 100; quality = 1; price = 700; };
	class Exile_Item_Wrench							{ traderRank = 0; loadoutRank = 100; quality = 1; price = 250; };
	class Exile_Item_SleepingMat					{ traderRank = 0; loadoutRank = 100; quality = 1; price = 1250; };
	class Exile_Item_ToiletPaper					{ traderRank = 0; loadoutRank = 100; quality = 1; price = 5; };
	class Exile_Item_ZipTie							{ traderRank = 0; loadoutRank = 100; quality = 1; price = 250; };
	class ChainSawB										{ traderRank = 5; loadoutRank = 4; quality = 1; price = 6000; };
	class ChainSawG										{ traderRank = 5; loadoutRank = 4; quality = 1; price = 6000; };
	class ChainSawP										{ traderRank = 5; loadoutRank = 4; quality = 1; price = 6000; };
	class ChainSawR										{ traderRank = 5; loadoutRank = 4; quality = 1; price = 6000; };
	class eXpoch_ItemHotwire 							{ traderRank = 5; loadoutRank = 100; quality = 1; price = 1000; };
	class eXpoch_ItemKeyKit 							{ traderRank = 10; loadoutRank = 100; quality = 1; price = 2500; };
	class eXpoch_ItemKey 								{ traderRank = 100; loadoutRank = 100; quality = 1; price = 250; sellPrice = 50; };
	class eXpoch_ItemKeyBlue 							{ traderRank = 100; loadoutRank = 100; quality = 1; price = 250; sellPrice = 50; };
	class eXpoch_ItemKeyGreen 							{ traderRank = 100; loadoutRank = 100; quality = 1; price = 250; sellPrice = 50; };
	class eXpoch_ItemKeyRed 							{ traderRank = 100; loadoutRank = 100; quality = 1; price = 250; sellPrice = 50; };
	class eXpoch_ItemKeyYellow 							{ traderRank = 100; loadoutRank = 100; quality = 1; price = 250; sellPrice = 50; };
	class EpochRadio0									{ traderRank = 100; loadoutRank = 100; quality = 1; price = 20; };
	class EpochRadio1									{ traderRank = 100; loadoutRank = 100; quality = 1; price = 20; };
	class EpochRadio2									{ traderRank = 100; loadoutRank = 100; quality = 1; price = 20; };
	class EpochRadio3									{ traderRank = 100; loadoutRank = 100; quality = 1; price = 20; };
	class EpochRadio4									{ traderRank = 100; loadoutRank = 100; quality = 1; price = 20; };
	class EpochRadio5									{ traderRank = 100; loadoutRank = 100; quality = 1; price = 20; };
	class EpochRadio6									{ traderRank = 100; loadoutRank = 100; quality = 1; price = 20; };
	class EpochRadio7									{ traderRank = 100; loadoutRank = 100; quality = 1; price = 20; };
	class EpochRadio8									{ traderRank = 100; loadoutRank = 100; quality = 1; price = 20; };
	class EpochRadio9									{ traderRank = 100; loadoutRank = 100; quality = 1; price = 20; };
	
	///////////////////////////////////////////////////////////////////////////////
	// Melee Weapons
	///////////////////////////////////////////////////////////////////////////////
	class MeleeSword 									{ traderRank = 0; loadoutRank = 0; quality = 1; price = 2500; };
	class MeleeMaul 									{ traderRank = 0; loadoutRank = 0; quality = 1; price = 1250; };
	class MeleeRod 										{ traderRank = 0; loadoutRank = 0; quality = 1; price = 3000; };
	class Hatchet										{ traderRank = 0; loadoutRank = 0; quality = 1; price = 3000; };
	class CrudeHatchet									{ traderRank = 0; loadoutRank = 0; quality = 1; price = 1750; };
	class MeleeSledge									{ traderRank = 0; loadoutRank = 0; quality = 1; price = 6000; };
	class WoodClub										{ traderRank = 0; loadoutRank = 0; quality = 1; price = 1000; };
	class Plunger										{ traderRank = 0; loadoutRank = 0; quality = 1; price = 700; };
	
	///////////////////////////////////////////////////////////////////////////////
	// Navigation
	///////////////////////////////////////////////////////////////////////////////
	class ItemWatch									{ traderRank = 0; loadoutRank = 100; quality = 1; price = 2; };	
	class ItemGPS									{ traderRank = 0; loadoutRank = 100; quality = 2; price = 40; };
	class ItemMap									{ traderRank = 0; loadoutRank = 100; quality = 1; price = 6; };
	class ItemCompass								{ traderRank = 0; loadoutRank = 100; quality = 1; price = 6; };
	class ItemRadio									{ traderRank = 0; loadoutRank = 100; quality = 1; price = 40; };
	class Binocular									{ traderRank = 0; loadoutRank = 100; quality = 1; price = 40; };
	class Rangefinder								{ traderRank = 0; loadoutRank = 100; quality = 3; price = 200; };
	class Laserdesignator							{ traderRank = 0; loadoutRank = 100; quality = 6; price = 750; };
	class Laserdesignator_02						{ traderRank = 0; loadoutRank = 100; quality = 6; price = 750; };
	class Laserdesignator_03						{ traderRank = 0; loadoutRank = 100; quality = 6; price = 750; };
	class NVGoggles									{ traderRank = 0; loadoutRank = 100; quality = 2; price = 100; };
	class NVGoggles_INDEP							{ traderRank = 0; loadoutRank = 100; quality = 2; price = 100; };
	class NVGoggles_OPFOR							{ traderRank = 0; loadoutRank = 100; quality = 2; price = 100; };
	class Exile_Item_XM8							{ traderRank = 0; loadoutRank = 100; quality = 2; price = 20; };
	class Exile_Item_MobilePhone					{ traderRank = 0; loadoutRank = 100; quality = 6; price = 500; };
	
	///////////////////////////////////////////////////////////////////////////////
	// Documents, Upgrades and mission special items
	///////////////////////////////////////////////////////////////////////////////
	class eXpoch_ItemDoc1 								{ traderRank = 100; loadoutRank = 100; quality = 1; price = 10000; sellPrice = 1000; };
	class eXpoch_ItemDoc2 								{ traderRank = 100; loadoutRank = 100; quality = 1; price = 10000; sellPrice = 1000; };
	class eXpoch_ItemDoc3 								{ traderRank = 100; loadoutRank = 100; quality = 1; price = 10000; sellPrice = 1000; };
	class eXpoch_ItemDoc4	 							{ traderRank = 100; loadoutRank = 100; quality = 1; price = 10000; sellPrice = 1000; };
	class eXpoch_ItemDoc5 								{ traderRank = 100; loadoutRank = 100; quality = 1; price = 10000; sellPrice = 1000; };
	class eXpoch_ItemDoc6 								{ traderRank = 100; loadoutRank = 100; quality = 1; price = 10000; sellPrice = 1000; };
	class eXpoch_ItemDoc7 								{ traderRank = 100; loadoutRank = 100; quality = 1; price = 10000; sellPrice = 1000; };
	class eXpoch_ItemDoc8 								{ traderRank = 100; loadoutRank = 100; quality = 1; price = 10000; sellPrice = 1000; };
	class eXpoch_ItemVehDoc1 							{ traderRank = 100; loadoutRank = 100; quality = 1; price = 20000; sellPrice = 2000; };
	class eXpoch_ItemVehDoc2 							{ traderRank = 100; loadoutRank = 100; quality = 1; price = 20000; sellPrice = 2000; };
	class eXpoch_ItemVehDoc3 							{ traderRank = 100; loadoutRank = 100; quality = 1; price = 20000; sellPrice = 2000; };
	class eXpoch_ItemVehDoc4 							{ traderRank = 100; loadoutRank = 100; quality = 1; price = 20000; sellPrice = 2000; };
	class eXpoch_ItemDocument 							{ traderRank = 100; loadoutRank = 100; quality = 1; price = 50000; sellPrice = 5000; };
	class eXpoch_ItemDocumentMission 					{ traderRank = 100; loadoutRank = 100; quality = 1; price = 100000; sellPrice = 10000; };
	
	///////////////////////////////////////////////////////////////////////////////
	// Watch out for a Walter fart! He has gas!
	///////////////////////////////////////////////////////////////////////////////
	class Exile_Headgear_GasMask					{ traderRank = 0; loadoutRank = 10; quality = 4; price = 500; };

	///////////////////////////////////////////////////////////////////////////////
	// Rebreather
	///////////////////////////////////////////////////////////////////////////////
	class V_RebreatherB								{ traderRank = 0; loadoutRank = 4; quality = 2; price = 250; };
	class V_RebreatherIA							{ traderRank = 0; loadoutRank = 4; quality = 2; price = 250; };
	class V_RebreatherIR							{ traderRank = 0; loadoutRank = 4; quality = 2; price = 250; };

	///////////////////////////////////////////////////////////////////////////////
	// Pilot Stuff
	///////////////////////////////////////////////////////////////////////////////
	class B_Parachute								{ traderRank = 0; loadoutRank = 6; quality = 3; price = 150; };
	class H_CrewHelmetHeli_B						{ traderRank = 0; loadoutRank = 6; quality = 3; price = 150; };
	class H_CrewHelmetHeli_I						{ traderRank = 0; loadoutRank = 6; quality = 3; price = 150; };
	class H_CrewHelmetHeli_O						{ traderRank = 0; loadoutRank = 6; quality = 3; price = 150; };
	class H_HelmetCrew_I							{ traderRank = 0; loadoutRank = 6; quality = 3; price = 100; };
	class H_HelmetCrew_B							{ traderRank = 0; loadoutRank = 6; quality = 3; price = 100; };
	class H_HelmetCrew_O							{ traderRank = 0; loadoutRank = 6; quality = 3; price = 100; };
	class H_PilotHelmetHeli_B						{ traderRank = 0; loadoutRank = 4; quality = 4; price = 100; };
	class H_PilotHelmetHeli_I						{ traderRank = 0; loadoutRank = 4; quality = 4; price = 100; };
	class H_PilotHelmetHeli_O						{ traderRank = 0; loadoutRank = 4; quality = 4; price = 100; };
	class U_B_HeliPilotCoveralls					{ traderRank = 0; loadoutRank = 4; quality = 4; price = 80; };
	class U_B_PilotCoveralls						{ traderRank = 0; loadoutRank = 4; quality = 2; price = 60; };
	class U_I_HeliPilotCoveralls					{ traderRank = 0; loadoutRank = 4; quality = 2; price = 60; };
	class U_I_pilotCoveralls						{ traderRank = 0; loadoutRank = 4; quality = 2; price = 60; };
	class U_O_PilotCoveralls						{ traderRank = 0; loadoutRank = 4; quality = 2; price = 60; };
	class H_PilotHelmetFighter_B					{ traderRank = 0; loadoutRank = 6; quality = 5; price = 150; };
	class H_PilotHelmetFighter_I					{ traderRank = 0; loadoutRank = 6; quality = 5; price = 150; };
	class H_PilotHelmetFighter_O					{ traderRank = 0; loadoutRank = 6; quality = 5; price = 150; };

	///////////////////////////////////////////////////////////////////////////////
	// Backpacks
	///////////////////////////////////////////////////////////////////////////////
	class B_HuntingBackpack							{ traderRank = 0; loadoutRank = 2; quality = 3; price = 70; };
	class B_OutdoorPack_blk							{ traderRank = 0; loadoutRank = 0; quality = 1; price = 80; };
	class B_OutdoorPack_blu							{ traderRank = 0; loadoutRank = 0; quality = 1; price = 80; };
	class B_OutdoorPack_tan							{ traderRank = 0; loadoutRank = 0; quality = 1; price = 80; };
	class B_AssaultPack_blk							{ traderRank = 0; loadoutRank = 0; quality = 1; price = 90; };
	class B_AssaultPack_cbr							{ traderRank = 0; loadoutRank = 0; quality = 1; price = 90; };
	class B_AssaultPack_dgtl						{ traderRank = 0; loadoutRank = 0; quality = 1; price = 90; };
	class B_AssaultPack_khk							{ traderRank = 0; loadoutRank = 0; quality = 1; price = 90; };
	class B_AssaultPack_mcamo						{ traderRank = 0; loadoutRank = 0; quality = 1; price = 90; };
	class B_AssaultPack_rgr							{ traderRank = 0; loadoutRank = 0; quality = 1; price = 90; };
	class B_AssaultPack_sgg							{ traderRank = 0; loadoutRank = 0; quality = 1; price = 90; };
	class B_FieldPack_blk							{ traderRank = 0; loadoutRank = 3; quality = 2; price = 120; };
	class B_FieldPack_cbr							{ traderRank = 0; loadoutRank = 3; quality = 2; price = 120; };
	class B_FieldPack_ocamo							{ traderRank = 0; loadoutRank = 3; quality = 2; price = 120; };
	class B_FieldPack_oucamo						{ traderRank = 0; loadoutRank = 3; quality = 2; price = 120; };
	class B_TacticalPack_blk						{ traderRank = 0; loadoutRank = 3; quality = 2; price = 150; };
	class B_TacticalPack_rgr						{ traderRank = 0; loadoutRank = 3; quality = 2; price = 150; };
	class B_TacticalPack_ocamo						{ traderRank = 0; loadoutRank = 3; quality = 2; price = 150; };
	class B_TacticalPack_mcamo						{ traderRank = 0; loadoutRank = 3; quality = 2; price = 150; };
	class B_TacticalPack_oli						{ traderRank = 0; loadoutRank = 3; quality = 2; price = 150; };
	class B_Kitbag_cbr								{ traderRank = 0; loadoutRank = 3; quality = 3; price = 200; };
	class B_Kitbag_mcamo							{ traderRank = 0; loadoutRank = 3; quality = 3; price = 200; };
	class B_Kitbag_sgg								{ traderRank = 0; loadoutRank = 3; quality = 3; price = 200; };
	class B_Bergen_blk								{ traderRank = 0; loadoutRank = 3; quality = 3; price = 200; };
	class B_Bergen_mcamo							{ traderRank = 0; loadoutRank = 3; quality = 3; price = 200; };
	class B_Bergen_rgr								{ traderRank = 0; loadoutRank = 3; quality = 3; price = 200; };
	class B_Bergen_sgg								{ traderRank = 0; loadoutRank = 3; quality = 3; price = 200; };
	class B_Carryall_cbr							{ traderRank = 5; loadoutRank = 3; quality = 4; price = 550; };
	class B_Carryall_khk							{ traderRank = 5; loadoutRank = 3; quality = 4; price = 550; };
	class B_Carryall_mcamo							{ traderRank = 5; loadoutRank = 3; quality = 4; price = 550; };
	class B_Carryall_ocamo							{ traderRank = 5; loadoutRank = 3; quality = 4; price = 550; };
	class B_Carryall_oli							{ traderRank = 5; loadoutRank = 3; quality = 4; price = 550; };
	class B_Carryall_oucamo							{ traderRank = 5; loadoutRank = 3; quality = 4; price = 550; };

	///////////////////////////////////////////////////////////////////////////////
	// Ammunition
	///////////////////////////////////////////////////////////////////////////////
	class 100Rnd_65x39_caseless_mag 						{ traderRank = 0; loadoutRank = 100; quality = 2; price = 30; };
	class 100Rnd_65x39_caseless_mag_Tracer 					{ traderRank = 0; loadoutRank = 100; quality = 2; price = 40; };
	class 10Rnd_127x54_Mag 									{ traderRank = 0; loadoutRank = 100; quality = 4; price = 30; };
	// Broken in Arma
	class 10Rnd_338_Mag 									{ traderRank = 0; loadoutRank = 100; quality = 5; price = 30; };

	class 10Rnd_762x54_Mag 									{ traderRank = 0; loadoutRank = 100; quality = 3; price = 30; };
	//class 10Rnd_762x51_Mag { traderRank = 0; loadoutRank = 100; quality = 1; price = 30; };
	class 10Rnd_93x64_DMR_05_Mag 							{ traderRank = 0; loadoutRank = 100; quality = 4; price = 40; };
	class 11Rnd_45ACP_Mag 									{ traderRank = 0; loadoutRank = 100; quality = 1; price = 8; };
	class 150Rnd_762x54_Box 								{ traderRank = 0; loadoutRank = 100; quality = 3; price = 20; };
	class 150Rnd_762x54_Box_Tracer 							{ traderRank = 0; loadoutRank = 100; quality = 3; price = 30; };
	class 16Rnd_9x21_Mag 									{ traderRank = 0; loadoutRank = 100; quality = 1; price = 20; };
	class 200Rnd_65x39_cased_Box 							{ traderRank = 0; loadoutRank = 100; quality = 2; price = 30; };
	class 200Rnd_65x39_cased_Box_Tracer 					{ traderRank = 0; loadoutRank = 100; quality = 2; price = 30; };
	class 150Rnd_93x64_Mag 									{ traderRank = 0; loadoutRank = 100; quality = 6; price = 50; };
	class 130Rnd_338_Mag 									{ traderRank = 0; loadoutRank = 100; quality = 5; price = 40; };
	class 20Rnd_556x45_UW_mag 								{ traderRank = 0; loadoutRank = 100; quality = 1; price = 20; };
	class 20Rnd_762x51_Mag 									{ traderRank = 0; loadoutRank = 100; quality = 2; price = 20; };
	class 30Rnd_45ACP_Mag_SMG_01 							{ traderRank = 0; loadoutRank = 100; quality = 1; price = 10; };
	class 30Rnd_45ACP_Mag_SMG_01_Tracer_Green 				{ traderRank = 0; loadoutRank = 100; quality = 1; price = 10; };
	class 30Rnd_45ACP_Mag_SMG_01_Tracer_Yellow				{ traderRank = 0; loadoutRank = 100; quality = 1; price = 10; };
	class 30Rnd_45ACP_Mag_SMG_01_Tracer_Red					{ traderRank = 0; loadoutRank = 100; quality = 1; price = 10; };
	class 30Rnd_556x45_Stanag 								{ traderRank = 0; loadoutRank = 100; quality = 1; price = 20; };
	class 30Rnd_556x45_Stanag_Tracer_Green 					{ traderRank = 0; loadoutRank = 100; quality = 1; price = 20; };
	class 30Rnd_556x45_Stanag_green  						{ traderRank = 0; loadoutRank = 100; quality = 1; price = 20; };
	class 30Rnd_556x45_Stanag_Tracer_Red 					{ traderRank = 0; loadoutRank = 100; quality = 1; price = 20; };
	class 30Rnd_556x45_Stanag_Tracer_Yellow 				{ traderRank = 0; loadoutRank = 100; quality = 1; price = 20; };
	class 30Rnd_556x45_Stanag_red 							{ traderRank = 0; loadoutRank = 100; quality = 1; price = 20; };
	class 30Rnd_65x39_caseless_green 						{ traderRank = 0; loadoutRank = 100; quality = 2; price = 20; };
	class 30Rnd_65x39_caseless_green_mag_Tracer 			{ traderRank = 0; loadoutRank = 100; quality = 2; price = 30; };
	class 30Rnd_65x39_caseless_mag 							{ traderRank = 0; loadoutRank = 100; quality = 2; price = 20; };
	class 30Rnd_65x39_caseless_mag_Tracer 					{ traderRank = 0; loadoutRank = 100; quality = 2; price = 30; };
	class 30Rnd_9x21_Mag 									{ traderRank = 0; loadoutRank = 100; quality = 1; price = 40; };
	class 30Rnd_9x21_Yellow_Mag								{ traderRank = 0; loadoutRank = 100; quality = 1; price = 40; };
	class 30Rnd_9x21_Green_Mag								{ traderRank = 0; loadoutRank = 100; quality = 1; price = 40; };
	class 30Rnd_9x21_Red_Mag								{ traderRank = 0; loadoutRank = 100; quality = 1; price = 40; };
	class 5Rnd_127x108_APDS_Mag 							{ traderRank = 0; loadoutRank = 100; quality = 6; price = 50; };
	class 5Rnd_127x108_Mag 									{ traderRank = 0; loadoutRank = 100; quality = 6; price = 40; };
	class 6Rnd_45ACP_Cylinder 								{ traderRank = 0; loadoutRank = 100; quality = 1; price = 8; };
	class 6Rnd_GreenSignal_F 								{ traderRank = 0; loadoutRank = 100; quality = 1; price = 30; };
	class 6Rnd_RedSignal_F 									{ traderRank = 0; loadoutRank = 100; quality = 1; price = 30; };
	class 7Rnd_408_Mag 										{ traderRank = 0; loadoutRank = 100; quality = 6; price = 10; };
	class 9Rnd_45ACP_Mag 									{ traderRank = 0; loadoutRank = 100; quality = 1; price = 6; };

	// Price for bullet cam magazines is normal magazine price + 20 pop tabs per bullet
	class Exile_Magazine_5Rnd_127x108_Bullet_Cam_Mag		{ traderRank = 5; loadoutRank = 100; quality = 6; price = 40 +  5 * 20; };
	class Exile_Magazine_10Rnd_93x64_DMR_05_Bullet_Cam_Mag	{ traderRank = 5; loadoutRank = 100; quality = 6; price = 40 + 10 * 20; };
	class Exile_Magazine_7Rnd_408_Bullet_Cam_Mag			{ traderRank = 5; loadoutRank = 100; quality = 6; price = 10 +  7 * 20; };
	class Exile_Magazine_10Rnd_338_Bullet_Cam_Mag			{ traderRank = 5; loadoutRank = 100; quality = 6; price = 30 + 10 * 20; };
	
	class 5Rnd_rollins_mag 								{ traderRank = 0; loadoutRank = 100; quality = 1; price = 20; };

	///////////////////////////////////////////////////////////////////////////////
	// Flares
	///////////////////////////////////////////////////////////////////////////////
	class Chemlight_blue							{ traderRank = 0; loadoutRank = 100; quality = 1; price = 2; };
	class Chemlight_green							{ traderRank = 0; loadoutRank = 100; quality = 1; price = 2; };
	class Chemlight_red								{ traderRank = 0; loadoutRank = 100; quality = 1; price = 2; };
	class FlareGreen_F								{ traderRank = 0; loadoutRank = 100; quality = 1; price = 6; };
	class FlareRed_F								{ traderRank = 0; loadoutRank = 100; quality = 1; price = 6; };
	class FlareWhite_F								{ traderRank = 0; loadoutRank = 100; quality = 1; price = 6; };
	class FlareYellow_F								{ traderRank = 0; loadoutRank = 100; quality = 1; price = 6; };
	class UGL_FlareGreen_F							{ traderRank = 0; loadoutRank = 100; quality = 2; price = 8; };
	class UGL_FlareRed_F							{ traderRank = 0; loadoutRank = 100; quality = 2; price = 8; };
	class UGL_FlareWhite_F							{ traderRank = 0; loadoutRank = 100; quality = 2; price = 8; };
	class UGL_FlareYellow_F							{ traderRank = 0; loadoutRank = 100; quality = 2; price = 8; };
	class 3Rnd_UGL_FlareGreen_F						{ traderRank = 0; loadoutRank = 100; quality = 3; price = 8*3; };
	class 3Rnd_UGL_FlareRed_F						{ traderRank = 0; loadoutRank = 100; quality = 3; price = 8*3; };
	class 3Rnd_UGL_FlareWhite_F						{ traderRank = 0; loadoutRank = 100; quality = 3; price = 8*3; };
	class 3Rnd_UGL_FlareYellow_F					{ traderRank = 0; loadoutRank = 100; quality = 3; price = 8*3; };

	///////////////////////////////////////////////////////////////////////////////
	// Smokes
	///////////////////////////////////////////////////////////////////////////////
	class SmokeShell								{ traderRank = 0; loadoutRank = 100; quality = 1; price = 6; };
	class SmokeShellBlue							{ traderRank = 0; loadoutRank = 100; quality = 1; price = 6; };
	class SmokeShellGreen							{ traderRank = 0; loadoutRank = 100; quality = 1; price = 6; };
	class SmokeShellOrange							{ traderRank = 0; loadoutRank = 100; quality = 1; price = 6; };
	class SmokeShellPurple							{ traderRank = 0; loadoutRank = 100; quality = 1; price = 6; };
	class SmokeShellRed								{ traderRank = 0; loadoutRank = 100; quality = 1; price = 6; };
	class SmokeShellYellow							{ traderRank = 0; loadoutRank = 100; quality = 1; price = 6; };
	class 1Rnd_Smoke_Grenade_shell					{ traderRank = 0; loadoutRank = 100; quality = 2; price = 8; };
	class 1Rnd_SmokeBlue_Grenade_shell				{ traderRank = 0; loadoutRank = 100; quality = 2; price = 8; };
	class 1Rnd_SmokeGreen_Grenade_shell				{ traderRank = 0; loadoutRank = 100; quality = 2; price = 8; };
	class 1Rnd_SmokeOrange_Grenade_shell			{ traderRank = 0; loadoutRank = 100; quality = 2; price = 8; };
	class 1Rnd_SmokePurple_Grenade_shell			{ traderRank = 0; loadoutRank = 100; quality = 2; price = 8; };
	class 1Rnd_SmokeRed_Grenade_shell				{ traderRank = 0; loadoutRank = 100; quality = 2; price = 8; };
	class 1Rnd_SmokeYellow_Grenade_shell			{ traderRank = 0; loadoutRank = 100; quality = 2; price = 8; };
	class 3Rnd_Smoke_Grenade_shell					{ traderRank = 0; loadoutRank = 100; quality = 3; price = 8*3; };
	class 3Rnd_SmokeBlue_Grenade_shell				{ traderRank = 0; loadoutRank = 100; quality = 3; price = 8*3; };
	class 3Rnd_SmokeGreen_Grenade_shell				{ traderRank = 0; loadoutRank = 100; quality = 3; price = 8*3; };
	class 3Rnd_SmokeOrange_Grenade_shell			{ traderRank = 0; loadoutRank = 100; quality = 3; price = 8*3; };
	class 3Rnd_SmokePurple_Grenade_shell			{ traderRank = 0; loadoutRank = 100; quality = 3; price = 8*3; };
	class 3Rnd_SmokeRed_Grenade_shell				{ traderRank = 0; loadoutRank = 100; quality = 3; price = 8*3; };
	class 3Rnd_SmokeYellow_Grenade_shell			{ traderRank = 0; loadoutRank = 100; quality = 3; price = 8*3; };

	///////////////////////////////////////////////////////////////////////////////
	// Explosives
	///////////////////////////////////////////////////////////////////////////////
	class HandGrenade								{ traderRank = 0; loadoutRank = 100; quality = 3; price = 40; };
	class MiniGrenade								{ traderRank = 0; loadoutRank = 100; quality = 2; price = 30; };
	class B_IR_Grenade								{ traderRank = 0; loadoutRank = 100; quality = 1; price = 50; };
	class O_IR_Grenade								{ traderRank = 0; loadoutRank = 100; quality = 1; price = 50; };
	class I_IR_Grenade								{ traderRank = 0; loadoutRank = 100; quality = 1; price = 50; };
	class 1Rnd_HE_Grenade_shell						{ traderRank = 0; loadoutRank = 100; quality = 2; price = 70; };
	class 3Rnd_HE_Grenade_shell						{ traderRank = 5; loadoutRank = 100; quality = 3; price = 70*3; };
	class APERSBoundingMine_Range_Mag				{ traderRank = 0; loadoutRank = 100; quality = 3; price = 500; };
	class APERSMine_Range_Mag						{ traderRank = 0; loadoutRank = 100; quality = 3; price = 600; };
	class APERSTripMine_Wire_Mag					{ traderRank = 0; loadoutRank = 100; quality = 3; price = 300; };
	class ClaymoreDirectionalMine_Remote_Mag		{ traderRank = 0; loadoutRank = 100; quality = 3; price = 350; };
	class DemoCharge_Remote_Mag						{ traderRank = 5; loadoutRank = 100; quality = 4; price = 7000; };
	class IEDLandBig_Remote_Mag						{ traderRank = 5; loadoutRank = 100; quality = 3; price = 6000; };
	class IEDLandSmall_Remote_Mag					{ traderRank = 5; loadoutRank = 100; quality = 3; price = 3000; };
	class IEDUrbanBig_Remote_Mag					{ traderRank = 5; loadoutRank = 100; quality = 3; price = 8000; };
	class IEDUrbanSmall_Remote_Mag					{ traderRank = 5; loadoutRank = 100; quality = 3; price = 4000; };
	class SatchelCharge_Remote_Mag					{ traderRank = 5; loadoutRank = 100; quality = 5; price = 10000; };
	class SLAMDirectionalMine_Wire_Mag				{ traderRank = 5; loadoutRank = 100; quality = 3; price = 7000; };

	///////////////////////////////////////////////////////////////////////////////
	// Pistols
	///////////////////////////////////////////////////////////////////////////////
	class hgun_ACPC2_F 								{ traderRank = 0; loadoutRank = 0; quality = 1; price = 50; };
	class hgun_P07_F 								{ traderRank = 0; loadoutRank = 0; quality = 1; price = 50; };
	class hgun_Pistol_heavy_01_F 					{ traderRank = 0; loadoutRank = 2; quality = 2; price = 80; };
	class hgun_Pistol_heavy_02_F 					{ traderRank = 0; loadoutRank = 2; quality = 2; price = 80; };
	class hgun_Pistol_Signal_F 						{ traderRank = 0; loadoutRank = 0; quality = 1; price = 100; };
	class hgun_Rook40_F 							{ traderRank = 0; loadoutRank = 0; quality = 1; price = 50; };
	class ruger_pistol_epoch 							{ traderRank = 0; loadoutRank = 0; quality = 1; price = 250; };
	class ruger_pistol_epoch_snds_F 					{ traderRank = 0; loadoutRank = 100; quality = 1; price = 325; };
	class ruger_pistol_epoch_pointer_F 					{ traderRank = 0; loadoutRank = 100; quality = 1; price = 325; };
	class 1911_pistol_epoch 							{ traderRank = 0; loadoutRank = 0; quality = 1; price = 425; };

	///////////////////////////////////////////////////////////////////////////////
	// Sub Machine Guns
	///////////////////////////////////////////////////////////////////////////////
	class hgun_PDW2000_F 							{ traderRank = 0; loadoutRank = 2; quality = 1; price = 100; };
	class SMG_01_F 									{ traderRank = 0; loadoutRank = 2; quality = 1; price = 150; };
	class SMG_02_F 									{ traderRank = 0; loadoutRank = 2; quality = 1; price = 150; };

	///////////////////////////////////////////////////////////////////////////////
	// Light Machine Guns
	///////////////////////////////////////////////////////////////////////////////
	class arifle_MX_SW_Black_F						{ traderRank = 0; loadoutRank = 4; quality = 2; price = 250; };
	class arifle_MX_SW_F							{ traderRank = 0; loadoutRank = 4; quality = 2; price = 250; };
	class LMG_Mk200_F								{ traderRank = 0; loadoutRank = 5; quality = 2; price = 300; };
	class LMG_Zafir_F								{ traderRank = 0; loadoutRank = 4; quality = 3; price = 350; };
	class MMG_01_hex_F								{ traderRank = 5; loadoutRank = 6; quality = 6; price = 800; };
	class MMG_01_tan_F								{ traderRank = 5; loadoutRank = 6; quality = 6; price = 800; };
	class MMG_02_black_F							{ traderRank = 5; loadoutRank = 7; quality = 6; price = 450; };
	class MMG_02_camo_F								{ traderRank = 5; loadoutRank = 7; quality = 5; price = 450; };
	class MMG_02_sand_F								{ traderRank = 5; loadoutRank = 8; quality = 5; price = 450; };
	class m249_EPOCH 									{ traderRank = 0; loadoutRank = 100; quality = 1; price = 1250; };
	class m249Tan_EPOCH 								{ traderRank = 0; loadoutRank = 100; quality = 1; price = 1500; };

	///////////////////////////////////////////////////////////////////////////////
	// Assault Rifles
	///////////////////////////////////////////////////////////////////////////////
	class arifle_Katiba_C_F							{ traderRank = 0; loadoutRank = 4; quality = 2; price = 150; };
	class arifle_Katiba_F							{ traderRank = 0; loadoutRank = 4; quality = 2; price = 150; };
	class arifle_Katiba_GL_F						{ traderRank = 0; loadoutRank = 4; quality = 2; price = 200; };
	class arifle_Mk20_F								{ traderRank = 0; loadoutRank = 4; quality = 1; price = 150; };
	class arifle_Mk20_GL_F							{ traderRank = 0; loadoutRank = 4; quality = 1; price = 200; };
	class arifle_Mk20_GL_plain_F					{ traderRank = 0; loadoutRank = 4; quality = 1; price = 200; };
	class arifle_Mk20_plain_F						{ traderRank = 0; loadoutRank = 4; quality = 1; price = 150; };
	class arifle_Mk20C_F							{ traderRank = 0; loadoutRank = 4; quality = 1; price = 150; };
	class arifle_Mk20C_plain_F						{ traderRank = 0; loadoutRank = 4; quality = 1; price = 150; };
	class arifle_MX_Black_F							{ traderRank = 0; loadoutRank = 4; quality = 2; price = 450; };
	class arifle_MX_F								{ traderRank = 0; loadoutRank = 4; quality = 2; price = 450; };
	class arifle_MX_GL_Black_F						{ traderRank = 0; loadoutRank = 4; quality = 2; price = 450; };
	class arifle_MX_GL_F							{ traderRank = 0; loadoutRank = 4; quality = 2; price = 450; };
	class arifle_MXC_Black_F						{ traderRank = 0; loadoutRank = 4; quality = 2; price = 350; };
	class arifle_MXC_F								{ traderRank = 0; loadoutRank = 4; quality = 2; price = 350; };
	class arifle_SDAR_F								{ traderRank = 0; loadoutRank = 4; quality = 1; price = 650; };
	class arifle_TRG20_F							{ traderRank = 0; loadoutRank = 4; quality = 1; price = 250; };
	class arifle_TRG21_F							{ traderRank = 0; loadoutRank = 4; quality = 1; price = 250; };
	class arifle_TRG21_GL_F							{ traderRank = 0; loadoutRank = 4; quality = 1; price = 350; };
	class l85a2_epoch 									{ traderRank = 0; loadoutRank = 100; quality = 1; price = 550; };
	class l85a2_ris_epoch 								{ traderRank = 0; loadoutRank = 100; quality = 1; price = 600; };
	class l85a2_ris_ng_epoch 							{ traderRank = 0; loadoutRank = 100; quality = 1; price = 650; };
	class l85a2_pink_epoch 								{ traderRank = 0; loadoutRank = 100; quality = 1; price = 750; };
	class l85a2_ugl_epoch 								{ traderRank = 0; loadoutRank = 100; quality = 1; price = 800; };
	class AKM_EPOCH 									{ traderRank = 0; loadoutRank = 100; quality = 1; price = 500; };
	class m4a3_EPOCH 									{ traderRank = 0; loadoutRank = 3; quality = 1; price = 650; };
	class speargun_epoch 								{ traderRank = 0; loadoutRank = 100; quality = 1; price = 1000; };
	
	///////////////////////////////////////////////////////////////////////////////
	// Sniper Rifles
	///////////////////////////////////////////////////////////////////////////////
	class arifle_MXM_Black_F 						{ traderRank = 0; loadoutRank = 7; quality = 2; price = 550; };
	class arifle_MXM_F 								{ traderRank = 0; loadoutRank = 7; quality = 2; price = 550; };
	class srifle_DMR_01_F 							{ traderRank = 0; loadoutRank = 7; quality = 3; price = 600; };
	class srifle_DMR_02_camo_F 						{ traderRank = 0; loadoutRank = 7; quality = 3; price = 800; };
	class srifle_DMR_02_F 							{ traderRank = 0; loadoutRank = 7; quality = 3; price = 800; };
	class srifle_DMR_02_sniper_F 					{ traderRank = 0; loadoutRank = 7; quality = 3; price = 800; };
	class srifle_DMR_03_F 							{ traderRank = 0; loadoutRank = 7; quality = 3; price = 750; };
	class srifle_DMR_03_khaki_F 					{ traderRank = 0; loadoutRank = 7; quality = 3; price = 750; };
	class srifle_DMR_03_multicam_F 					{ traderRank = 0; loadoutRank = 7; quality = 3; price = 750; };
	class srifle_DMR_03_tan_F 						{ traderRank = 0; loadoutRank = 7; quality = 3; price = 750; };
	class srifle_DMR_03_woodland_F 					{ traderRank = 0; loadoutRank = 7; quality = 3; price = 750; };
	class srifle_DMR_04_F 							{ traderRank = 0; loadoutRank = 7; quality = 4; price = 700; };
	class srifle_DMR_04_Tan_F 						{ traderRank = 0; loadoutRank = 7; quality = 4; price = 700; };
	class srifle_DMR_05_blk_F 						{ traderRank = 0; loadoutRank = 7; quality = 4; price = 850; };
	class srifle_DMR_05_hex_F 						{ traderRank = 0; loadoutRank = 7; quality = 4; price = 850; };
	class srifle_DMR_05_tan_f 						{ traderRank = 0; loadoutRank = 7; quality = 4; price = 850; };
	class srifle_DMR_06_camo_F 						{ traderRank = 0; loadoutRank = 7; quality = 5; price = 800; };
	class srifle_DMR_06_olive_F 					{ traderRank = 0; loadoutRank = 7; quality = 5; price = 800; };
	class srifle_EBR_F 								{ traderRank = 0; loadoutRank = 7; quality = 3; price = 700; };
	class srifle_GM6_camo_F 						{ traderRank = 5; loadoutRank = 7; quality = 6; price = 900; };
	class srifle_GM6_F 								{ traderRank = 5; loadoutRank = 7; quality = 6; price = 900; };
	class srifle_LRR_camo_F 						{ traderRank = 5; loadoutRank = 7; quality = 6; price = 850; };
	class srifle_LRR_F 								{ traderRank = 5; loadoutRank = 7; quality = 6; price = 850; };
	class Rollins_F 									{ traderRank = 0; loadoutRank = 100; quality = 1; price = 750; };
	class sr25_epoch 									{ traderRank = 10; loadoutRank = 100; quality = 1; price = 1250; };
	class sr25_ec_epoch 								{ traderRank = 10; loadoutRank = 100; quality = 1; price = 1500; };
	class M14_EPOCH 									{ traderRank = 0; loadoutRank = 100; quality = 1; price = 800; };
	class M14Grn_EPOCH 									{ traderRank = 5; loadoutRank = 100; quality = 1; price = 800; };
	class m16_EPOCH 									{ traderRank = 0; loadoutRank = 100; quality = 1; price = 850; };
	class m16Red_EPOCH 									{ traderRank = 5; loadoutRank = 100; quality = 1; price = 850; };
	class m107_EPOCH 									{ traderRank = 5; loadoutRank = 100; quality = 1; price = 1700; };
	class m107Tan_EPOCH 								{ traderRank = 5; loadoutRank = 100; quality = 1; price = 1900; };
	
	///////////////////////////////////////////////////////////////////////////////
	// ArmA 2 Weapons
	///////////////////////////////////////////////////////////////////////////////
	class Exile_Weapon_AK107						{ traderRank = 0; loadoutRank = 8; quality = 1; price = 300; };
	class Exile_Weapon_AK107_GL						{ traderRank = 0; loadoutRank = 8; quality = 2; price = 400; };
	class Exile_Weapon_AK74							{ traderRank = 0; loadoutRank = 8; quality = 2; price = 350; };
	class Exile_Weapon_AK74_GL						{ traderRank = 0; loadoutRank = 8; quality = 2; price = 400; };
	class Exile_Weapon_AK47							{ traderRank = 0; loadoutRank = 8; quality = 3; price = 500; };
	class Exile_Weapon_AKM							{ traderRank = 0; loadoutRank = 8; quality = 3; price = 500; };
	class Exile_Weapon_AKS							{ traderRank = 0; loadoutRank = 8; quality = 3; price = 500; };
	class Exile_Weapon_AKS_Gold						{ traderRank = 5; loadoutRank = 8; quality = 3; price = 550; };
	class Exile_Weapon_DMR							{ traderRank = 0; loadoutRank = 8; quality = 3; price = 650; };
	class Exile_Weapon_LeeEnfield					{ traderRank = 0; loadoutRank = 8; quality = 1; price = 250; };
	class Exile_Weapon_CZ550						{ traderRank = 0; loadoutRank = 8; quality = 2; price = 400; };
	class Exile_Weapon_SVD							{ traderRank = 5; loadoutRank = 8; quality = 4; price = 800; };
	class Exile_Weapon_SVDCamo						{ traderRank = 10; loadoutRank = 8; quality = 4; price = 850; };
	class Exile_Weapon_VSSVintorez					{ traderRank = 0; loadoutRank = 8; quality = 3; price = 600; };
	class Exile_Weapon_RPK							{ traderRank = 5; loadoutRank = 8; quality = 2; price = 250; };
	class Exile_Weapon_PK							{ traderRank = 0; loadoutRank = 8; quality = 3; price = 300; };
	class Exile_Weapon_PKP							{ traderRank = 5; loadoutRank = 8; quality = 3; price = 350; };
	class Exile_Weapon_Colt1911						{ traderRank = 0; loadoutRank = 8; quality = 1; price = 100; };
	class Exile_Weapon_Makarov						{ traderRank = 0; loadoutRank = 8; quality = 1; price = 100; };
	class Exile_Weapon_Taurus						{ traderRank = 0; loadoutRank = 8; quality = 1; price = 100; };
	class Exile_Weapon_TaurusGold					{ traderRank = 5; loadoutRank = 8; quality = 1; price = 150; };
	class Exile_Weapon_M1014						{ traderRank = 0; loadoutRank = 8; quality = 2; price = 200; };
	
	///////////////////////////////////////////////////////////////////////////////
	// ArmA 2 Ammunition
	///////////////////////////////////////////////////////////////////////////////
	class Exile_Magazine_30Rnd_762x39_AK				{ traderRank = 0; loadoutRank = 100; quality = 3; price = 20; };
	class Exile_Magazine_30Rnd_545x39_AK				{ traderRank = 0; loadoutRank = 100; quality = 1; price = 20; };
	class Exile_Magazine_30Rnd_545x39_AK_Green			{ traderRank = 0; loadoutRank = 100; quality = 1; price = 20; };
	class Exile_Magazine_30Rnd_545x39_AK_Red			{ traderRank = 0; loadoutRank = 100; quality = 1; price = 20; };
	class Exile_Magazine_30Rnd_545x39_AK_White			{ traderRank = 0; loadoutRank = 100; quality = 1; price = 20; };
	class Exile_Magazine_30Rnd_545x39_AK_Yellow			{ traderRank = 0; loadoutRank = 100; quality = 1; price = 20; };
	class Exile_Magazine_45Rnd_545x39_RPK_Green			{ traderRank = 0; loadoutRank = 100; quality = 1; price = 20; };
	class Exile_Magazine_75Rnd_545x39_RPK_Green			{ traderRank = 0; loadoutRank = 100; quality = 1; price = 20; };
	class Exile_Magazine_20Rnd_762x51_DMR				{ traderRank = 0; loadoutRank = 100; quality = 3; price = 20; };
	class Exile_Magazine_20Rnd_762x51_DMR_Yellow		{ traderRank = 0; loadoutRank = 100; quality = 3; price = 20; };
	class Exile_Magazine_20Rnd_762x51_DMR_Red			{ traderRank = 0; loadoutRank = 100; quality = 3; price = 20; };
	class Exile_Magazine_20Rnd_762x51_DMR_Green			{ traderRank = 0; loadoutRank = 100; quality = 3; price = 20; };
	class Exile_Magazine_10Rnd_303						{ traderRank = 0; loadoutRank = 100; quality = 1; price = 20; };
	class Exile_Magazine_100Rnd_762x54_PK_Green			{ traderRank = 0; loadoutRank = 100; quality = 3; price = 20; };
	class Exile_Magazine_7Rnd_45ACP						{ traderRank = 0; loadoutRank = 100; quality = 1; price = 20; };
	class Exile_Magazine_8Rnd_9x18						{ traderRank = 0; loadoutRank = 100; quality = 1; price = 20; };
	class Exile_Magazine_6Rnd_45ACP						{ traderRank = 0; loadoutRank = 100; quality = 1; price = 20; };
	class Exile_Magazine_5Rnd_22LR						{ traderRank = 0; loadoutRank = 100; quality = 1; price = 20; };
	class Exile_Magazine_10Rnd_762x54					{ traderRank = 0; loadoutRank = 100; quality = 1; price = 20; };
	class Exile_Magazine_10Rnd_9x39						{ traderRank = 0; loadoutRank = 100; quality = 1; price = 20; };
	class Exile_Magazine_20Rnd_9x39						{ traderRank = 0; loadoutRank = 100; quality = 1; price = 20; };
	class Exile_Magazine_8Rnd_74Slug					{ traderRank = 0; loadoutRank = 100; quality = 1; price = 20; };
	class Exile_Magazine_8Rnd_74Pellets					{ traderRank = 0; loadoutRank = 100; quality = 1; price = 20; }; // broken?
	
	///////////////////////////////////////////////////////////////////////////////
	// Apex Items & Weapons
	///////////////////////////////////////////////////////////////////////////////
	class hgun_Pistol_01_F            { traderRank = 0; loadoutRank = 100; quality = 1; price = 65; };
	class hgun_P07_khk_F              { traderRank = 0; loadoutRank = 100; quality = 1; price = 65; };
	class SMG_05_F					  { traderRank = 0; loadoutRank = 100; quality = 1; price = 150; };
	class LMG_03_F					  { traderRank = 0; loadoutRank = 100; quality = 2; price = 300; };
	class arifle_MX_khk_F             { traderRank = 0; loadoutRank = 100; quality = 2; price = 450; };
	class arifle_MX_GL_khk_F          { traderRank = 0; loadoutRank = 100; quality = 2; price = 500; };
	class arifle_MXC_khk_F            { traderRank = 0; loadoutRank = 100; quality = 2; price = 350; };
	class arifle_MXM_khk_F            { traderRank = 0; loadoutRank = 100; quality = 2; price = 500; };
	class srifle_LRR_tna_F            { traderRank = 0; loadoutRank = 100; quality = 6; price = 850; };
	class srifle_GM6_ghex_F           { traderRank = 0; loadoutRank = 100; quality = 6; price = 900; };
	class srifle_DMR_07_blk_F         { traderRank = 0; loadoutRank = 100; quality = 4; price = 750; };
	class srifle_DMR_07_hex_F         { traderRank = 0; loadoutRank = 100; quality = 4; price = 750; };
	class srifle_DMR_07_ghex_F        { traderRank = 0; loadoutRank = 100; quality = 4; price = 750; };
	class arifle_AK12_F               { traderRank = 0; loadoutRank = 100; quality = 3; price = 650; };
	class arifle_AK12_GL_F            { traderRank = 0; loadoutRank = 100; quality = 3; price = 700; };
	class arifle_AKM_F                { traderRank = 0; loadoutRank = 100; quality = 3; price = 400; };
	class arifle_AKM_FL_F             { traderRank = 0; loadoutRank = 100; quality = 3; price = 400; };
	class arifle_AKS_F                { traderRank = 0; loadoutRank = 100; quality = 3; price = 350; };
	class arifle_ARX_blk_F            { traderRank = 0; loadoutRank = 100; quality = 5; price = 900; };
	class arifle_ARX_ghex_F           { traderRank = 0; loadoutRank = 100; quality = 5; price = 900; };
	class arifle_ARX_hex_F            { traderRank = 0; loadoutRank = 100; quality = 5; price = 900; };
	class arifle_CTAR_blk_F           { traderRank = 0; loadoutRank = 100; quality = 2; price = 450; };
	class arifle_CTAR_hex_F           { traderRank = 0; loadoutRank = 100; quality = 2; price = 450; };
	class arifle_CTAR_ghex_F          { traderRank = 0; loadoutRank = 100; quality = 2; price = 450; };
	class arifle_CTAR_GL_blk_F        { traderRank = 0; loadoutRank = 100; quality = 2; price = 450; };
	class arifle_CTARS_blk_F          { traderRank = 0; loadoutRank = 100; quality = 2; price = 450; };
	class arifle_CTARS_ghex_F          { traderRank = 0; loadoutRank = 100; quality = 2; price = 450; };
	class arifle_CTARS_hex_F          { traderRank = 0; loadoutRank = 100; quality = 2; price = 450; };
	class arifle_SPAR_01_blk_F        { traderRank = 0; loadoutRank = 100; quality = 1; price = 400; };
	class arifle_SPAR_01_khk_F        { traderRank = 0; loadoutRank = 100; quality = 1; price = 400; };
	class arifle_SPAR_01_snd_F        { traderRank = 0; loadoutRank = 100; quality = 1; price = 400; };
	class arifle_SPAR_01_GL_blk_F     { traderRank = 0; loadoutRank = 100; quality = 1; price = 500; };
	class arifle_SPAR_01_GL_khk_F     { traderRank = 0; loadoutRank = 100; quality = 1; price = 500; };
	class arifle_SPAR_01_GL_snd_F     { traderRank = 0; loadoutRank = 100; quality = 1; price = 500; };
	class arifle_SPAR_02_blk_F        { traderRank = 0; loadoutRank = 100; quality = 2; price = 550; };
	class arifle_SPAR_02_khk_F        { traderRank = 0; loadoutRank = 100; quality = 2; price = 550; };
	class arifle_SPAR_02_snd_F        { traderRank = 0; loadoutRank = 100; quality = 2; price = 550; };
	class arifle_SPAR_03_blk_F        { traderRank = 0; loadoutRank = 100; quality = 3; price = 600; };
	class arifle_SPAR_03_khk_F        { traderRank = 0; loadoutRank = 100; quality = 3; price = 600; };
	class arifle_SPAR_03_snd_F        { traderRank = 0; loadoutRank = 100; quality = 3; price = 600; };					
	class muzzle_snds_H_khk_F         { traderRank = 0; loadoutRank = 100; quality = 2; price = 50; };
	class muzzle_snds_H_snd_F         { traderRank = 0; loadoutRank = 100; quality = 2; price = 50; };
	class muzzle_snds_58_blk_F        { traderRank = 0; loadoutRank = 100; quality = 1; price = 20; };
	class muzzle_snds_m_khk_F         { traderRank = 0; loadoutRank = 100; quality = 1; price = 15; };
	class muzzle_snds_m_snd_F         { traderRank = 0; loadoutRank = 100; quality = 1; price = 15; };
	class muzzle_snds_B_khk_F         { traderRank = 0; loadoutRank = 100; quality = 3; price = 50; };
	class muzzle_snds_B_snd_F         { traderRank = 0; loadoutRank = 100; quality = 3; price = 50; };
	class muzzle_snds_58_wdm_F        { traderRank = 0; loadoutRank = 100; quality = 1; price = 20; };
	class muzzle_snds_65_TI_blk_F     { traderRank = 0; loadoutRank = 100; quality = 2; price = 75; };
	class muzzle_snds_65_TI_hex_F     { traderRank = 0; loadoutRank = 100; quality = 2; price = 75; };
	class muzzle_snds_65_TI_ghex_F    { traderRank = 0; loadoutRank = 100; quality = 2; price = 75; };
	class muzzle_snds_H_MG_blk_F      { traderRank = 0; loadoutRank = 100; quality = 2; price = 20; };
	class muzzle_snds_H_MG_khk_F      { traderRank = 0; loadoutRank = 100; quality = 2; price = 20; };
	class optic_Arco_blk_F            { traderRank = 0; loadoutRank = 100; quality = 1; price = 100; };
	class optic_Arco_ghex_F           { traderRank = 0; loadoutRank = 100; quality = 1; price = 100; };
	class optic_DMS_ghex_F            { traderRank = 0; loadoutRank = 100; quality = 2; price = 150; };
	class optic_Hamr_khk_F            { traderRank = 0; loadoutRank = 100; quality = 3; price = 200; };
	class optic_ERCO_blk_F            { traderRank = 0; loadoutRank = 100; quality = 1; price = 125; };
	class optic_ERCO_khk_F            { traderRank = 0; loadoutRank = 100; quality = 1; price = 125; };
	class optic_ERCO_snd_F            { traderRank = 0; loadoutRank = 100; quality = 1; price = 125; };
	class optic_SOS_khk_F             { traderRank = 0; loadoutRank = 100; quality = 2; price = 200; };
	class optic_LRPS_tna_F            { traderRank = 0; loadoutRank = 100; quality = 5; price = 300; };
	class optic_LRPS_ghex_F           { traderRank = 0; loadoutRank = 100; quality = 5; price = 300; };
	class optic_Holosight_blk_F       { traderRank = 0; loadoutRank = 100; quality = 1; price = 50; };
	class optic_Holosight_khk_F       { traderRank = 0; loadoutRank = 100; quality = 1; price = 50; };
	class optic_Holosight_smg_blk_F   { traderRank = 0; loadoutRank = 100; quality = 1; price = 50; };
	class bipod_01_F_khk              { traderRank = 0; loadoutRank = 100; quality = 2; price = 10; };
	class O_NVGoggles_hex_F           { traderRank = 0; loadoutRank = 100; quality = 3; price = 150; };
	class O_NVGoggles_urb_F           { traderRank = 0; loadoutRank = 100; quality = 3; price = 150; };
	class O_NVGoggles_ghex_F          { traderRank = 0; loadoutRank = 100; quality = 3; price = 150; };
	class NVGoggles_tna_F             { traderRank = 0; loadoutRank = 100; quality = 2; price = 100; };
	//class NVGogglesB_blk_F            { traderRank = 0; loadoutRank = 100; quality = 1; price = 1000; }; //Normal NightV but fullscreen thermal
	//class NVGogglesB_grn_F            { traderRank = 0; loadoutRank = 100; quality = 1; price = 1000; };	//Normal NightV but fullscreen thermal
	//class NVGogglesB_gry_F            { traderRank = 0; loadoutRank = 100; quality = 1; price = 1000; };	//Normal NightV but fullscreen thermal
	//class Laserdesignator_01_khk_F    { traderRank = 0; loadoutRank = 100; quality = 1; price = 1000; };	//Thermal
	//class Laserdesignator_02_ghex_F   { traderRank = 0; loadoutRank = 100; quality = 1; price = 1000; };	//Thermal
	class U_B_T_Soldier_F             { traderRank = 0; loadoutRank = 100; quality = 2; price = 40; };
	class U_B_T_Soldier_AR_F          { traderRank = 0; loadoutRank = 100; quality = 2; price = 40; };
	class U_B_T_Soldier_SL_F          { traderRank = 0; loadoutRank = 100; quality = 2; price = 40; };
	class U_B_T_Sniper_F              { traderRank = 0; loadoutRank = 100; quality = 3; price = 100; };
	class U_B_T_FullGhillie_tna_F     { traderRank = 0; loadoutRank = 100; quality = 4; price = 150; };
	class U_B_CTRG_Soldier_F          { traderRank = 0; loadoutRank = 100; quality = 2; price = 40; };
	class U_B_CTRG_Soldier_2_F        { traderRank = 0; loadoutRank = 100; quality = 2; price = 40; };
	class U_B_CTRG_Soldier_3_F        { traderRank = 0; loadoutRank = 100; quality = 2; price = 40; };
	class U_B_GEN_Soldier_F           { traderRank = 0; loadoutRank = 100; quality = 2; price = 35; };
	class U_B_GEN_Commander_F         { traderRank = 0; loadoutRank = 100; quality = 2; price = 35; };
	class U_O_T_Soldier_F             { traderRank = 0; loadoutRank = 100; quality = 2; price = 40; };
	class U_O_T_Officer_F             { traderRank = 0; loadoutRank = 100; quality = 3; price = 40; };
	class U_O_T_Sniper_F              { traderRank = 0; loadoutRank = 100; quality = 3; price = 100; };
	class U_O_T_FullGhillie_tna_F     { traderRank = 0; loadoutRank = 100; quality = 4; price = 150; };
	class U_O_V_Soldier_Viper_F       { traderRank = 0; loadoutRank = 100; quality = 4; price = 150; };
	class U_O_V_Soldier_Viper_hex_F   { traderRank = 0; loadoutRank = 100; quality = 4; price = 150; };
	class U_I_C_Soldier_Para_1_F      { traderRank = 0; loadoutRank = 100; quality = 2; price = 30; };
	class U_I_C_Soldier_Para_2_F      { traderRank = 0; loadoutRank = 100; quality = 2; price = 30; };
	class U_I_C_Soldier_Para_3_F      { traderRank = 0; loadoutRank = 100; quality = 2; price = 30; };
	class U_I_C_Soldier_Para_4_F      { traderRank = 0; loadoutRank = 100; quality = 2; price = 30; };
	class U_I_C_Soldier_Para_5_F      { traderRank = 0; loadoutRank = 100; quality = 2; price = 30; };
	class U_I_C_Soldier_Bandit_1_F    { traderRank = 0; loadoutRank = 100; quality = 1; price = 15; };
	class U_I_C_Soldier_Bandit_2_F    { traderRank = 0; loadoutRank = 100; quality = 1; price = 15; };
	class U_I_C_Soldier_Bandit_3_F    { traderRank = 0; loadoutRank = 100; quality = 1; price = 15; };
	class U_I_C_Soldier_Bandit_4_F    { traderRank = 0; loadoutRank = 100; quality = 1; price = 15; };
	class U_I_C_Soldier_Bandit_5_F    { traderRank = 0; loadoutRank = 100; quality = 1; price = 15; };
	class U_I_C_Soldier_Camo_F        { traderRank = 0; loadoutRank = 100; quality = 2; price = 30; };
	class U_C_man_sport_1_F           { traderRank = 0; loadoutRank = 100; quality = 1; price = 10; };
	class U_C_man_sport_2_F           { traderRank = 0; loadoutRank = 100; quality = 1; price = 10; };
	class U_C_man_sport_3_F           { traderRank = 0; loadoutRank = 100; quality = 1; price = 10; };
	class U_C_Man_casual_1_F          { traderRank = 0; loadoutRank = 100; quality = 1; price = 10; };
	class U_C_Man_casual_2_F          { traderRank = 0; loadoutRank = 100; quality = 1; price = 10; };
	class U_C_Man_casual_3_F          { traderRank = 0; loadoutRank = 100; quality = 1; price = 10; };
	class U_C_Man_casual_4_F          { traderRank = 0; loadoutRank = 100; quality = 1; price = 10; };
	class U_C_Man_casual_5_F          { traderRank = 0; loadoutRank = 100; quality = 1; price = 10; };
	class U_C_Man_casual_6_F          { traderRank = 0; loadoutRank = 100; quality = 1; price = 10; };
	class U_B_CTRG_Soldier_urb_1_F    { traderRank = 0; loadoutRank = 100; quality = 2; price = 40; };
	class U_B_CTRG_Soldier_urb_2_F    { traderRank = 0; loadoutRank = 100; quality = 2; price = 40; };
	class U_B_CTRG_Soldier_urb_3_F    { traderRank = 0; loadoutRank = 100; quality = 2; price = 40; };
	class H_Helmet_Skate              { traderRank = 0; loadoutRank = 100; quality = 2; price = 20; };
	class H_HelmetB_TI_tna_F          { traderRank = 0; loadoutRank = 100; quality = 4; price = 100; };
	class H_HelmetO_ViperSP_hex_F     { traderRank = 10; loadoutRank = 100; quality = 4; price = 25000; };		//Themal
	class H_HelmetO_ViperSP_ghex_F    { traderRank = 10; loadoutRank = 100; quality = 4; price = 25000; }; 	//Themal 
	class H_HelmetB_tna_F             { traderRank = 0; loadoutRank = 100; quality = 3; price = 50; };
	class H_HelmetB_Enh_tna_F         { traderRank = 0; loadoutRank = 100; quality = 4; price = 100; };
	class H_HelmetB_Light_tna_F       { traderRank = 0; loadoutRank = 100; quality = 2; price = 20; };
	class H_HelmetSpecO_ghex_F        { traderRank = 0; loadoutRank = 100; quality = 5; price = 100; };
	class H_HelmetLeaderO_ghex_F      { traderRank = 0; loadoutRank = 100; quality = 5; price = 175; };
	class H_HelmetO_ghex_F            { traderRank = 0; loadoutRank = 100; quality = 5; price = 75; };
	class H_HelmetCrew_O_ghex_F       { traderRank = 0; loadoutRank = 100; quality = 3; price = 75; };
	class H_MilCap_tna_F              { traderRank = 0; loadoutRank = 100; quality = 1; price = 8; };
	class H_MilCap_ghex_F             { traderRank = 0; loadoutRank = 100; quality = 1; price = 8; };
	class H_Booniehat_tna_F           { traderRank = 0; loadoutRank = 100; quality = 1; price = 4; };
	class H_Beret_gen_F               { traderRank = 0; loadoutRank = 100; quality = 2; price = 12; };
	class H_MilCap_gen_F              { traderRank = 0; loadoutRank = 100; quality = 1; price = 10; };
	class H_Cap_oli_Syndikat_F        { traderRank = 0; loadoutRank = 100; quality = 1; price = 6; };
	class H_Cap_tan_Syndikat_F        { traderRank = 0; loadoutRank = 100; quality = 1; price = 6; };
	class H_Cap_blk_Syndikat_F        { traderRank = 0; loadoutRank = 100; quality = 1; price = 6; };
	class H_Cap_grn_Syndikat_F        { traderRank = 0; loadoutRank = 100; quality = 1; price = 6; };
	class H_FakeHeadgear_Syndikat_F   { traderRank = 0; loadoutRank = 100; quality = 1; price = 6; };
	class V_TacChestrig_grn_F         { traderRank = 0; loadoutRank = 100; quality = 1; price = 15; };
	class V_TacChestrig_oli_F         { traderRank = 0; loadoutRank = 100; quality = 1; price = 15; };
	class V_TacChestrig_cbr_F         { traderRank = 0; loadoutRank = 100; quality = 1; price = 15; };
	class V_PlateCarrier1_tna_F       { traderRank = 0; loadoutRank = 100; quality = 3; price = 50; };
	class V_PlateCarrier2_tna_F       { traderRank = 0; loadoutRank = 100; quality = 3; price = 60; };
	class V_PlateCarrierSpec_tna_F    { traderRank = 0; loadoutRank = 100; quality = 5; price = 100; };
	class V_PlateCarrierGL_tna_F      { traderRank = 0; loadoutRank = 100; quality = 6; price = 500; };
	class V_HarnessO_ghex_F           { traderRank = 0; loadoutRank = 100; quality = 2; price = 50; };
	class V_HarnessOGL_ghex_F         { traderRank = 0; loadoutRank = 100; quality = 1; price = 30; };
	class V_BandollierB_ghex_F        { traderRank = 0; loadoutRank = 100; quality = 1; price = 10; };
	class V_TacVest_gen_F             { traderRank = 0; loadoutRank = 100; quality = 1; price = 25; };
	class V_PlateCarrier1_rgr_noflag_F		{ traderRank = 0; loadoutRank = 100; quality = 2; price = 50; };
	class V_PlateCarrier2_rgr_noflag_F		{ traderRank = 0; loadoutRank = 100; quality = 2; price = 60; };
	class B_Bergen_Base_F					{ traderRank = 0; loadoutRank = 100; quality = 5; price = 400; };
	class B_Bergen_mcamo_F                  { traderRank = 0; loadoutRank = 100; quality = 5; price = 400; };
	class B_Bergen_dgtl_F                   { traderRank = 0; loadoutRank = 100; quality = 5; price = 400; };
	class B_Bergen_hex_F                    { traderRank = 0; loadoutRank = 100; quality = 5; price = 400; };
	class B_Bergen_tna_F                    { traderRank = 0; loadoutRank = 100; quality = 5; price = 400; };
	class B_AssaultPack_tna_F               { traderRank = 0; loadoutRank = 100; quality = 1; price = 90; };
	class B_Carryall_ghex_F                 { traderRank = 0; loadoutRank = 100; quality = 4; price = 300; };
	class B_FieldPack_ghex_F                { traderRank = 0; loadoutRank = 100; quality = 2; price = 120; };
	class B_ViperHarness_base_F             { traderRank = 0; loadoutRank = 100; quality = 3; price = 250; };
	class B_ViperHarness_blk_F              { traderRank = 0; loadoutRank = 100; quality = 3; price = 250; };
	class B_ViperHarness_ghex_F             { traderRank = 0; loadoutRank = 100; quality = 3; price = 250; };
	class B_ViperHarness_hex_F              { traderRank = 0; loadoutRank = 100; quality = 3; price = 250; };
	class B_ViperHarness_khk_F              { traderRank = 0; loadoutRank = 100; quality = 3; price = 250; };
	class B_ViperHarness_oli_F              { traderRank = 0; loadoutRank = 100; quality = 3; price = 250; };
	class B_ViperLightHarness_base_F        { traderRank = 0; loadoutRank = 100; quality = 2; price = 200; };
	class B_ViperLightHarness_blk_F         { traderRank = 0; loadoutRank = 100; quality = 2; price = 200; };
	class B_ViperLightHarness_ghex_F        { traderRank = 0; loadoutRank = 100; quality = 2; price = 200; };
	class B_ViperLightHarness_hex_F         { traderRank = 0; loadoutRank = 100; quality = 2; price = 200; };
	class B_ViperLightHarness_khk_F         { traderRank = 0; loadoutRank = 100; quality = 2; price = 200; };
	class B_ViperLightHarness_oli_F         { traderRank = 0; loadoutRank = 100; quality = 2; price = 200; };
	
	class 30Rnd_9x21_Mag_SMG_02						{ traderRank = 0; loadoutRank = 100; quality = 1; price = 10; };
	class 30Rnd_9x21_Mag_SMG_02_Tracer_Red          { traderRank = 0; loadoutRank = 100; quality = 1; price = 15; };
	class 30Rnd_9x21_Mag_SMG_02_Tracer_Yellow       { traderRank = 0; loadoutRank = 100; quality = 1; price = 15; };
	class 30Rnd_9x21_Mag_SMG_02_Tracer_Green        { traderRank = 0; loadoutRank = 100; quality = 1; price = 15; };
	class 30Rnd_580x42_Mag_F                        { traderRank = 0; loadoutRank = 100; quality = 2; price = 15; };
	class 30Rnd_580x42_Mag_Tracer_F                 { traderRank = 0; loadoutRank = 100; quality = 2; price = 15; };
	class 100Rnd_580x42_Mag_F                       { traderRank = 0; loadoutRank = 100; quality = 2; price = 15; };
	class 100Rnd_580x42_Mag_Tracer_F                { traderRank = 0; loadoutRank = 100; quality = 2; price = 15; };
	class 20Rnd_650x39_Cased_Mag_F                  { traderRank = 0; loadoutRank = 100; quality = 4; price = 20; };
	class 10Rnd_50BW_Mag_F                          { traderRank = 0; loadoutRank = 100; quality = 5; price = 35; };
	class 150Rnd_556x45_Drum_Mag_F                  { traderRank = 0; loadoutRank = 100; quality = 2; price = 75; };
	class 150Rnd_556x45_Drum_Mag_Tracer_F           { traderRank = 0; loadoutRank = 100; quality = 2; price = 75; };
	class 30Rnd_762x39_Mag_F                        { traderRank = 0; loadoutRank = 100; quality = 3; price = 25; };
	class 30Rnd_762x39_Mag_Green_F                  { traderRank = 0; loadoutRank = 100; quality = 3; price = 25; };
	class 30Rnd_762x39_Mag_Tracer_F                 { traderRank = 0; loadoutRank = 100; quality = 3; price = 25; };
	class 30Rnd_762x39_Mag_Tracer_Green_F           { traderRank = 0; loadoutRank = 100; quality = 3; price = 25; };
	class 30Rnd_545x39_Mag_F                        { traderRank = 0; loadoutRank = 100; quality = 1; price = 10; };
	class 30Rnd_545x39_Mag_Green_F                  { traderRank = 0; loadoutRank = 100; quality = 1; price = 10; };
	class 30Rnd_545x39_Mag_Tracer_F                 { traderRank = 0; loadoutRank = 100; quality = 1; price = 10; };
	class 30Rnd_545x39_Mag_Tracer_Green_F           { traderRank = 0; loadoutRank = 100; quality = 1; price = 10; };
	class 200Rnd_556x45_Box_F                       { traderRank = 0; loadoutRank = 100; quality = 1; price = 90; };
	class 200Rnd_556x45_Box_Red_F                   { traderRank = 0; loadoutRank = 100; quality = 1; price = 90; };
	class 200Rnd_556x45_Box_Tracer_F                { traderRank = 0; loadoutRank = 100; quality = 1; price = 90; };
	class 200Rnd_556x45_Box_Tracer_Red_F            { traderRank = 0; loadoutRank = 100; quality = 1; price = 90; };
	class 10Rnd_9x21_Mag							{ traderRank = 0; loadoutRank = 100; quality = 1; price = 10; };
	
	///////////////////////////////////////////////////////////////////////////////
	// BIKES
	///////////////////////////////////////////////////////////////////////////////
	class Exile_Bike_OldBike 						{ traderRank = 0; loadoutRank = 100; quality = 1; price = 40; };
	class Exile_Bike_MountainBike 					{ traderRank = 0; loadoutRank = 100; quality = 1; price = 50; };

	///////////////////////////////////////////////////////////////////////////////
	// QUAD BIKES
	///////////////////////////////////////////////////////////////////////////////
	class Exile_Bike_QuadBike_Black					{ traderRank = 0; loadoutRank = 100; quality = 1; price = 2500; };
	class Exile_Bike_QuadBike_Blue					{ traderRank = 0; loadoutRank = 100; quality = 1; price = 2500; };
	class Exile_Bike_QuadBike_Red					{ traderRank = 0; loadoutRank = 100; quality = 1; price = 2500; };
	class Exile_Bike_QuadBike_White					{ traderRank = 0; loadoutRank = 100; quality = 1; price = 2500; };
	class Exile_Bike_QuadBike_Nato					{ traderRank = 0; loadoutRank = 100; quality = 1; price = 2500; };
	class Exile_Bike_QuadBike_Csat					{ traderRank = 0; loadoutRank = 100; quality = 1; price = 2500; };
	class Exile_Bike_QuadBike_Fia					{ traderRank = 0; loadoutRank = 100; quality = 1; price = 2500; };
	class Exile_Bike_QuadBike_Guerilla01			{ traderRank = 0; loadoutRank = 100; quality = 1; price = 2500; };
	class Exile_Bike_QuadBike_Guerilla02			{ traderRank = 0; loadoutRank = 100; quality = 1; price = 2500; };

	///////////////////////////////////////////////////////////////////////////////
	// KARTS
	///////////////////////////////////////////////////////////////////////////////
	class Exile_Car_Kart_BluKing					{ traderRank = 0; loadoutRank = 100; quality = 1; price = 1100; };
	class Exile_Car_Kart_RedStone					{ traderRank = 0; loadoutRank = 100; quality = 1; price = 1100; };
	class Exile_Car_Kart_Vrana						{ traderRank = 0; loadoutRank = 100; quality = 1; price = 1100; };
	class Exile_Car_Kart_Green						{ traderRank = 0; loadoutRank = 100; quality = 1; price = 1100; };
	class Exile_Car_Kart_Blue						{ traderRank = 0; loadoutRank = 100; quality = 1; price = 1100; };
	class Exile_Car_Kart_Orange						{ traderRank = 0; loadoutRank = 100; quality = 1; price = 1100; };
	class Exile_Car_Kart_White						{ traderRank = 0; loadoutRank = 100; quality = 1; price = 1100; };
	class Exile_Car_Kart_Yellow						{ traderRank = 0; loadoutRank = 100; quality = 1; price = 1100; };
	class Exile_Car_Kart_Black						{ traderRank = 0; loadoutRank = 100; quality = 1; price = 1100; };

	///////////////////////////////////////////////////////////////////////////////
	// MOTOR BOATS
	///////////////////////////////////////////////////////////////////////////////
	class Exile_Boat_MotorBoat_Police				{ traderRank = 5; loadoutRank = 100; quality = 1; price = 700; };
	class Exile_Boat_MotorBoat_Orange				{ traderRank = 0; loadoutRank = 100; quality = 1; price = 700; };
	class Exile_Boat_MotorBoat_White				{ traderRank = 0; loadoutRank = 100; quality = 1; price = 700; };

	///////////////////////////////////////////////////////////////////////////////
	// RUBBER DUCKS
	///////////////////////////////////////////////////////////////////////////////
	class Exile_Boat_RubberDuck_CSAT				{ traderRank = 0; loadoutRank = 100; quality = 1; price = 500; };
	class Exile_Boat_RubberDuck_Digital				{ traderRank = 0; loadoutRank = 100; quality = 1; price = 500; };
	class Exile_Boat_RubberDuck_Orange				{ traderRank = 0; loadoutRank = 100; quality = 1; price = 500; };
	class Exile_Boat_RubberDuck_Blue				{ traderRank = 0; loadoutRank = 100; quality = 1; price = 500; };
	class Exile_Boat_RubberDuck_Black				{ traderRank = 0; loadoutRank = 100; quality = 1; price = 500; };

	///////////////////////////////////////////////////////////////////////////////
	// SDV
	///////////////////////////////////////////////////////////////////////////////
	class Exile_Boat_SDV_CSAT						{ traderRank = 0; loadoutRank = 100; quality = 2; price = 11000; };
	class Exile_Boat_SDV_Digital					{ traderRank = 0; loadoutRank = 100; quality = 2; price = 11000; };
	class Exile_Boat_SDV_Grey						{ traderRank = 0; loadoutRank = 100; quality = 2; price = 11000; };

	///////////////////////////////////////////////////////////////////////////////
	// UH-1H Huey
	///////////////////////////////////////////////////////////////////////////////
	class Exile_Chopper_Huey_Green 					{ traderRank = 0; loadoutRank = 100; quality = 2; price = 21000; };
	class Exile_Chopper_Huey_Desert					{ traderRank = 0; loadoutRank = 100; quality = 2; price = 21000; };
	class Exile_Chopper_Huey_Armed_Green			{ traderRank = 0; loadoutRank = 100; quality = 2; price = 25000; };
	class Exile_Chopper_Huey_Armed_Desert			{ traderRank = 0; loadoutRank = 100; quality = 2; price = 25000; };

	///////////////////////////////////////////////////////////////////////////////
	// Hellcat
	///////////////////////////////////////////////////////////////////////////////
	class Exile_Chopper_Hellcat_Green				{ traderRank = 0; loadoutRank = 100; quality = 3; price = 27500; };
	class Exile_Chopper_Hellcat_FIA					{ traderRank = 0; loadoutRank = 100; quality = 3; price = 27500; };

	///////////////////////////////////////////////////////////////////////////////
	// Hummingbird
	///////////////////////////////////////////////////////////////////////////////
	class Exile_Chopper_Hummingbird_Green			{ traderRank = 0; loadoutRank = 100; quality = 3; price = 23000; };

	///////////////////////////////////////////////////////////////////////////////
	// Hummingbird (Civillian)
	///////////////////////////////////////////////////////////////////////////////
	class Exile_Chopper_Hummingbird_Civillian_Blue				{ traderRank = 0; loadoutRank = 100; quality = 1; price = 17000; };
	class Exile_Chopper_Hummingbird_Civillian_Red				{ traderRank = 0; loadoutRank = 100; quality = 1; price = 17000; };
	class Exile_Chopper_Hummingbird_Civillian_ION				{ traderRank = 0; loadoutRank = 100; quality = 1; price = 17000; };
	class Exile_Chopper_Hummingbird_Civillian_BlueLine			{ traderRank = 0; loadoutRank = 100; quality = 1; price = 17000; };
	class Exile_Chopper_Hummingbird_Civillian_Digital			{ traderRank = 0; loadoutRank = 100; quality = 1; price = 17000; };
	class Exile_Chopper_Hummingbird_Civillian_Elliptical		{ traderRank = 0; loadoutRank = 100; quality = 1; price = 17000; };
	class Exile_Chopper_Hummingbird_Civillian_Furious			{ traderRank = 0; loadoutRank = 100; quality = 1; price = 17000; };
	class Exile_Chopper_Hummingbird_Civillian_GrayWatcher		{ traderRank = 0; loadoutRank = 100; quality = 1; price = 17000; };
	class Exile_Chopper_Hummingbird_Civillian_Jeans				{ traderRank = 0; loadoutRank = 100; quality = 1; price = 17000; };
	class Exile_Chopper_Hummingbird_Civillian_Light				{ traderRank = 0; loadoutRank = 100; quality = 1; price = 17000; };
	class Exile_Chopper_Hummingbird_Civillian_Shadow			{ traderRank = 0; loadoutRank = 100; quality = 1; price = 17000; };
	class Exile_Chopper_Hummingbird_Civillian_Sheriff			{ traderRank = 0; loadoutRank = 100; quality = 1; price = 17000; };
	class Exile_Chopper_Hummingbird_Civillian_Speedy			{ traderRank = 0; loadoutRank = 100; quality = 1; price = 17000; };
	class Exile_Chopper_Hummingbird_Civillian_Sunset			{ traderRank = 0; loadoutRank = 100; quality = 1; price = 17000; };
	class Exile_Chopper_Hummingbird_Civillian_Vrana				{ traderRank = 0; loadoutRank = 100; quality = 1; price = 17000; };
	class Exile_Chopper_Hummingbird_Civillian_Wasp				{ traderRank = 0; loadoutRank = 100; quality = 1; price = 17000; };
	class Exile_Chopper_Hummingbird_Civillian_Wave				{ traderRank = 0; loadoutRank = 100; quality = 1; price = 17000; };

	///////////////////////////////////////////////////////////////////////////////
	// Huron
	///////////////////////////////////////////////////////////////////////////////
	class Exile_Chopper_Huron_Black								{ traderRank = 0; loadoutRank = 100; quality = 5; price = 50000; };
	class Exile_Chopper_Huron_Green								{ traderRank = 0; loadoutRank = 100; quality = 5; price = 50000; };

	///////////////////////////////////////////////////////////////////////////////
	// Mohawk
	///////////////////////////////////////////////////////////////////////////////
	class Exile_Chopper_Mohawk_FIA								{ traderRank = 0; loadoutRank = 100; quality = 4; price = 45000; };

	///////////////////////////////////////////////////////////////////////////////
	// Orca
	///////////////////////////////////////////////////////////////////////////////
	class Exile_Chopper_Orca_CSAT								{ traderRank = 0; loadoutRank = 100; quality = 3; price = 28000; };
	class Exile_Chopper_Orca_Black								{ traderRank = 0; loadoutRank = 100; quality = 3; price = 28000; };
	class Exile_Chopper_Orca_BlackCustom						{ traderRank = 0; loadoutRank = 100; quality = 3; price = 28000; };

	///////////////////////////////////////////////////////////////////////////////
	// Taru
	///////////////////////////////////////////////////////////////////////////////
	class Exile_Chopper_Taru_Transport_CSAT						{ traderRank = 0; loadoutRank = 100; quality = 3; price = 17000; };
	class Exile_Chopper_Taru_Transport_Black					{ traderRank = 0; loadoutRank = 100; quality = 3; price = 17000; };
	                                                                                      
	class Exile_Chopper_Taru_CSAT								{ traderRank = 0; loadoutRank = 100; quality = 4; price = 33000; };
	class Exile_Chopper_Taru_Black								{ traderRank = 0; loadoutRank = 100; quality = 4; price = 33000; };
                                                                                          
	class Exile_Chopper_Taru_Covered_CSAT						{ traderRank = 0; loadoutRank = 100; quality = 4; price = 43000; };
	class Exile_Chopper_Taru_Covered_Black						{ traderRank = 0; loadoutRank = 100; quality = 4; price = 43000; };

	///////////////////////////////////////////////////////////////////////////////
	// Cessna
	///////////////////////////////////////////////////////////////////////////////
	class Exile_Plane_Cessna									{ traderRank = 0; loadoutRank = 100; quality = 1; price = 16500; };

	///////////////////////////////////////////////////////////////////////////////
	// An-2
	///////////////////////////////////////////////////////////////////////////////
	class Exile_Plane_AN2_Green									{ traderRank = 0; loadoutRank = 100; quality = 2; price = 17000; };
	class Exile_Plane_AN2_White									{ traderRank = 0; loadoutRank = 100; quality = 2; price = 17000; };
	class Exile_Plane_AN2_Stripe								{ traderRank = 0; loadoutRank = 100; quality = 2; price = 17000; };
	
	///////////////////////////////////////////////////////////////////////////////
	// Hatchback
	///////////////////////////////////////////////////////////////////////////////
	class Exile_Car_Hatchback_Beige						{ traderRank = 0; loadoutRank = 100; quality = 3; price = 12000; };
	class Exile_Car_Hatchback_Green						{ traderRank = 0; loadoutRank = 100; quality = 3; price = 12000; };
	class Exile_Car_Hatchback_Blue						{ traderRank = 0; loadoutRank = 100; quality = 3; price = 12000; };
	class Exile_Car_Hatchback_BlueCustom				{ traderRank = 0; loadoutRank = 100; quality = 3; price = 12000; };
	class Exile_Car_Hatchback_BeigeCustom				{ traderRank = 0; loadoutRank = 100; quality = 3; price = 12000; };
	class Exile_Car_Hatchback_Yellow					{ traderRank = 0; loadoutRank = 100; quality = 3; price = 12000; };
	class Exile_Car_Hatchback_Grey						{ traderRank = 0; loadoutRank = 100; quality = 3; price = 12000; };
	class Exile_Car_Hatchback_Black						{ traderRank = 0; loadoutRank = 100; quality = 3; price = 12000; };
	class Exile_Car_Hatchback_Dark						{ traderRank = 0; loadoutRank = 100; quality = 3; price = 12000; };
	class Exile_Car_Hatchback_Rusty1					{ traderRank = 0; loadoutRank = 100; quality = 3; price = 12000; };
	class Exile_Car_Hatchback_Rusty2					{ traderRank = 0; loadoutRank = 100; quality = 3; price = 12000; };
	class Exile_Car_Hatchback_Rusty3					{ traderRank = 0; loadoutRank = 100; quality = 3; price = 12000; };
	
	///////////////////////////////////////////////////////////////////////////////
	// Golf
	///////////////////////////////////////////////////////////////////////////////
	class Exile_Car_Golf_Red							{ traderRank = 0; loadoutRank = 100; quality = 1; price = 8000; };
	class Exile_Car_Golf_Black							{ traderRank = 0; loadoutRank = 100; quality = 1; price = 8000; };

	///////////////////////////////////////////////////////////////////////////////
	// Ikarus
	///////////////////////////////////////////////////////////////////////////////
	class Exile_Car_Ikarus_Blue 				{ traderRank = 0; loadoutRank = 100; quality = 1; price = 17000; };
	class Exile_Car_Ikarus_Red 					{ traderRank = 0; loadoutRank = 100; quality = 1; price = 17000; };
	class Exile_Car_Ikarus_Party 				{ traderRank = 0; loadoutRank = 100; quality = 1; price = 17000; };

	///////////////////////////////////////////////////////////////////////////////
	// Ural (Open)
	///////////////////////////////////////////////////////////////////////////////
	class Exile_Car_Ural_Open_Blue			{ traderRank = 0; loadoutRank = 100; quality = 2; price = 25000; };
	class Exile_Car_Ural_Open_Yellow		{ traderRank = 0; loadoutRank = 100; quality = 2; price = 25000; };
	class Exile_Car_Ural_Open_Worker		{ traderRank = 0; loadoutRank = 100; quality = 2; price = 25000; };
	class Exile_Car_Ural_Open_Military		{ traderRank = 0; loadoutRank = 100; quality = 2; price = 25000; };

	///////////////////////////////////////////////////////////////////////////////
	// Ural (Covered)
	///////////////////////////////////////////////////////////////////////////////
	class Exile_Car_Ural_Covered_Blue			{ traderRank = 0; loadoutRank = 100; quality = 2; price = 28000; };
	class Exile_Car_Ural_Covered_Yellow			{ traderRank = 0; loadoutRank = 100; quality = 2; price = 28000; };
	class Exile_Car_Ural_Covered_Worker			{ traderRank = 0; loadoutRank = 100; quality = 2; price = 28000; };
	class Exile_Car_Ural_Covered_Military		{ traderRank = 0; loadoutRank = 100; quality = 2; price = 28000; };
	
	///////////////////////////////////////////////////////////////////////////////
	// V3S
	///////////////////////////////////////////////////////////////////////////////
	class Exile_Car_V3S_Open			{ traderRank = 0; loadoutRank = 100; quality = 2; price = 28000; };
	class Exile_Car_V3S_Covered			{ traderRank = 0; loadoutRank = 100; quality = 2; price = 28000; };

	///////////////////////////////////////////////////////////////////////////////
	// SUVXL
	///////////////////////////////////////////////////////////////////////////////
	class Exile_Car_SUVXL_Black 				{ traderRank = 0; loadoutRank = 100; quality = 3; price = 20000; };
	
	///////////////////////////////////////////////////////////////////////////////
	// Tractor
	///////////////////////////////////////////////////////////////////////////////
	class Exile_Car_Tractor_Red 				{ traderRank = 0; loadoutRank = 100; quality = 1; price = 2000; };

	///////////////////////////////////////////////////////////////////////////////
	// Tractor (Old)
	///////////////////////////////////////////////////////////////////////////////
	class Exile_Car_OldTractor_Red 				{ traderRank = 0; loadoutRank = 100; quality = 1; price = 1200; };

	///////////////////////////////////////////////////////////////////////////////
	// Tow Tractor
	///////////////////////////////////////////////////////////////////////////////
	class Exile_Car_TowTractor_White			{ traderRank = 0; loadoutRank = 100; quality = 1; price = 1800; };

	///////////////////////////////////////////////////////////////////////////////
	// Octavius
	///////////////////////////////////////////////////////////////////////////////
	class Exile_Car_Octavius_White				{ traderRank = 0; loadoutRank = 100; quality = 2; price = 6000; };
	class Exile_Car_Octavius_Black				{ traderRank = 0; loadoutRank = 100; quality = 2; price = 6000; };

	///////////////////////////////////////////////////////////////////////////////
	// UAZ
	///////////////////////////////////////////////////////////////////////////////
	class Exile_Car_UAZ_Green				{ traderRank = 0; loadoutRank = 100; quality = 2; price = 7000; };

	///////////////////////////////////////////////////////////////////////////////
	// UAZ (Open)
	///////////////////////////////////////////////////////////////////////////////
	class Exile_Car_UAZ_Open_Green			{ traderRank = 0; loadoutRank = 100; quality = 2; price = 8000; };

	///////////////////////////////////////////////////////////////////////////////
	// Land Rover
	///////////////////////////////////////////////////////////////////////////////
	class Exile_Car_LandRover_Red 				{ traderRank = 0; loadoutRank = 100; quality = 3; price = 11000; };
	class Exile_Car_LandRover_Urban 			{ traderRank = 0; loadoutRank = 100; quality = 3; price = 11000; };
	class Exile_Car_LandRover_Green 			{ traderRank = 0; loadoutRank = 100; quality = 3; price = 11000; };
	class Exile_Car_LandRover_Sand 				{ traderRank = 0; loadoutRank = 100; quality = 3; price = 11000; };
	class Exile_Car_LandRover_Desert 			{ traderRank = 0; loadoutRank = 100; quality = 3; price = 11000; };

	///////////////////////////////////////////////////////////////////////////////
	// Land Rover (Ambulance)
	///////////////////////////////////////////////////////////////////////////////
	class Exile_Car_LandRover_Ambulance_Green		{ traderRank = 0; loadoutRank = 100; quality = 3; price = 12000; };
	class Exile_Car_LandRover_Ambulance_Desert		{ traderRank = 0; loadoutRank = 100; quality = 3; price = 12000; };
	class Exile_Car_LandRover_Ambulance_Sand		{ traderRank = 0; loadoutRank = 100; quality = 3; price = 12000; };

	///////////////////////////////////////////////////////////////////////////////
	// Lada
	///////////////////////////////////////////////////////////////////////////////
	class Exile_Car_Lada_Green 				{ traderRank = 0; loadoutRank = 100; quality = 2; price = 6000; };
	class Exile_Car_Lada_Taxi 				{ traderRank = 0; loadoutRank = 100; quality = 2; price = 6000; };
	class Exile_Car_Lada_Red 				{ traderRank = 0; loadoutRank = 100; quality = 2; price = 6000; };
	class Exile_Car_Lada_White 				{ traderRank = 0; loadoutRank = 100; quality = 2; price = 6000; };
	class Exile_Car_Lada_Hipster 			{ traderRank = 0; loadoutRank = 100; quality = 2; price = 6000; };

	///////////////////////////////////////////////////////////////////////////////
	// Volha
	///////////////////////////////////////////////////////////////////////////////
	class Exile_Car_Volha_Blue				{ traderRank = 0; loadoutRank = 100; quality = 2; price = 6000; };
	class Exile_Car_Volha_White				{ traderRank = 0; loadoutRank = 100; quality = 2; price = 6000; };
	class Exile_Car_Volha_Black				{ traderRank = 0; loadoutRank = 100; quality = 2; price = 6000; };

	///////////////////////////////////////////////////////////////////////////////
	// Hatchback (Sport)
	///////////////////////////////////////////////////////////////////////////////
	class Exile_Car_Hatchback_Sport_Red					{ traderRank = 0; loadoutRank = 100; quality = 4; price = 14000; };
	class Exile_Car_Hatchback_Sport_Blue				{ traderRank = 0; loadoutRank = 100; quality = 4; price = 14000; };
	class Exile_Car_Hatchback_Sport_Orange				{ traderRank = 0; loadoutRank = 100; quality = 4; price = 14000; };
	class Exile_Car_Hatchback_Sport_White				{ traderRank = 0; loadoutRank = 100; quality = 4; price = 14000; };
	class Exile_Car_Hatchback_Sport_Beige				{ traderRank = 0; loadoutRank = 100; quality = 4; price = 14000; };
	class Exile_Car_Hatchback_Sport_Green				{ traderRank = 0; loadoutRank = 100; quality = 4; price = 14000; };

	///////////////////////////////////////////////////////////////////////////////
	// HEMMT
	///////////////////////////////////////////////////////////////////////////////
	class Exile_Car_HEMMT 								{ traderRank = 0; loadoutRank = 100; quality = 3; price = 48000; };

	///////////////////////////////////////////////////////////////////////////////
	// Hunter
	///////////////////////////////////////////////////////////////////////////////
	class Exile_Car_Hunter 								{ traderRank = 5; loadoutRank = 100; quality = 5; price = 26500; };

	///////////////////////////////////////////////////////////////////////////////
	// Ifrit
	///////////////////////////////////////////////////////////////////////////////
	class Exile_Car_Ifrit 								{ traderRank = 5; loadoutRank = 100; quality = 4; price = 23000; };

	///////////////////////////////////////////////////////////////////////////////
	// Offroad
	///////////////////////////////////////////////////////////////////////////////
	class Exile_Car_Offroad_Red							{ traderRank = 0; loadoutRank = 100; quality = 3; price = 16000; };
	class Exile_Car_Offroad_Beige						{ traderRank = 0; loadoutRank = 100; quality = 3; price = 16000; };
	class Exile_Car_Offroad_White						{ traderRank = 0; loadoutRank = 100; quality = 3; price = 16000; };
	class Exile_Car_Offroad_Blue						{ traderRank = 0; loadoutRank = 100; quality = 3; price = 16000; };
	class Exile_Car_Offroad_DarkRed						{ traderRank = 0; loadoutRank = 100; quality = 3; price = 16000; };
	class Exile_Car_Offroad_BlueCustom					{ traderRank = 0; loadoutRank = 100; quality = 3; price = 16000; };
	class Exile_Car_Offroad_Guerilla01					{ traderRank = 0; loadoutRank = 100; quality = 3; price = 16000; };
	class Exile_Car_Offroad_Guerilla02					{ traderRank = 0; loadoutRank = 100; quality = 3; price = 16000; };
	class Exile_Car_Offroad_Guerilla03					{ traderRank = 0; loadoutRank = 100; quality = 3; price = 16000; };
	class Exile_Car_Offroad_Guerilla04					{ traderRank = 0; loadoutRank = 100; quality = 3; price = 16000; };
	class Exile_Car_Offroad_Guerilla05					{ traderRank = 0; loadoutRank = 100; quality = 3; price = 16000; };
	class Exile_Car_Offroad_Guerilla06					{ traderRank = 0; loadoutRank = 100; quality = 3; price = 16000; };
	class Exile_Car_Offroad_Guerilla07					{ traderRank = 0; loadoutRank = 100; quality = 3; price = 16000; };
	class Exile_Car_Offroad_Guerilla08					{ traderRank = 0; loadoutRank = 100; quality = 3; price = 16000; };
	class Exile_Car_Offroad_Guerilla09					{ traderRank = 0; loadoutRank = 100; quality = 3; price = 16000; };
	class Exile_Car_Offroad_Guerilla10					{ traderRank = 0; loadoutRank = 100; quality = 3; price = 16000; };
	class Exile_Car_Offroad_Guerilla11					{ traderRank = 0; loadoutRank = 100; quality = 3; price = 16000; };
	class Exile_Car_Offroad_Guerilla12					{ traderRank = 0; loadoutRank = 100; quality = 3; price = 16000; };
	class Exile_Car_Offroad_Rusty1						{ traderRank = 0; loadoutRank = 100; quality = 3; price = 16000; };
	class Exile_Car_Offroad_Rusty2						{ traderRank = 0; loadoutRank = 100; quality = 3; price = 16000; };
	class Exile_Car_Offroad_Rusty3						{ traderRank = 0; loadoutRank = 100; quality = 3; price = 16000; };

	///////////////////////////////////////////////////////////////////////////////
	// Offroad (Armed)
	///////////////////////////////////////////////////////////////////////////////
	class Exile_Car_Offroad_Armed_Guerilla01 			{ traderRank = 0; loadoutRank = 100; quality = 5; price = 25000; };
	class Exile_Car_Offroad_Armed_Guerilla02 			{ traderRank = 0; loadoutRank = 100; quality = 5; price = 25000; };
	class Exile_Car_Offroad_Armed_Guerilla03 			{ traderRank = 0; loadoutRank = 100; quality = 5; price = 25000; };
	class Exile_Car_Offroad_Armed_Guerilla04 			{ traderRank = 0; loadoutRank = 100; quality = 5; price = 25000; };
	class Exile_Car_Offroad_Armed_Guerilla05 			{ traderRank = 0; loadoutRank = 100; quality = 5; price = 25000; };
	class Exile_Car_Offroad_Armed_Guerilla06 			{ traderRank = 0; loadoutRank = 100; quality = 5; price = 25000; };
	class Exile_Car_Offroad_Armed_Guerilla07 			{ traderRank = 0; loadoutRank = 100; quality = 5; price = 25000; };
	class Exile_Car_Offroad_Armed_Guerilla08 			{ traderRank = 0; loadoutRank = 100; quality = 5; price = 25000; };
	class Exile_Car_Offroad_Armed_Guerilla09 			{ traderRank = 0; loadoutRank = 100; quality = 5; price = 25000; };
	class Exile_Car_Offroad_Armed_Guerilla10 			{ traderRank = 0; loadoutRank = 100; quality = 5; price = 25000; };
	class Exile_Car_Offroad_Armed_Guerilla11 			{ traderRank = 0; loadoutRank = 100; quality = 5; price = 25000; };
	class Exile_Car_Offroad_Armed_Guerilla12 			{ traderRank = 0; loadoutRank = 100; quality = 5; price = 25000; };

	///////////////////////////////////////////////////////////////////////////////
	// Offroad (Repair)
	///////////////////////////////////////////////////////////////////////////////
	class Exile_Car_Offroad_Repair_Civillian 			{ traderRank = 0; loadoutRank = 100; quality = 4; price = 12500; };
	class Exile_Car_Offroad_Repair_Red 					{ traderRank = 0; loadoutRank = 100; quality = 4; price = 12500; };
	class Exile_Car_Offroad_Repair_Beige 				{ traderRank = 0; loadoutRank = 100; quality = 4; price = 12500; };
	class Exile_Car_Offroad_Repair_White 				{ traderRank = 0; loadoutRank = 100; quality = 4; price = 12500; };
	class Exile_Car_Offroad_Repair_Blue 				{ traderRank = 0; loadoutRank = 100; quality = 4; price = 12500; };
	class Exile_Car_Offroad_Repair_DarkRed 				{ traderRank = 0; loadoutRank = 100; quality = 4; price = 12500; };
	class Exile_Car_Offroad_Repair_BlueCustom 			{ traderRank = 0; loadoutRank = 100; quality = 4; price = 12500; };
	class Exile_Car_Offroad_Repair_Guerilla01 			{ traderRank = 0; loadoutRank = 100; quality = 4; price = 12500; };
	class Exile_Car_Offroad_Repair_Guerilla02 			{ traderRank = 0; loadoutRank = 100; quality = 4; price = 12500; };
	class Exile_Car_Offroad_Repair_Guerilla03 			{ traderRank = 0; loadoutRank = 100; quality = 4; price = 12500; };
	class Exile_Car_Offroad_Repair_Guerilla04 			{ traderRank = 0; loadoutRank = 100; quality = 4; price = 12500; };
	class Exile_Car_Offroad_Repair_Guerilla05 			{ traderRank = 0; loadoutRank = 100; quality = 4; price = 12500; };
	class Exile_Car_Offroad_Repair_Guerilla06 			{ traderRank = 0; loadoutRank = 100; quality = 4; price = 12500; };
	class Exile_Car_Offroad_Repair_Guerilla07 			{ traderRank = 0; loadoutRank = 100; quality = 4; price = 12500; };
	class Exile_Car_Offroad_Repair_Guerilla08 			{ traderRank = 0; loadoutRank = 100; quality = 4; price = 12500; };
	class Exile_Car_Offroad_Repair_Guerilla09 			{ traderRank = 0; loadoutRank = 100; quality = 4; price = 12500; };
	class Exile_Car_Offroad_Repair_Guerilla10 			{ traderRank = 0; loadoutRank = 100; quality = 4; price = 12500; };
	class Exile_Car_Offroad_Repair_Guerilla11 			{ traderRank = 0; loadoutRank = 100; quality = 4; price = 12500; };
	class Exile_Car_Offroad_Repair_Guerilla12 			{ traderRank = 0; loadoutRank = 100; quality = 4; price = 12500; };

	///////////////////////////////////////////////////////////////////////////////
	// Strider
	///////////////////////////////////////////////////////////////////////////////
	class Exile_Car_Strider 							{ traderRank = 5; loadoutRank = 100; quality = 6; price = 44000; };

	///////////////////////////////////////////////////////////////////////////////
	// SUV
	///////////////////////////////////////////////////////////////////////////////
	class Exile_Car_SUV_Red 							{ traderRank = 0; loadoutRank = 100; quality = 3; price = 14000; };
	class Exile_Car_SUV_Black 							{ traderRank = 0; loadoutRank = 100; quality = 3; price = 14000; };
	class Exile_Car_SUV_Grey 							{ traderRank = 0; loadoutRank = 100; quality = 3; price = 14000; };
	class Exile_Car_SUV_Orange 							{ traderRank = 0; loadoutRank = 100; quality = 3; price = 14000; };

	///////////////////////////////////////////////////////////////////////////////
	// SUV (Armed)
	///////////////////////////////////////////////////////////////////////////////
	class Exile_Car_SUV_Armed_Black 					{ traderRank = 10; loadoutRank = 100; quality = 4; price = 25000; };
	
	///////////////////////////////////////////////////////////////////////////////
	// BRDM2
	///////////////////////////////////////////////////////////////////////////////
	class Exile_Car_BRDM2_HQ 							{ traderRank = 5; loadoutRank = 100; quality = 5; price = 25000; };
	
	///////////////////////////////////////////////////////////////////////////////
	// BTR40
	///////////////////////////////////////////////////////////////////////////////
	class Exile_Car_BTR40_MG_Green 							{ traderRank = 10; loadoutRank = 100; quality = 6; price = 38000; };
	class Exile_Car_BTR40_MG_Camo 							{ traderRank = 10; loadoutRank = 100; quality = 6; price = 38000; };
	class Exile_Car_BTR40_Green 							{ traderRank = 10; loadoutRank = 100; quality = 2; price = 15000; };
	class Exile_Car_BTR40_Camo 								{ traderRank = 10; loadoutRank = 100; quality = 2; price = 15000; };
	
	///////////////////////////////////////////////////////////////////////////////
	// HMMWV
	///////////////////////////////////////////////////////////////////////////////
	class Exile_Car_HMMWV_M134_Green 							{ traderRank = 10; loadoutRank = 100; quality = 5; price = 33000; };
	class Exile_Car_HMMWV_M134_Desert 							{ traderRank = 10; loadoutRank = 100; quality = 5; price = 33000; };
	class Exile_Car_HMMWV_M2_Green 								{ traderRank = 10; loadoutRank = 100; quality = 6; price = 40000; };
	class Exile_Car_HMMWV_M2_Desert 							{ traderRank = 10; loadoutRank = 100; quality = 6; price = 40000; };
	class Exile_Car_HMMWV_MEV_Green 							{ traderRank = 0; loadoutRank = 100; quality = 3; price = 21000; };
	class Exile_Car_HMMWV_MEV_Desert 							{ traderRank = 0; loadoutRank = 100; quality = 3; price = 21000; };
	class Exile_Car_HMMWV_UNA_Green 							{ traderRank = 0; loadoutRank = 100; quality = 3; price = 21000; };
	class Exile_Car_HMMWV_UNA_Desert 							{ traderRank = 0; loadoutRank = 100; quality = 3; price = 21000; };
	
	///////////////////////////////////////////////////////////////////////////////
	// Tempest
	///////////////////////////////////////////////////////////////////////////////
	class Exile_Car_Tempest 							{ traderRank = 0; loadoutRank = 100; quality = 4; price = 48300; };

	///////////////////////////////////////////////////////////////////////////////
	// Van 
	///////////////////////////////////////////////////////////////////////////////
	class Exile_Car_Van_Black 							{ traderRank = 0; loadoutRank = 100; quality = 2; price = 12000; };
	class Exile_Car_Van_White 							{ traderRank = 0; loadoutRank = 100; quality = 2; price = 12000; };
	class Exile_Car_Van_Red 							{ traderRank = 0; loadoutRank = 100; quality = 2; price = 12000; };
	class Exile_Car_Van_Guerilla01 						{ traderRank = 0; loadoutRank = 100; quality = 2; price = 12000; };
	class Exile_Car_Van_Guerilla02 						{ traderRank = 0; loadoutRank = 100; quality = 2; price = 12000; };
	class Exile_Car_Van_Guerilla03 						{ traderRank = 0; loadoutRank = 100; quality = 2; price = 12000; };
	class Exile_Car_Van_Guerilla04 						{ traderRank = 0; loadoutRank = 100; quality = 2; price = 12000; };
	class Exile_Car_Van_Guerilla05 						{ traderRank = 0; loadoutRank = 100; quality = 2; price = 12000; };
	class Exile_Car_Van_Guerilla06 						{ traderRank = 0; loadoutRank = 100; quality = 2; price = 12000; };
	class Exile_Car_Van_Guerilla07 						{ traderRank = 0; loadoutRank = 100; quality = 2; price = 12000; };
	class Exile_Car_Van_Guerilla08 						{ traderRank = 0; loadoutRank = 100; quality = 2; price = 12000; };

	///////////////////////////////////////////////////////////////////////////////
	// Van (Box) 
	///////////////////////////////////////////////////////////////////////////////
	class Exile_Car_Van_Box_Black 						{ traderRank = 0; loadoutRank = 100; quality = 3; price = 17000; };
	class Exile_Car_Van_Box_White 						{ traderRank = 0; loadoutRank = 100; quality = 3; price = 17000; };
	class Exile_Car_Van_Box_Red 						{ traderRank = 0; loadoutRank = 100; quality = 3; price = 17000; };
	class Exile_Car_Van_Box_Guerilla01 					{ traderRank = 0; loadoutRank = 100; quality = 3; price = 17000; };
	class Exile_Car_Van_Box_Guerilla02 					{ traderRank = 0; loadoutRank = 100; quality = 3; price = 17000; };
	class Exile_Car_Van_Box_Guerilla03 					{ traderRank = 0; loadoutRank = 100; quality = 3; price = 17000; };
	class Exile_Car_Van_Box_Guerilla04 					{ traderRank = 0; loadoutRank = 100; quality = 3; price = 17000; };
	class Exile_Car_Van_Box_Guerilla05 					{ traderRank = 0; loadoutRank = 100; quality = 3; price = 17000; };
	class Exile_Car_Van_Box_Guerilla06 					{ traderRank = 0; loadoutRank = 100; quality = 3; price = 17000; };
	class Exile_Car_Van_Box_Guerilla07 					{ traderRank = 0; loadoutRank = 100; quality = 3; price = 17000; };
	class Exile_Car_Van_Box_Guerilla08 					{ traderRank = 0; loadoutRank = 100; quality = 3; price = 17000; };

	///////////////////////////////////////////////////////////////////////////////
	// Van (Fuel) 
	///////////////////////////////////////////////////////////////////////////////
	class Exile_Car_Van_Fuel_Black 						{ traderRank = 0; loadoutRank = 100; quality = 3; price = 15000; };
	class Exile_Car_Van_Fuel_White 						{ traderRank = 0; loadoutRank = 100; quality = 3; price = 15000; };
	class Exile_Car_Van_Fuel_Red 						{ traderRank = 0; loadoutRank = 100; quality = 3; price = 15000; };
	class Exile_Car_Van_Fuel_Guerilla01 				{ traderRank = 0; loadoutRank = 100; quality = 3; price = 15000; };
	class Exile_Car_Van_Fuel_Guerilla02 				{ traderRank = 0; loadoutRank = 100; quality = 3; price = 15000; };
	class Exile_Car_Van_Fuel_Guerilla03 				{ traderRank = 0; loadoutRank = 100; quality = 3; price = 15000; };

	///////////////////////////////////////////////////////////////////////////////
	// Zamak
	///////////////////////////////////////////////////////////////////////////////
	class Exile_Car_Zamak 								{ traderRank = 0; loadoutRank = 100; quality = 4; price = 43000; };
	
	///////////////////////////////////////////////////////////////////////////////
	// Water Scooter
	///////////////////////////////////////////////////////////////////////////////
	class Exile_Boat_WaterScooter						{ traderRank = 0; loadoutRank = 100; quality = 2; price = 800; };
	
	///////////////////////////////////////////////////////////////////////////////
	// RHIB
	///////////////////////////////////////////////////////////////////////////////
	class Exile_Boat_RHIB								{ traderRank = 0; loadoutRank = 100; quality = 3; price = 1500; };
	
	///////////////////////////////////////////////////////////////////////////////
	// Ceaser BTT
	///////////////////////////////////////////////////////////////////////////////
	class Exile_Plane_Ceasar							{ traderRank = 0; loadoutRank = 100; quality = 2; price = 15000; };
	
	///////////////////////////////////////////////////////////////////////////////
	// V-44 X Blackfish
	///////////////////////////////////////////////////////////////////////////////
	class Exile_Plane_BlackfishInfantry							{ traderRank = 0; loadoutRank = 100; quality = 6; price = 60000; };
	class Exile_Plane_BlackfishVehicle							{ traderRank = 0; loadoutRank = 100; quality = 6; price = 60000; };
	
	///////////////////////////////////////////////////////////////////////////////
	// Prowler
	///////////////////////////////////////////////////////////////////////////////
	class Exile_Car_ProwlerLight							{ traderRank = 0; loadoutRank = 100; quality = 3; price = 22000; };
	class Exile_Car_ProwlerUnarmed							{ traderRank = 0; loadoutRank = 100; quality = 3; price = 22000; };
	
	///////////////////////////////////////////////////////////////////////////////
	// Qilin
	///////////////////////////////////////////////////////////////////////////////
	class Exile_Car_QilinUnarmed							{ traderRank = 0; loadoutRank = 100; quality = 3; price = 21000; };
	
	///////////////////////////////////////////////////////////////////////////////
	// MB 4WD
	///////////////////////////////////////////////////////////////////////////////
	class Exile_Car_MB4WD							{ traderRank = 0; loadoutRank = 100; quality = 2; price = 15000; };
	class Exile_Car_MB4WDOpen							{ traderRank = 0; loadoutRank = 100; quality = 2; price = 15000; };
	
	///////////////////////////////////////////////////////////////////////////////
	// Flags
	///////////////////////////////////////////////////////////////////////////////
	class Exile_Item_FlagStolen1						{ traderRank = 0; loadoutRank = 100; quality = 1; price = 5000;  sellPrice = 5000;  };
	class Exile_Item_FlagStolen2						{ traderRank = 0; loadoutRank = 100; quality = 1; price = 10000; sellPrice = 10000; };
	class Exile_Item_FlagStolen3						{ traderRank = 0; loadoutRank = 100; quality = 1; price = 15000; sellPrice = 15000; };
	class Exile_Item_FlagStolen4						{ traderRank = 0; loadoutRank = 100; quality = 1; price = 20000; sellPrice = 20000; };
	class Exile_Item_FlagStolen5						{ traderRank = 0; loadoutRank = 100; quality = 1; price = 25000; sellPrice = 25000; };
	class Exile_Item_FlagStolen6						{ traderRank = 0; loadoutRank = 100; quality = 1; price = 30000; sellPrice = 30000; };
	class Exile_Item_FlagStolen7						{ traderRank = 0; loadoutRank = 100; quality = 1; price = 35000; sellPrice = 35000; };
	class Exile_Item_FlagStolen8						{ traderRank = 0; loadoutRank = 100; quality = 1; price = 40000; sellPrice = 40000; };
	class Exile_Item_FlagStolen9						{ traderRank = 0; loadoutRank = 100; quality = 1; price = 45000; sellPrice = 45000; };
	class Exile_Item_FlagStolen10						{ traderRank = 0; loadoutRank = 100; quality = 1; price = 50000; sellPrice = 50000; };