    ///////////////////////////////////////////////////////////////////////////////
    // class ACE MEDICAL
    ///////////////////////////////////////////////////////////////////////////////
	class ACE_fieldDressing       					{ quality = 1; price = 100; };
	class ACE_packingBandage						{ quality = 1; price = 100; };
	class ACE_elasticBandage						{ quality = 1; price = 100; };
	class ACE_quikclot								{ quality = 1; price = 150; };
	class ACE_tourniquet							{ quality = 1; price = 150; };
	class ACE_atropine								{ quality = 1; price = 150; };
	class ACE_morphine								{ quality = 1; price = 150; };
	class ACE_epinephrine							{ quality = 1; price = 100; };
	class ACE_plasmaIV								{ quality = 1; price = 100; };
	class ACE_plasmaIV_250							{ quality = 1; price = 100; };
	class ACE_plasmaIV_500							{ quality = 1; price = 100; };
	class ACE_salineIV								{ quality = 1; price = 100; };
	class ACE_salineIV_250							{ quality = 1; price = 100; };
	class ACE_salineIV_500							{ quality = 1; price = 100; };
	class ACE_bloodIV								{ quality = 1; price = 100; };
	class ACE_bloodIV_250							{ quality = 1; price = 100; };
	class ACE_bloodIV_500							{ quality = 1; price = 100; };
	class ACE_personalAidKit						{ quality = 1; price = 250; };
	class ACE_surgicalKit							{ quality = 1; price = 500; };
	class ACE_bodyBag								{ quality = 1; price = 300; };


   
