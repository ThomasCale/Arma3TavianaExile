	// Sanitize with Whiskey
	class TornRagsSanitized101: Exile_AbstractCraftingRecipe
	{
		name = "Sanitize Rags w/Whiskey";
		pictureItem = "eXpoch_Rag00_Item";
		returnedItems[] =
		{
			{1, "eXpoch_Rag00_Item"}
		};
		tools[] = {};
		components[] = 
		{
			{1, "eXpoch_Rag01_Item"},
			{1, "eXpoch_WhiskeyNoodle"}
		};
		requiresFire = 0;
		category = "Medical";
	};
	class TornRagsSanitized102: Exile_AbstractCraftingRecipe
	{
		name = "Sanitize Rags w/Whiskey";
		pictureItem = "eXpoch_Rag00_Item";
		returnedItems[] =
		{
			{1, "eXpoch_Rag00_Item"}
		};
		tools[] = {};
		components[] = 
		{
			{1, "eXpoch_Rag02_Item"},
			{1, "eXpoch_WhiskeyNoodle"}
		};
		requiresFire = 0;
		category = "Medical";
	};
	class TornRagsSanitized103: Exile_AbstractCraftingRecipe
	{
		name = "Sanitize Rags w/Whiskey";
		pictureItem = "eXpoch_Rag00_Item";
		returnedItems[] =
		{
			{1, "eXpoch_Rag00_Item"}
		};
		tools[] = {};
		components[] = 
		{
			{1, "eXpoch_Rag03_Item"},
			{1, "eXpoch_WhiskeyNoodle"}
		};
		requiresFire = 0;
		category = "Medical";
	};
	class TornRagsSanitized104: Exile_AbstractCraftingRecipe
	{
		name = "Sanitize Rags w/Whiskey";
		pictureItem = "eXpoch_Rag00_Item";
		returnedItems[] =
		{
			{1, "eXpoch_Rag00_Item"}
		};
		tools[] = {};
		components[] = 
		{
			{1, "eXpoch_Rag04_Item"},
			{1, "eXpoch_WhiskeyNoodle"}
		};
		requiresFire = 0;
		category = "Medical";
	};
	class TornRagsSanitized105: Exile_AbstractCraftingRecipe
	{
		name = "Sanitize Rags w/Whiskey";
		pictureItem = "eXpoch_Rag00_Item";
		returnedItems[] =
		{
			{1, "eXpoch_Rag00_Item"}
		};
		tools[] = {};
		components[] = 
		{
			{1, "eXpoch_Rag05_Item"},
			{1, "eXpoch_WhiskeyNoodle"}
		};
		requiresFire = 0;
		category = "Medical";
	};
	class TornRagsSanitized106: Exile_AbstractCraftingRecipe
	{
		name = "Sanitize Rags w/Whiskey";
		pictureItem = "eXpoch_Rag00_Item";
		returnedItems[] =
		{
			{1, "eXpoch_Rag00_Item"}
		};
		tools[] = {};
		components[] = 
		{
			{1, "eXpoch_Rag06_Item"},
			{1, "eXpoch_WhiskeyNoodle"}
		};
		requiresFire = 0;
		category = "Medical";
	};
	class TornRagsSanitized107: Exile_AbstractCraftingRecipe
	{
		name = "Sanitize Rags w/Whiskey";
		pictureItem = "eXpoch_Rag00_Item";
		returnedItems[] =
		{
			{1, "eXpoch_Rag00_Item"}
		};
		tools[] = {};
		components[] = 
		{
			{1, "eXpoch_Rag07_Item"},
			{1, "eXpoch_WhiskeyNoodle"}
		};
		requiresFire = 0;
		category = "Medical";
	};
	class TornRagsSanitized108: Exile_AbstractCraftingRecipe
	{
		name = "Sanitize Rags w/Whiskey";
		pictureItem = "eXpoch_Rag00_Item";
		returnedItems[] =
		{
			{1, "eXpoch_Rag00_Item"}
		};
		tools[] = {};
		components[] = 
		{
			{1, "eXpoch_Rag08_Item"},
			{1, "eXpoch_WhiskeyNoodle"}
		};
		requiresFire = 0;
		category = "Medical";
	};
	class TornRagsSanitized109: Exile_AbstractCraftingRecipe
	{
		name = "Sanitize Rags w/Whiskey";
		pictureItem = "eXpoch_Rag00_Item";
		returnedItems[] =
		{
			{1, "eXpoch_Rag00_Item"}
		};
		tools[] = {};
		components[] = 
		{
			{1, "eXpoch_Rag09_Item"},
			{1, "eXpoch_WhiskeyNoodle"}
		};
		requiresFire = 0;
		category = "Medical";
	};
	class TornRagsSanitized110: Exile_AbstractCraftingRecipe
	{
		name = "Sanitize Rags w/Whiskey";
		pictureItem = "eXpoch_Rag00_Item";
		returnedItems[] =
		{
			{1, "eXpoch_Rag00_Item"}
		};
		tools[] = {};
		components[] = 
		{
			{1, "eXpoch_Rag10_Item"},
			{1, "eXpoch_WhiskeyNoodle"}
		};
		requiresFire = 0;
		category = "Medical";
	};
	class TornRagsSanitized111: Exile_AbstractCraftingRecipe
	{
		name = "Sanitize Rags w/Whiskey";
		pictureItem = "eXpoch_Rag00_Item";
		returnedItems[] =
		{
			{1, "eXpoch_Rag00_Item"}
		};
		tools[] = {};
		components[] = 
		{
			{1, "eXpoch_Rag11_Item"},
			{1, "eXpoch_WhiskeyNoodle"}
		};
		requiresFire = 0;
		category = "Medical";
	};
	class TornRagsSanitized112: Exile_AbstractCraftingRecipe
	{
		name = "Sanitize Rags w/Whiskey";
		pictureItem = "eXpoch_Rag00_Item";
		returnedItems[] =
		{
			{1, "eXpoch_Rag00_Item"}
		};
		tools[] = {};
		components[] = 
		{
			{1, "eXpoch_Rag12_Item"},
			{1, "eXpoch_WhiskeyNoodle"}
		};
		requiresFire = 0;
		category = "Medical";
	};
	class TornRagsSanitized113: Exile_AbstractCraftingRecipe
	{
		name = "Sanitize Rags w/Whiskey";
		pictureItem = "eXpoch_Rag00_Item";
		returnedItems[] =
		{
			{1, "eXpoch_Rag00_Item"}
		};
		tools[] = {};
		components[] = 
		{
			{1, "eXpoch_Rag13_Item"},
			{1, "eXpoch_WhiskeyNoodle"}
		};
		requiresFire = 0;
		category = "Medical";
	};
	class TornRagsSanitized114: Exile_AbstractCraftingRecipe
	{
		name = "Sanitize Rags w/Whiskey";
		pictureItem = "eXpoch_Rag00_Item";
		returnedItems[] =
		{
			{1, "eXpoch_Rag00_Item"}
		};
		tools[] = {};
		components[] = 
		{
			{1, "eXpoch_Rag14_Item"},
			{1, "eXpoch_WhiskeyNoodle"}
		};
		requiresFire = 0;
		category = "Medical";
	};
	class TornRagsSanitized115: Exile_AbstractCraftingRecipe
	{
		name = "Sanitize Rags w/Whiskey";
		pictureItem = "eXpoch_Rag00_Item";
		returnedItems[] =
		{
			{1, "eXpoch_Rag00_Item"}
		};
		tools[] = {};
		components[] = 
		{
			{1, "eXpoch_Rag15_Item"},
			{1, "eXpoch_WhiskeyNoodle"}
		};
		requiresFire = 0;
		category = "Medical";
	};
	class TornRagsSanitized116: Exile_AbstractCraftingRecipe
	{
		name = "Sanitize Rags w/Whiskey";
		pictureItem = "eXpoch_Rag00_Item";
		returnedItems[] =
		{
			{1, "eXpoch_Rag00_Item"}
		};
		tools[] = {};
		components[] = 
		{
			{1, "eXpoch_Rag16_Item"},
			{1, "eXpoch_WhiskeyNoodle"}
		};
		requiresFire = 0;
		category = "Medical";
	};
	class TornRagsSanitized117: Exile_AbstractCraftingRecipe
	{
		name = "Sanitize Rags w/Whiskey";
		pictureItem = "eXpoch_Rag00_Item";
		returnedItems[] =
		{
			{1, "eXpoch_Rag00_Item"}
		};
		tools[] = {};
		components[] = 
		{
			{1, "eXpoch_Rag17_Item"},
			{1, "eXpoch_WhiskeyNoodle"}
		};
		requiresFire = 0;
		category = "Medical";
	};
	class TornRagsSanitized118: Exile_AbstractCraftingRecipe
	{
		name = "Sanitize Rags w/Whiskey";
		pictureItem = "eXpoch_Rag00_Item";
		returnedItems[] =
		{
			{1, "eXpoch_Rag00_Item"}
		};
		tools[] = {};
		components[] = 
		{
			{1, "eXpoch_Rag18_Item"},
			{1, "eXpoch_WhiskeyNoodle"}
		};
		requiresFire = 0;
		category = "Medical";
	};
	class TornRagsSanitized119: Exile_AbstractCraftingRecipe
	{
		name = "Sanitize Rags w/Whiskey";
		pictureItem = "eXpoch_Rag00_Item";
		returnedItems[] =
		{
			{1, "eXpoch_Rag00_Item"}
		};
		tools[] = {};
		components[] = 
		{
			{1, "eXpoch_Rag19_Item"},
			{1, "eXpoch_WhiskeyNoodle"}
		};
		requiresFire = 0;
		category = "Medical";
	};
	class TornRagsSanitized120: Exile_AbstractCraftingRecipe
	{
		name = "Sanitize Rags w/Whiskey";
		pictureItem = "eXpoch_Rag00_Item";
		returnedItems[] =
		{
			{1, "eXpoch_Rag00_Item"}
		};
		tools[] = {};
		components[] = 
		{
			{1, "eXpoch_Rag20_Item"},
			{1, "eXpoch_WhiskeyNoodle"}
		};
		requiresFire = 0;
		category = "Medical";
	};
	class TornRagsSanitized121: Exile_AbstractCraftingRecipe
	{
		name = "Sanitize Rags w/Whiskey";
		pictureItem = "eXpoch_Rag00_Item";
		returnedItems[] =
		{
			{1, "eXpoch_Rag00_Item"}
		};
		tools[] = {};
		components[] = 
		{
			{1, "eXpoch_Rag21_Item"},
			{1, "eXpoch_WhiskeyNoodle"}
		};
		requiresFire = 0;
		category = "Medical";
	};
	class TornRagsSanitized122: Exile_AbstractCraftingRecipe
	{
		name = "Sanitize Rags w/Whiskey";
		pictureItem = "eXpoch_Rag00_Item";
		returnedItems[] =
		{
			{1, "eXpoch_Rag00_Item"}
		};
		tools[] = {};
		components[] = 
		{
			{1, "eXpoch_Rag22_Item"},
			{1, "eXpoch_WhiskeyNoodle"}
		};
		requiresFire = 0;
		category = "Medical";
	};
	class TornRagsSanitized123: Exile_AbstractCraftingRecipe
	{
		name = "Sanitize Rags w/Whiskey";
		pictureItem = "eXpoch_Rag00_Item";
		returnedItems[] =
		{
			{1, "eXpoch_Rag00_Item"}
		};
		tools[] = {};
		components[] = 
		{
			{1, "eXpoch_Rag23_Item"},
			{1, "eXpoch_WhiskeyNoodle"}
		};
		requiresFire = 0;
		category = "Medical";
	};
	class TornRagsSanitized124: Exile_AbstractCraftingRecipe
	{
		name = "Sanitize Rags w/Whiskey";
		pictureItem = "eXpoch_Rag00_Item";
		returnedItems[] =
		{
			{1, "eXpoch_Rag00_Item"}
		};
		tools[] = {};
		components[] = 
		{
			{1, "eXpoch_Rag24_Item"},
			{1, "eXpoch_WhiskeyNoodle"}
		};
		requiresFire = 0;
		category = "Medical";
	};
	class TornRagsSanitized125: Exile_AbstractCraftingRecipe
	{
		name = "Sanitize Rags w/Whiskey";
		pictureItem = "eXpoch_Rag00_Item";
		returnedItems[] =
		{
			{1, "eXpoch_Rag00_Item"}
		};
		tools[] = {};
		components[] = 
		{
			{1, "eXpoch_Rag25_Item"},
			{1, "eXpoch_WhiskeyNoodle"}
		};
		requiresFire = 0;
		category = "Medical";
	};
	class TornRagsSanitized126: Exile_AbstractCraftingRecipe
	{
		name = "Sanitize Rags w/Whiskey";
		pictureItem = "eXpoch_Rag00_Item";
		returnedItems[] =
		{
			{1, "eXpoch_Rag00_Item"}
		};
		tools[] = {};
		components[] = 
		{
			{1, "eXpoch_Rag26_Item"},
			{1, "eXpoch_WhiskeyNoodle"}
		};
		requiresFire = 0;
		category = "Medical";
	};
	class TornRagsSanitized127: Exile_AbstractCraftingRecipe
	{
		name = "Sanitize Rags w/Whiskey";
		pictureItem = "eXpoch_Rag00_Item";
		returnedItems[] =
		{
			{1, "eXpoch_Rag00_Item"}
		};
		tools[] = {};
		components[] = 
		{
			{1, "eXpoch_Rag27_Item"},
			{1, "eXpoch_WhiskeyNoodle"}
		};
		requiresFire = 0;
		category = "Medical";
	};
	class TornRagsSanitized128: Exile_AbstractCraftingRecipe
	{
		name = "Sanitize Rags w/Whiskey";
		pictureItem = "eXpoch_Rag00_Item";
		returnedItems[] =
		{
			{1, "eXpoch_Rag00_Item"}
		};
		tools[] = {};
		components[] = 
		{
			{1, "eXpoch_Rag28_Item"},
			{1, "eXpoch_WhiskeyNoodle"}
		};
		requiresFire = 0;
		category = "Medical";
	};
	class TornRagsSanitized129: Exile_AbstractCraftingRecipe
	{
		name = "Sanitize Rags w/Whiskey";
		pictureItem = "eXpoch_Rag00_Item";
		returnedItems[] =
		{
			{1, "eXpoch_Rag00_Item"}
		};
		tools[] = {};
		components[] = 
		{
			{1, "eXpoch_Rag29_Item"},
			{1, "eXpoch_WhiskeyNoodle"}
		};
		requiresFire = 0;
		category = "Medical";
	};
	class TornRagsSanitized130: Exile_AbstractCraftingRecipe
	{
		name = "Sanitize Rags w/Whiskey";
		pictureItem = "eXpoch_Rag00_Item";
		returnedItems[] =
		{
			{1, "eXpoch_Rag00_Item"}
		};
		tools[] = {};
		components[] = 
		{
			{1, "eXpoch_Rag30_Item"},
			{1, "eXpoch_WhiskeyNoodle"}
		};
		requiresFire = 0;
		category = "Medical";
	};
	class TornRagsSanitized131: Exile_AbstractCraftingRecipe
	{
		name = "Sanitize Rags w/Whiskey";
		pictureItem = "eXpoch_Rag00_Item";
		returnedItems[] =
		{
			{1, "eXpoch_Rag00_Item"}
		};
		tools[] = {};
		components[] = 
		{
			{1, "eXpoch_Rag31_Item"},
			{1, "eXpoch_WhiskeyNoodle"}
		};
		requiresFire = 0;
		category = "Medical";
	};
	class TornRagsSanitized132: Exile_AbstractCraftingRecipe
	{
		name = "Sanitize Rags w/Whiskey";
		pictureItem = "eXpoch_Rag00_Item";
		returnedItems[] =
		{
			{1, "eXpoch_Rag00_Item"}
		};
		tools[] = {};
		components[] = 
		{
			{1, "eXpoch_Rag32_Item"},
			{1, "eXpoch_WhiskeyNoodle"}
		};
		requiresFire = 0;
		category = "Medical";
	};
	class TornRagsSanitized133: Exile_AbstractCraftingRecipe
	{
		name = "Sanitize Rags w/Whiskey";
		pictureItem = "eXpoch_Rag00_Item";
		returnedItems[] =
		{
			{1, "eXpoch_Rag00_Item"}
		};
		tools[] = {};
		components[] = 
		{
			{1, "eXpoch_Rag33_Item"},
			{1, "eXpoch_WhiskeyNoodle"}
		};
		requiresFire = 0;
		category = "Medical";
	};
	class TornRagsSanitized134: Exile_AbstractCraftingRecipe
	{
		name = "Sanitize Rags w/Whiskey";
		pictureItem = "eXpoch_Rag00_Item";
		returnedItems[] =
		{
			{1, "eXpoch_Rag00_Item"}
		};
		tools[] = {};
		components[] = 
		{
			{1, "eXpoch_Rag34_Item"},
			{1, "eXpoch_WhiskeyNoodle"}
		};
		requiresFire = 0;
		category = "Medical";
	};
	class TornRagsSanitized135: Exile_AbstractCraftingRecipe
	{
		name = "Sanitize Rags w/Whiskey";
		pictureItem = "eXpoch_Rag00_Item";
		returnedItems[] =
		{
			{1, "eXpoch_Rag00_Item"}
		};
		tools[] = {};
		components[] = 
		{
			{1, "eXpoch_Rag35_Item"},
			{1, "eXpoch_WhiskeyNoodle"}
		};
		requiresFire = 0;
		category = "Medical";
	};
	class TornRagsSanitized136: Exile_AbstractCraftingRecipe
	{
		name = "Sanitize Rags w/Whiskey";
		pictureItem = "eXpoch_Rag00_Item";
		returnedItems[] =
		{
			{1, "eXpoch_Rag00_Item"}
		};
		tools[] = {};
		components[] = 
		{
			{1, "eXpoch_Rag36_Item"},
			{1, "eXpoch_WhiskeyNoodle"}
		};
		requiresFire = 0;
		category = "Medical";
	};
	class TornRagsSanitized137: Exile_AbstractCraftingRecipe
	{
		name = "Sanitize Rags w/Whiskey";
		pictureItem = "eXpoch_Rag00_Item";
		returnedItems[] =
		{
			{1, "eXpoch_Rag00_Item"}
		};
		tools[] = {};
		components[] = 
		{
			{1, "eXpoch_Rag37_Item"},
			{1, "eXpoch_WhiskeyNoodle"}
		};
		requiresFire = 0;
		category = "Medical";
	};
	class TornRagsSanitized138: Exile_AbstractCraftingRecipe
	{
		name = "Sanitize Rags w/Whiskey";
		pictureItem = "eXpoch_Rag00_Item";
		returnedItems[] =
		{
			{1, "eXpoch_Rag00_Item"}
		};
		tools[] = {};
		components[] = 
		{
			{1, "eXpoch_Rag38_Item"},
			{1, "eXpoch_WhiskeyNoodle"}
		};
		requiresFire = 0;
		category = "Medical";
	};
	class TornRagsSanitized139: Exile_AbstractCraftingRecipe
	{
		name = "Sanitize Rags w/Whiskey";
		pictureItem = "eXpoch_Rag00_Item";
		returnedItems[] =
		{
			{1, "eXpoch_Rag00_Item"}
		};
		tools[] = {};
		components[] = 
		{
			{1, "eXpoch_Rag39_Item"},
			{1, "eXpoch_WhiskeyNoodle"}
		};
		requiresFire = 0;
		category = "Medical";
	};
	class TornRagsSanitized140: Exile_AbstractCraftingRecipe
	{
		name = "Sanitize Rags w/Whiskey";
		pictureItem = "eXpoch_Rag00_Item";
		returnedItems[] =
		{
			{1, "eXpoch_Rag00_Item"}
		};
		tools[] = {};
		components[] = 
		{
			{1, "eXpoch_Rag40_Item"},
			{1, "eXpoch_WhiskeyNoodle"}
		};
		requiresFire = 0;
		category = "Medical";
	};
	class TornRagsSanitized141: Exile_AbstractCraftingRecipe
	{
		name = "Sanitize Rags w/Whiskey";
		pictureItem = "eXpoch_Rag00_Item";
		returnedItems[] =
		{
			{1, "eXpoch_Rag00_Item"}
		};
		tools[] = {};
		components[] = 
		{
			{1, "eXpoch_Rag41_Item"},
			{1, "eXpoch_WhiskeyNoodle"}
		};
		requiresFire = 0;
		category = "Medical";
	};
	class TornRagsSanitized142: Exile_AbstractCraftingRecipe
	{
		name = "Sanitize Rags w/Whiskey";
		pictureItem = "eXpoch_Rag00_Item";
		returnedItems[] =
		{
			{1, "eXpoch_Rag00_Item"}
		};
		tools[] = {};
		components[] = 
		{
			{1, "eXpoch_Rag42_Item"},
			{1, "eXpoch_WhiskeyNoodle"}
		};
		requiresFire = 0;
		category = "Medical";
	};
	class TornRagsSanitized143: Exile_AbstractCraftingRecipe
	{
		name = "Sanitize Rags w/Whiskey";
		pictureItem = "eXpoch_Rag00_Item";
		returnedItems[] =
		{
			{1, "eXpoch_Rag00_Item"}
		};
		tools[] = {};
		components[] = 
		{
			{1, "eXpoch_Rag43_Item"},
			{1, "eXpoch_WhiskeyNoodle"}
		};
		requiresFire = 0;
		category = "Medical";
	};
	class TornRagsSanitized144: Exile_AbstractCraftingRecipe
	{
		name = "Sanitize Rags w/Whiskey";
		pictureItem = "eXpoch_Rag00_Item";
		returnedItems[] =
		{
			{1, "eXpoch_Rag00_Item"}
		};
		tools[] = {};
		components[] = 
		{
			{1, "eXpoch_Rag44_Item"},
			{1, "eXpoch_WhiskeyNoodle"}
		};
		requiresFire = 0;
		category = "Medical";
	};
	class TornRagsSanitized145: Exile_AbstractCraftingRecipe
	{
		name = "Sanitize Rags w/Whiskey";
		pictureItem = "eXpoch_Rag00_Item";
		returnedItems[] =
		{
			{1, "eXpoch_Rag00_Item"}
		};
		tools[] = {};
		components[] = 
		{
			{1, "eXpoch_Rag45_Item"},
			{1, "eXpoch_WhiskeyNoodle"}
		};
		requiresFire = 0;
		category = "Medical";
	};
	class TornRagsSanitized146: Exile_AbstractCraftingRecipe
	{
		name = "Sanitize Rags w/Whiskey";
		pictureItem = "eXpoch_Rag00_Item";
		returnedItems[] =
		{
			{1, "eXpoch_Rag00_Item"}
		};
		tools[] = {};
		components[] = 
		{
			{1, "eXpoch_Rag46_Item"},
			{1, "eXpoch_WhiskeyNoodle"}
		};
		requiresFire = 0;
		category = "Medical";
	};
	// Sanitize with Boiling Water
	class TornRagsSanitized201: Exile_AbstractCraftingRecipe
	{
		name = "Sanitize Rags w/Boiling Water";
		pictureItem = "eXpoch_Rag00_Item";
		returnedItems[] =
		{
			{1, "eXpoch_Rag00_Item"},
			{1, "Exile_Item_PlasticBottleEmpty"}
		};
		tools[] = 
		{
			"Exile_Item_CookingPot"
		};
		components[] = 
		{
			{1, "eXpoch_Rag01_Item"},
			{1, "Exile_Item_PlasticBottleFreshWater"}
		};
		requiresFire = 1;
		category = "Medical";
	};
	class TornRagsSanitized202: Exile_AbstractCraftingRecipe
	{
		name = "Sanitize Rags w/Boiling Water";
		pictureItem = "eXpoch_Rag00_Item";
		returnedItems[] =
		{
			{1, "eXpoch_Rag00_Item"},
			{1, "Exile_Item_PlasticBottleEmpty"}
		};
		tools[] = 
		{
			"Exile_Item_CookingPot"
		};
		components[] = 
		{
			{1, "eXpoch_Rag02_Item"},
			{1, "Exile_Item_PlasticBottleFreshWater"}
		};
		requiresFire = 1;
		category = "Medical";
	};
	class TornRagsSanitized203: Exile_AbstractCraftingRecipe
	{
		name = "Sanitize Rags w/Boiling Water";
		pictureItem = "eXpoch_Rag00_Item";
		returnedItems[] =
		{
			{1, "eXpoch_Rag00_Item"},
			{1, "Exile_Item_PlasticBottleEmpty"}
		};
		tools[] = 
		{
			"Exile_Item_CookingPot"
		};
		components[] = 
		{
			{1, "eXpoch_Rag03_Item"},
			{1, "Exile_Item_PlasticBottleFreshWater"}
		};
		requiresFire = 1;
		category = "Medical";
	};
	class TornRagsSanitized204: Exile_AbstractCraftingRecipe
	{
		name = "Sanitize Rags w/Boiling Water";
		pictureItem = "eXpoch_Rag00_Item";
		returnedItems[] =
		{
			{1, "eXpoch_Rag00_Item"},
			{1, "Exile_Item_PlasticBottleEmpty"}
		};
		tools[] = 
		{
			"Exile_Item_CookingPot"
		};
		components[] = 
		{
			{1, "eXpoch_Rag04_Item"},
			{1, "Exile_Item_PlasticBottleFreshWater"}
		};
		requiresFire = 1;
		category = "Medical";
	};
	class TornRagsSanitized205: Exile_AbstractCraftingRecipe
	{
		name = "Sanitize Rags w/Boiling Water";
		pictureItem = "eXpoch_Rag00_Item";
		returnedItems[] =
		{
			{1, "eXpoch_Rag00_Item"},
			{1, "Exile_Item_PlasticBottleEmpty"}
		};
		tools[] = 
		{
			"Exile_Item_CookingPot"
		};
		components[] = 
		{
			{1, "eXpoch_Rag05_Item"},
			{1, "Exile_Item_PlasticBottleFreshWater"}
		};
		requiresFire = 1;
		category = "Medical";
	};
	class TornRagsSanitized206: Exile_AbstractCraftingRecipe
	{
		name = "Sanitize Rags w/Boiling Water";
		pictureItem = "eXpoch_Rag00_Item";
		returnedItems[] =
		{
			{1, "eXpoch_Rag00_Item"},
			{1, "Exile_Item_PlasticBottleEmpty"}
		};
		tools[] = 
		{
			"Exile_Item_CookingPot"
		};
		components[] = 
		{
			{1, "eXpoch_Rag06_Item"},
			{1, "Exile_Item_PlasticBottleFreshWater"}
		};
		requiresFire = 1;
		category = "Medical";
	};
	class TornRagsSanitized207: Exile_AbstractCraftingRecipe
	{
		name = "Sanitize Rags w/Boiling Water";
		pictureItem = "eXpoch_Rag00_Item";
		returnedItems[] =
		{
			{1, "eXpoch_Rag00_Item"},
			{1, "Exile_Item_PlasticBottleEmpty"}
		};
		tools[] = 
		{
			"Exile_Item_CookingPot"
		};
		components[] = 
		{
			{1, "eXpoch_Rag07_Item"},
			{1, "Exile_Item_PlasticBottleFreshWater"}
		};
		requiresFire = 1;
		category = "Medical";
	};
	class TornRagsSanitized208: Exile_AbstractCraftingRecipe
	{
		name = "Sanitize Rags w/Boiling Water";
		pictureItem = "eXpoch_Rag00_Item";
		returnedItems[] =
		{
			{1, "eXpoch_Rag00_Item"},
			{1, "Exile_Item_PlasticBottleEmpty"}
		};
		tools[] = 
		{
			"Exile_Item_CookingPot"
		};
		components[] = 
		{
			{1, "eXpoch_Rag08_Item"},
			{1, "Exile_Item_PlasticBottleFreshWater"}
		};
		requiresFire = 1;
		category = "Medical";
	};
	class TornRagsSanitized209: Exile_AbstractCraftingRecipe
	{
		name = "Sanitize Rags w/Boiling Water";
		pictureItem = "eXpoch_Rag00_Item";
		returnedItems[] =
		{
			{1, "eXpoch_Rag00_Item"},
			{1, "Exile_Item_PlasticBottleEmpty"}
		};
		tools[] = 
		{
			"Exile_Item_CookingPot"
		};
		components[] = 
		{
			{1, "eXpoch_Rag09_Item"},
			{1, "Exile_Item_PlasticBottleFreshWater"}
		};
		requiresFire = 1;
		category = "Medical";
	};
	class TornRagsSanitized210: Exile_AbstractCraftingRecipe
	{
		name = "Sanitize Rags w/Boiling Water";
		pictureItem = "eXpoch_Rag00_Item";
		returnedItems[] =
		{
			{1, "eXpoch_Rag00_Item"},
			{1, "Exile_Item_PlasticBottleEmpty"}
		};
		tools[] = 
		{
			"Exile_Item_CookingPot"
		};
		components[] = 
		{
			{1, "eXpoch_Rag10_Item"},
			{1, "Exile_Item_PlasticBottleFreshWater"}
		};
		requiresFire = 1;
		category = "Medical";
	};
	class TornRagsSanitized211: Exile_AbstractCraftingRecipe
	{
		name = "Sanitize Rags w/Boiling Water";
		pictureItem = "eXpoch_Rag00_Item";
		returnedItems[] =
		{
			{1, "eXpoch_Rag00_Item"},
			{1, "Exile_Item_PlasticBottleEmpty"}
		};
		tools[] = 
		{
			"Exile_Item_CookingPot"
		};
		components[] = 
		{
			{1, "eXpoch_Rag11_Item"},
			{1, "Exile_Item_PlasticBottleFreshWater"}
		};
		requiresFire = 1;
		category = "Medical";
	};
	class TornRagsSanitized212: Exile_AbstractCraftingRecipe
	{
		name = "Sanitize Rags w/Boiling Water";
		pictureItem = "eXpoch_Rag00_Item";
		returnedItems[] =
		{
			{1, "eXpoch_Rag00_Item"},
			{1, "Exile_Item_PlasticBottleEmpty"}
		};
		tools[] = 
		{
			"Exile_Item_CookingPot"
		};
		components[] = 
		{
			{1, "eXpoch_Rag12_Item"},
			{1, "Exile_Item_PlasticBottleFreshWater"}
		};
		requiresFire = 1;
		category = "Medical";
	};
	class TornRagsSanitized213: Exile_AbstractCraftingRecipe
	{
		name = "Sanitize Rags w/Boiling Water";
		pictureItem = "eXpoch_Rag00_Item";
		returnedItems[] =
		{
			{1, "eXpoch_Rag00_Item"},
			{1, "Exile_Item_PlasticBottleEmpty"}
		};
		tools[] = 
		{
			"Exile_Item_CookingPot"
		};
		components[] = 
		{
			{1, "eXpoch_Rag13_Item"},
			{1, "Exile_Item_PlasticBottleFreshWater"}
		};
		requiresFire = 1;
		category = "Medical";
	};
	class TornRagsSanitized214: Exile_AbstractCraftingRecipe
	{
		name = "Sanitize Rags w/Boiling Water";
		pictureItem = "eXpoch_Rag00_Item";
		returnedItems[] =
		{
			{1, "eXpoch_Rag00_Item"},
			{1, "Exile_Item_PlasticBottleEmpty"}
		};
		tools[] = 
		{
			"Exile_Item_CookingPot"
		};
		components[] = 
		{
			{1, "eXpoch_Rag14_Item"},
			{1, "Exile_Item_PlasticBottleFreshWater"}
		};
		requiresFire = 1;
		category = "Medical";
	};
	class TornRagsSanitized215: Exile_AbstractCraftingRecipe
	{
		name = "Sanitize Rags w/Boiling Water";
		pictureItem = "eXpoch_Rag00_Item";
		returnedItems[] =
		{
			{1, "eXpoch_Rag00_Item"},
			{1, "Exile_Item_PlasticBottleEmpty"}
		};
		tools[] = 
		{
			"Exile_Item_CookingPot"
		};
		components[] = 
		{
			{1, "eXpoch_Rag15_Item"},
			{1, "Exile_Item_PlasticBottleFreshWater"}
		};
		requiresFire = 1;
		category = "Medical";
	};
	class TornRagsSanitized216: Exile_AbstractCraftingRecipe
	{
		name = "Sanitize Rags w/Boiling Water";
		pictureItem = "eXpoch_Rag00_Item";
		returnedItems[] =
		{
			{1, "eXpoch_Rag00_Item"},
			{1, "Exile_Item_PlasticBottleEmpty"}
		};
		tools[] = 
		{
			"Exile_Item_CookingPot"
		};
		components[] = 
		{
			{1, "eXpoch_Rag16_Item"},
			{1, "Exile_Item_PlasticBottleFreshWater"}
		};
		requiresFire = 1;
		category = "Medical";
	};
	class TornRagsSanitized217: Exile_AbstractCraftingRecipe
	{
		name = "Sanitize Rags w/Boiling Water";
		pictureItem = "eXpoch_Rag00_Item";
		returnedItems[] =
		{
			{1, "eXpoch_Rag00_Item"},
			{1, "Exile_Item_PlasticBottleEmpty"}
		};
		tools[] = 
		{
			"Exile_Item_CookingPot"
		};
		components[] = 
		{
			{1, "eXpoch_Rag17_Item"},
			{1, "Exile_Item_PlasticBottleFreshWater"}
		};
		requiresFire = 1;
		category = "Medical";
	};
	class TornRagsSanitized218: Exile_AbstractCraftingRecipe
	{
		name = "Sanitize Rags w/Boiling Water";
		pictureItem = "eXpoch_Rag00_Item";
		returnedItems[] =
		{
			{1, "eXpoch_Rag00_Item"},
			{1, "Exile_Item_PlasticBottleEmpty"}
		};
		tools[] = 
		{
			"Exile_Item_CookingPot"
		};
		components[] = 
		{
			{1, "eXpoch_Rag18_Item"},
			{1, "Exile_Item_PlasticBottleFreshWater"}
		};
		requiresFire = 1;
		category = "Medical";
	};
	class TornRagsSanitized219: Exile_AbstractCraftingRecipe
	{
		name = "Sanitize Rags w/Boiling Water";
		pictureItem = "eXpoch_Rag00_Item";
		returnedItems[] =
		{
			{1, "eXpoch_Rag00_Item"},
			{1, "Exile_Item_PlasticBottleEmpty"}
		};
		tools[] = 
		{
			"Exile_Item_CookingPot"
		};
		components[] = 
		{
			{1, "eXpoch_Rag19_Item"},
			{1, "Exile_Item_PlasticBottleFreshWater"}
		};
		requiresFire = 1;
		category = "Medical";
	};
	class TornRagsSanitized220: Exile_AbstractCraftingRecipe
	{
		name = "Sanitize Rags w/Boiling Water";
		pictureItem = "eXpoch_Rag00_Item";
		returnedItems[] =
		{
			{1, "eXpoch_Rag00_Item"},
			{1, "Exile_Item_PlasticBottleEmpty"}
		};
		tools[] = 
		{
			"Exile_Item_CookingPot"
		};
		components[] = 
		{
			{1, "eXpoch_Rag20_Item"},
			{1, "Exile_Item_PlasticBottleFreshWater"}
		};
		requiresFire = 1;
		category = "Medical";
	};
	class TornRagsSanitized221: Exile_AbstractCraftingRecipe
	{
		name = "Sanitize Rags w/Boiling Water";
		pictureItem = "eXpoch_Rag00_Item";
		returnedItems[] =
		{
			{1, "eXpoch_Rag00_Item"},
			{1, "Exile_Item_PlasticBottleEmpty"}
		};
		tools[] = 
		{
			"Exile_Item_CookingPot"
		};
		components[] = 
		{
			{1, "eXpoch_Rag21_Item"},
			{1, "Exile_Item_PlasticBottleFreshWater"}
		};
		requiresFire = 1;
		category = "Medical";
	};
	class TornRagsSanitized222: Exile_AbstractCraftingRecipe
	{
		name = "Sanitize Rags w/Boiling Water";
		pictureItem = "eXpoch_Rag00_Item";
		returnedItems[] =
		{
			{1, "eXpoch_Rag00_Item"},
			{1, "Exile_Item_PlasticBottleEmpty"}
		};
		tools[] = 
		{
			"Exile_Item_CookingPot"
		};
		components[] = 
		{
			{1, "eXpoch_Rag22_Item"},
			{1, "Exile_Item_PlasticBottleFreshWater"}
		};
		requiresFire = 1;
		category = "Medical";
	};
	class TornRagsSanitized223: Exile_AbstractCraftingRecipe
	{
		name = "Sanitize Rags w/Boiling Water";
		pictureItem = "eXpoch_Rag00_Item";
		returnedItems[] =
		{
			{1, "eXpoch_Rag00_Item"},
			{1, "Exile_Item_PlasticBottleEmpty"}
		};
		tools[] = 
		{
			"Exile_Item_CookingPot"
		};
		components[] = 
		{
			{1, "eXpoch_Rag23_Item"},
			{1, "Exile_Item_PlasticBottleFreshWater"}
		};
		requiresFire = 1;
		category = "Medical";
	};
	class TornRagsSanitized224: Exile_AbstractCraftingRecipe
	{
		name = "Sanitize Rags w/Boiling Water";
		pictureItem = "eXpoch_Rag00_Item";
		returnedItems[] =
		{
			{1, "eXpoch_Rag00_Item"},
			{1, "Exile_Item_PlasticBottleEmpty"}
		};
		tools[] = 
		{
			"Exile_Item_CookingPot"
		};
		components[] = 
		{
			{1, "eXpoch_Rag24_Item"},
			{1, "Exile_Item_PlasticBottleFreshWater"}
		};
		requiresFire = 1;
		category = "Medical";
	};
	class TornRagsSanitized225: Exile_AbstractCraftingRecipe
	{
		name = "Sanitize Rags w/Boiling Water";
		pictureItem = "eXpoch_Rag00_Item";
		returnedItems[] =
		{
			{1, "eXpoch_Rag00_Item"},
			{1, "Exile_Item_PlasticBottleEmpty"}
		};
		tools[] = 
		{
			"Exile_Item_CookingPot"
		};
		components[] = 
		{
			{1, "eXpoch_Rag25_Item"},
			{1, "Exile_Item_PlasticBottleFreshWater"}
		};
		requiresFire = 1;
		category = "Medical";
	};
	class TornRagsSanitized226: Exile_AbstractCraftingRecipe
	{
		name = "Sanitize Rags w/Boiling Water";
		pictureItem = "eXpoch_Rag00_Item";
		returnedItems[] =
		{
			{1, "eXpoch_Rag00_Item"},
			{1, "Exile_Item_PlasticBottleEmpty"}
		};
		tools[] = 
		{
			"Exile_Item_CookingPot"
		};
		components[] = 
		{
			{1, "eXpoch_Rag26_Item"},
			{1, "Exile_Item_PlasticBottleFreshWater"}
		};
		requiresFire = 1;
		category = "Medical";
	};
	class TornRagsSanitized227: Exile_AbstractCraftingRecipe
	{
		name = "Sanitize Rags w/Boiling Water";
		pictureItem = "eXpoch_Rag00_Item";
		returnedItems[] =
		{
			{1, "eXpoch_Rag00_Item"},
			{1, "Exile_Item_PlasticBottleEmpty"}
		};
		tools[] = 
		{
			"Exile_Item_CookingPot"
		};
		components[] = 
		{
			{1, "eXpoch_Rag27_Item"},
			{1, "Exile_Item_PlasticBottleFreshWater"}
		};
		requiresFire = 1;
		category = "Medical";
	};
	class TornRagsSanitized228: Exile_AbstractCraftingRecipe
	{
		name = "Sanitize Rags w/Boiling Water";
		pictureItem = "eXpoch_Rag00_Item";
		returnedItems[] =
		{
			{1, "eXpoch_Rag00_Item"},
			{1, "Exile_Item_PlasticBottleEmpty"}
		};
		tools[] = 
		{
			"Exile_Item_CookingPot"
		};
		components[] = 
		{
			{1, "eXpoch_Rag28_Item"},
			{1, "Exile_Item_PlasticBottleFreshWater"}
		};
		requiresFire = 1;
		category = "Medical";
	};
	class TornRagsSanitized229: Exile_AbstractCraftingRecipe
	{
		name = "Sanitize Rags w/Boiling Water";
		pictureItem = "eXpoch_Rag00_Item";
		returnedItems[] =
		{
			{1, "eXpoch_Rag00_Item"},
			{1, "Exile_Item_PlasticBottleEmpty"}
		};
		tools[] = 
		{
			"Exile_Item_CookingPot"
		};
		components[] = 
		{
			{1, "eXpoch_Rag29_Item"},
			{1, "Exile_Item_PlasticBottleFreshWater"}
		};
		requiresFire = 1;
		category = "Medical";
	};
	class TornRagsSanitized230: Exile_AbstractCraftingRecipe
	{
		name = "Sanitize Rags w/Boiling Water";
		pictureItem = "eXpoch_Rag00_Item";
		returnedItems[] =
		{
			{1, "eXpoch_Rag00_Item"},
			{1, "Exile_Item_PlasticBottleEmpty"}
		};
		tools[] = 
		{
			"Exile_Item_CookingPot"
		};
		components[] = 
		{
			{1, "eXpoch_Rag30_Item"},
			{1, "Exile_Item_PlasticBottleFreshWater"}
		};
		requiresFire = 1;
		category = "Medical";
	};
	class TornRagsSanitized231: Exile_AbstractCraftingRecipe
	{
		name = "Sanitize Rags w/Boiling Water";
		pictureItem = "eXpoch_Rag00_Item";
		returnedItems[] =
		{
			{1, "eXpoch_Rag00_Item"},
			{1, "Exile_Item_PlasticBottleEmpty"}
		};
		tools[] = 
		{
			"Exile_Item_CookingPot"
		};
		components[] = 
		{
			{1, "eXpoch_Rag31_Item"},
			{1, "Exile_Item_PlasticBottleFreshWater"}
		};
		requiresFire = 1;
		category = "Medical";
	};
	class TornRagsSanitized232: Exile_AbstractCraftingRecipe
	{
		name = "Sanitize Rags w/Boiling Water";
		pictureItem = "eXpoch_Rag00_Item";
		returnedItems[] =
		{
			{1, "eXpoch_Rag00_Item"},
			{1, "Exile_Item_PlasticBottleEmpty"}
		};
		tools[] = 
		{
			"Exile_Item_CookingPot"
		};
		components[] = 
		{
			{1, "eXpoch_Rag32_Item"},
			{1, "Exile_Item_PlasticBottleFreshWater"}
		};
		requiresFire = 1;
		category = "Medical";
	};
	class TornRagsSanitized233: Exile_AbstractCraftingRecipe
	{
		name = "Sanitize Rags w/Boiling Water";
		pictureItem = "eXpoch_Rag00_Item";
		returnedItems[] =
		{
			{1, "eXpoch_Rag00_Item"},
			{1, "Exile_Item_PlasticBottleEmpty"}
		};
		tools[] = 
		{
			"Exile_Item_CookingPot"
		};
		components[] = 
		{
			{1, "eXpoch_Rag33_Item"},
			{1, "Exile_Item_PlasticBottleFreshWater"}
		};
		requiresFire = 1;
		category = "Medical";
	};
	class TornRagsSanitized234: Exile_AbstractCraftingRecipe
	{
		name = "Sanitize Rags w/Boiling Water";
		pictureItem = "eXpoch_Rag00_Item";
		returnedItems[] =
		{
			{1, "eXpoch_Rag00_Item"},
			{1, "Exile_Item_PlasticBottleEmpty"}
		};
		tools[] = 
		{
			"Exile_Item_CookingPot"
		};
		components[] = 
		{
			{1, "eXpoch_Rag34_Item"},
			{1, "Exile_Item_PlasticBottleFreshWater"}
		};
		requiresFire = 1;
		category = "Medical";
	};
	class TornRagsSanitized235: Exile_AbstractCraftingRecipe
	{
		name = "Sanitize Rags w/Boiling Water";
		pictureItem = "eXpoch_Rag00_Item";
		returnedItems[] =
		{
			{1, "eXpoch_Rag00_Item"},
			{1, "Exile_Item_PlasticBottleEmpty"}
		};
		tools[] = 
		{
			"Exile_Item_CookingPot"
		};
		components[] = 
		{
			{1, "eXpoch_Rag35_Item"},
			{1, "Exile_Item_PlasticBottleFreshWater"}
		};
		requiresFire = 1;
		category = "Medical";
	};
	class TornRagsSanitized236: Exile_AbstractCraftingRecipe
	{
		name = "Sanitize Rags w/Boiling Water";
		pictureItem = "eXpoch_Rag00_Item";
		returnedItems[] =
		{
			{1, "eXpoch_Rag00_Item"},
			{1, "Exile_Item_PlasticBottleEmpty"}
		};
		tools[] = 
		{
			"Exile_Item_CookingPot"
		};
		components[] = 
		{
			{1, "eXpoch_Rag36_Item"},
			{1, "Exile_Item_PlasticBottleFreshWater"}
		};
		requiresFire = 1;
		category = "Medical";
	};
	class TornRagsSanitized237: Exile_AbstractCraftingRecipe
	{
		name = "Sanitize Rags w/Boiling Water";
		pictureItem = "eXpoch_Rag00_Item";
		returnedItems[] =
		{
			{1, "eXpoch_Rag00_Item"},
			{1, "Exile_Item_PlasticBottleEmpty"}
		};
		tools[] = 
		{
			"Exile_Item_CookingPot"
		};
		components[] = 
		{
			{1, "eXpoch_Rag37_Item"},
			{1, "Exile_Item_PlasticBottleFreshWater"}
		};
		requiresFire = 1;
		category = "Medical";
	};
	class TornRagsSanitized238: Exile_AbstractCraftingRecipe
	{
		name = "Sanitize Rags w/Boiling Water";
		pictureItem = "eXpoch_Rag00_Item";
		returnedItems[] =
		{
			{1, "eXpoch_Rag00_Item"},
			{1, "Exile_Item_PlasticBottleEmpty"}
		};
		tools[] = 
		{
			"Exile_Item_CookingPot"
		};
		components[] = 
		{
			{1, "eXpoch_Rag38_Item"},
			{1, "Exile_Item_PlasticBottleFreshWater"}
		};
		requiresFire = 1;
		category = "Medical";
	};
	class TornRagsSanitized239: Exile_AbstractCraftingRecipe
	{
		name = "Sanitize Rags w/Boiling Water";
		pictureItem = "eXpoch_Rag00_Item";
		returnedItems[] =
		{
			{1, "eXpoch_Rag00_Item"},
			{1, "Exile_Item_PlasticBottleEmpty"}
		};
		tools[] = 
		{
			"Exile_Item_CookingPot"
		};
		components[] = 
		{
			{1, "eXpoch_Rag39_Item"},
			{1, "Exile_Item_PlasticBottleFreshWater"}
		};
		requiresFire = 1;
		category = "Medical";
	};
	class TornRagsSanitized240: Exile_AbstractCraftingRecipe
	{
		name = "Sanitize Rags w/Boiling Water";
		pictureItem = "eXpoch_Rag00_Item";
		returnedItems[] =
		{
			{1, "eXpoch_Rag00_Item"},
			{1, "Exile_Item_PlasticBottleEmpty"}
		};
		tools[] = 
		{
			"Exile_Item_CookingPot"
		};
		components[] = 
		{
			{1, "eXpoch_Rag40_Item"},
			{1, "Exile_Item_PlasticBottleFreshWater"}
		};
		requiresFire = 1;
		category = "Medical";
	};
	class TornRagsSanitized241: Exile_AbstractCraftingRecipe
	{
		name = "Sanitize Rags w/Boiling Water";
		pictureItem = "eXpoch_Rag00_Item";
		returnedItems[] =
		{
			{1, "eXpoch_Rag00_Item"},
			{1, "Exile_Item_PlasticBottleEmpty"}
		};
		tools[] = 
		{
			"Exile_Item_CookingPot"
		};
		components[] = 
		{
			{1, "eXpoch_Rag41_Item"},
			{1, "Exile_Item_PlasticBottleFreshWater"}
		};
		requiresFire = 1;
		category = "Medical";
	};
	class TornRagsSanitized242: Exile_AbstractCraftingRecipe
	{
		name = "Sanitize Rags w/Boiling Water";
		pictureItem = "eXpoch_Rag00_Item";
		returnedItems[] =
		{
			{1, "eXpoch_Rag00_Item"},
			{1, "Exile_Item_PlasticBottleEmpty"}
		};
		tools[] = 
		{
			"Exile_Item_CookingPot"
		};
		components[] = 
		{
			{1, "eXpoch_Rag42_Item"},
			{1, "Exile_Item_PlasticBottleFreshWater"}
		};
		requiresFire = 1;
		category = "Medical";
	};
	class TornRagsSanitized243: Exile_AbstractCraftingRecipe
	{
		name = "Sanitize Rags w/Boiling Water";
		pictureItem = "eXpoch_Rag00_Item";
		returnedItems[] =
		{
			{1, "eXpoch_Rag00_Item"},
			{1, "Exile_Item_PlasticBottleEmpty"}
		};
		tools[] = 
		{
			"Exile_Item_CookingPot"
		};
		components[] = 
		{
			{1, "eXpoch_Rag43_Item"},
			{1, "Exile_Item_PlasticBottleFreshWater"}
		};
		requiresFire = 1;
		category = "Medical";
	};
	class TornRagsSanitized244: Exile_AbstractCraftingRecipe
	{
		name = "Sanitize Rags w/Boiling Water";
		pictureItem = "eXpoch_Rag00_Item";
		returnedItems[] =
		{
			{1, "eXpoch_Rag00_Item"},
			{1, "Exile_Item_PlasticBottleEmpty"}
		};
		tools[] = 
		{
			"Exile_Item_CookingPot"
		};
		components[] = 
		{
			{1, "eXpoch_Rag44_Item"},
			{1, "Exile_Item_PlasticBottleFreshWater"}
		};
		requiresFire = 1;
		category = "Medical";
	};
	class TornRagsSanitized245: Exile_AbstractCraftingRecipe
	{
		name = "Sanitize Rags w/Boiling Water";
		pictureItem = "eXpoch_Rag00_Item";
		returnedItems[] =
		{
			{1, "eXpoch_Rag00_Item"},
			{1, "Exile_Item_PlasticBottleEmpty"}
		};
		tools[] = 
		{
			"Exile_Item_CookingPot"
		};
		components[] = 
		{
			{1, "eXpoch_Rag45_Item"},
			{1, "Exile_Item_PlasticBottleFreshWater"}
		};
		requiresFire = 1;
		category = "Medical";
	};
	class TornRagsSanitized246: Exile_AbstractCraftingRecipe
	{
		name = "Sanitize Rags w/Boiling Water";
		pictureItem = "eXpoch_Rag00_Item";
		returnedItems[] =
		{
			{1, "eXpoch_Rag00_Item"},
			{1, "Exile_Item_PlasticBottleEmpty"}
		};
		tools[] = 
		{
			"Exile_Item_CookingPot"
		};
		components[] = 
		{
			{1, "eXpoch_Rag46_Item"},
			{1, "Exile_Item_PlasticBottleFreshWater"}
		};
		requiresFire = 1;
		category = "Medical";
	};
	// Rip up clothing
	class TornRags_U_I_C_Soldier_Bandit_4_F: Exile_AbstractCraftingRecipe
	{
		name = "Torn Rags";
		pictureItem = "eXpoch_Rag07_Item";
		returnedItems[] =
		{
			{2, "eXpoch_Rag04_Item"},
			{3, "eXpoch_Rag07_Item"}
		};
		components[] = 
		{
			{1, "U_I_C_Soldier_Bandit_4_F"}
		};
		category = "Medical";
	};
	class TornRags_U_I_C_Soldier_Bandit_1_F: Exile_AbstractCraftingRecipe
	{
		name = "Torn Rags";
		pictureItem = "eXpoch_Rag43_Item";
		returnedItems[] =
		{
			{2, "eXpoch_Rag45_Item"},
			{3, "eXpoch_Rag43_Item"}
		};
		components[] = 
		{
			{1, "U_I_C_Soldier_Bandit_1_F"}
		};
		category = "Medical";
	};
	class TornRags_U_I_C_Soldier_Bandit_2_F: Exile_AbstractCraftingRecipe
	{
		name = "Torn Rags";
		pictureItem = "eXpoch_Rag41_Item";
		returnedItems[] =
		{
			{3, "eXpoch_Rag42_Item"},
			{4, "eXpoch_Rag41_Item"}
		};
		components[] = 
		{
			{1, "U_I_C_Soldier_Bandit_1_F"}
		};
		category = "Medical";
	};
	class TornRags_U_I_C_Soldier_Bandit_5_F: Exile_AbstractCraftingRecipe
	{
		name = "Torn Rags";
		pictureItem = "eXpoch_Rag42_Item";
		returnedItems[] =
		{
			{2, "eXpoch_Rag42_Item"},
			{2, "eXpoch_Rag44_Item"}
		};
		components[] = 
		{
			{1, "U_I_C_Soldier_Bandit_5_F"}
		};
		category = "Medical";
	};
	class TornRags_U_I_C_Soldier_Bandit_3_F: Exile_AbstractCraftingRecipe
	{
		name = "Torn Rags";
		pictureItem = "eXpoch_Rag04_Item";
		returnedItems[] =
		{
			{1, "eXpoch_Rag29_Item"},
			{3, "eXpoch_Rag35_Item"},
			{4, "eXpoch_Rag04_Item"}
		};
		components[] = 
		{
			{1, "U_I_C_Soldier_Bandit_3_F"}
		};
		category = "Medical";
	};
	class TornRags_U_C_Man_casual_2_F: Exile_AbstractCraftingRecipe
	{
		name = "Torn Rags";
		pictureItem = "eXpoch_Rag44_Item";
		returnedItems[] =
		{
			{3, "eXpoch_Rag04_Item"},
			{4, "eXpoch_Rag44_Item"}
		};
		components[] = 
		{
			{1, "U_C_Man_casual_2_F"}
		};
		category = "Medical";
	};
	class TornRags_U_C_Man_casual_3_F: Exile_AbstractCraftingRecipe
	{
		name = "Torn Rags";
		pictureItem = "eXpoch_Rag02_Item";
		returnedItems[] =
		{
			{3, "eXpoch_Rag22_Item"},
			{4, "eXpoch_Rag02_Item"}
		};
		components[] = 
		{
			{1, "U_C_Man_casual_3_F"}
		};
		category = "Medical";
	};
	class TornRags_U_C_Man_casual_1_F: Exile_AbstractCraftingRecipe
	{
		name = "Torn Rags";
		pictureItem = "eXpoch_Rag23_Item";
		returnedItems[] =
		{
			{3, "eXpoch_Rag04_Item"},
			{4, "eXpoch_Rag23_Item"}
		};
		components[] = 
		{
			{1, "U_C_Man_casual_1_F"}
		};
		category = "Medical";
	};
	class TornRags_U_B_CombatUniform_mcam: Exile_AbstractCraftingRecipe
	{
		name = "Torn Rags";
		pictureItem = "eXpoch_Rag03_Item";
		returnedItems[] =
		{
			{6, "eXpoch_Rag03_Item"},
			{2, "eXpoch_Rag21_Item"}
		};
		components[] = 
		{
			{1, "U_B_CombatUniform_mcam"}
		};
		category = "Medical";
	};
	class TornRags_U_B_CombatUniform_mcam_tshirt: Exile_AbstractCraftingRecipe
	{
		name = "Torn Rags";
		pictureItem = "eXpoch_Rag03_Item";
		returnedItems[] =
		{
			{2, "eXpoch_Rag22_Item"},
			{4, "eXpoch_Rag03_Item"}
		};
		components[] = 
		{
			{1, "U_B_CombatUniform_mcam_tshirt"}
		};
		category = "Medical";
	};
	class TornRags_U_I_G_resistanceLeader_F: Exile_AbstractCraftingRecipe
	{
		name = "Torn Rags";
		pictureItem = "eXpoch_Rag02_Item";
		returnedItems[] =
		{
			{4, "eXpoch_Rag02_Item"},
			{2, "eXpoch_Rag22_Item"},
			{1, "eXpoch_Rag19_Item"}
		};
		components[] = 
		{
			{1, "U_I_G_resistanceLeader_F"}
		};
		category = "Medical";
	};
	class TornRags_U_B_T_Soldier_F: Exile_AbstractCraftingRecipe
	{
		name = "Torn Rags";
		pictureItem = "eXpoch_Rag46_Item";
		returnedItems[] =
		{
			{2, "eXpoch_Rag40_Item"},
			{6, "eXpoch_Rag46_Item"}
		};
		components[] = 
		{
			{1, "U_B_T_Soldier_F"}
		};
		category = "Medical";
	};
	class TornRags_U_B_T_Soldier_AR_F: Exile_AbstractCraftingRecipe
	{
		name = "Torn Rags";
		pictureItem = "eXpoch_Rag46_Item";
		returnedItems[] =
		{
			{4, "eXpoch_Rag46_Item"},
			{2, "eXpoch_Rag22_Item"},
			{1, "eXpoch_Rag40_Item"}
		};
		components[] = 
		{
			{1, "U_B_T_Soldier_AR_F"}
		};
		category = "Medical";
	};
	class TornRags_U_I_CombatUniform: Exile_AbstractCraftingRecipe
	{
		name = "Torn Rags";
		pictureItem = "eXpoch_Rag17_Item";
		returnedItems[] =
		{
			{2, "eXpoch_Rag22_Item"},
			{6, "eXpoch_Rag17_Item"}
		};
		components[] = 
		{
			{1, "U_I_CombatUniform"}
		};
		category = "Medical";
	};
	class TornRags_U_I_OfficerUniform: Exile_AbstractCraftingRecipe
	{
		name = "Torn Rags";
		pictureItem = "eXpoch_Rag17_Item";
		returnedItems[] =
		{
			{8, "eXpoch_Rag17_Item"}
		};
		components[] = 
		{
			{1, "U_I_OfficerUniform"}
		};
		category = "Medical";
	};
	class TornRags_U_I_CombatUniform_shortsleeve: Exile_AbstractCraftingRecipe
	{
		name = "Torn Rags";
		pictureItem = "eXpoch_Rag17_Item";
		returnedItems[] =
		{
			{2, "eXpoch_Rag22_Item"},
			{6, "eXpoch_Rag17_Item"}
		};
		components[] = 
		{
			{1, "U_I_CombatUniform_shortsleeve"}
		};
		category = "Medical";
	};
	class TornRags_U_C_Poloshirt_blue: Exile_AbstractCraftingRecipe
	{
		name = "Torn Rags";
		pictureItem = "eXpoch_Rag04_Item";
		returnedItems[] =
		{
			{3, "eXpoch_Rag04_Item"},
			{2, "eXpoch_Rag21_Item"}
		};
		components[] = 
		{
			{1, "U_C_Poloshirt_blue"}
		};
		category = "Medical";
	};
	class TornRags_U_C_Poloshirt_burgundy: Exile_AbstractCraftingRecipe
	{
		name = "Torn Rags";
		pictureItem = "eXpoch_Rag18_Item";
		returnedItems[] =
		{
			{3, "eXpoch_Rag18_Item"},
			{2, "eXpoch_Rag04_Item"}
		};
		components[] = 
		{
			{1, "U_C_Poloshirt_burgundy"}
		};
		category = "Medical";
	};
	class TornRags_U_C_Poloshirt_redwhite: Exile_AbstractCraftingRecipe
	{
		name = "Torn Rags";
		pictureItem = "eXpoch_Rag39_Item";
		returnedItems[] =
		{
			{3, "eXpoch_Rag39_Item"},
			{2, "eXpoch_Rag44_Item"}
		};
		components[] = 
		{
			{1, "U_C_Poloshirt_redwhite"}
		};
		category = "Medical";
	};
	class TornRags_U_C_Poloshirt_salmon: Exile_AbstractCraftingRecipe
	{
		name = "Torn Rags";
		pictureItem = "eXpoch_Rag38_Item";
		returnedItems[] =
		{
			{3, "eXpoch_Rag38_Item"},
			{2, "eXpoch_Rag40_Item"}
		};
		components[] = 
		{
			{1, "U_C_Poloshirt_salmon"}
		};
		category = "Medical";
	};
	class TornRags_U_C_Poloshirt_stripped: Exile_AbstractCraftingRecipe
	{
		name = "Torn Rags";
		pictureItem = "eXpoch_Rag44_Item";
		returnedItems[] =
		{
			{1, "eXpoch_Rag04_Item"},
			{1, "eXpoch_Rag22_Item"},
			{2, "eXpoch_Rag44_Item"}
		};
		components[] = 
		{
			{1, "U_C_Poloshirt_stripped"}
		};
		category = "Medical";
	};
	class TornRags_U_C_Poloshirt_tricolour: Exile_AbstractCraftingRecipe
	{
		name = "Torn Rags";
		pictureItem = "eXpoch_Rag04_Item";
		returnedItems[] =
		{
			{2, "eXpoch_Rag04_Item"},
			{2, "eXpoch_Rag03_Item"}
		};
		components[] = 
		{
			{1, "U_C_Poloshirt_tricolour"}
		};
		category = "Medical";
	};
	class TornRags_U_Competitor: Exile_AbstractCraftingRecipe
	{
		name = "Torn Rags";
		pictureItem = "eXpoch_Rag01_Item";
		returnedItems[] =
		{
			{1, "eXpoch_Rag23_Item"},
			{1, "eXpoch_Rag02_Item"},
			{4, "eXpoch_Rag01_Item"}
		};
		components[] = 
		{
			{1, "U_Competitor"}
		};
		category = "Medical";
	};
	class TornRags_U_B_CTRG_1: Exile_AbstractCraftingRecipe
	{
		name = "Torn Rags";
		pictureItem = "eXpoch_Rag12_Item";
		returnedItems[] =
		{
			{6, "eXpoch_Rag12_Item"},
			{2, "eXpoch_Rag35_Item"}
		};
		components[] = 
		{
			{1, "U_B_CTRG_1"}
		};
		category = "Medical";
	};
	class TornRags_U_B_CTRG_3: Exile_AbstractCraftingRecipe
	{
		name = "Torn Rags";
		pictureItem = "eXpoch_Rag12_Item";
		returnedItems[] =
		{
			{6, "eXpoch_Rag12_Item"},
			{2, "eXpoch_Rag35_Item"}
		};
		components[] = 
		{
			{1, "U_B_CTRG_3"}
		};
		category = "Medical";
	};
	class TornRags_U_B_CTRG_2: Exile_AbstractCraftingRecipe
	{
		name = "Torn Rags";
		pictureItem = "eXpoch_Rag12_Item";
		returnedItems[] =
		{
			{4, "eXpoch_Rag12_Item"},
			{2, "eXpoch_Rag22_Item"}
		};
		components[] = 
		{
			{1, "U_B_CTRG_2"}
		};
		category = "Medical";
	};
	class TornRags_U_B_CTRG_Soldier_F: Exile_AbstractCraftingRecipe
	{
		name = "Torn Rags";
		pictureItem = "eXpoch_Rag12_Item";
		returnedItems[] =
		{
			{6, "eXpoch_Rag12_Item"},
			{2, "eXpoch_Rag22_Item"}
		};
		components[] = 
		{
			{1, "U_B_CTRG_Soldier_F"}
		};
		category = "Medical";
	};
	class TornRags_U_B_CTRG_Soldier_3_F: Exile_AbstractCraftingRecipe
	{
		name = "Torn Rags";
		pictureItem = "eXpoch_Rag12_Item";
		returnedItems[] =
		{
			{6, "eXpoch_Rag12_Item"},
			{2, "eXpoch_Rag22_Item"}
		};
		components[] = 
		{
			{1, "U_B_CTRG_Soldier_3_F"}
		};
		category = "Medical";
	};
	class TornRags_U_B_CTRG_Soldier_2_F: Exile_AbstractCraftingRecipe
	{
		name = "Torn Rags";
		pictureItem = "eXpoch_Rag12_Item";
		returnedItems[] =
		{
			{4, "eXpoch_Rag12_Item"},
			{2, "eXpoch_Rag22_Item"}
		};
		components[] = 
		{
			{1, "U_B_CTRG_Soldier_2_F"}
		};
		category = "Medical";
	};
	class TornRags_U_B_CTRG_Soldier_urb_1_F: Exile_AbstractCraftingRecipe
	{
		name = "Torn Rags";
		pictureItem = "eXpoch_Rag22_Item";
		returnedItems[] =
		{
			{6, "eXpoch_Rag22_Item"},
			{2, "eXpoch_Rag44_Item"}
		};
		components[] = 
		{
			{1, "U_B_CTRG_Soldier_urb_1_F"}
		};
		category = "Medical";
	};
	class TornRags_U_B_CTRG_Soldier_urb_3_F: Exile_AbstractCraftingRecipe
	{
		name = "Torn Rags";
		pictureItem = "eXpoch_Rag22_Item";
		returnedItems[] =
		{
			{6, "eXpoch_Rag22_Item"},
			{2, "eXpoch_Rag44_Item"}
		};
		components[] = 
		{
			{1, "U_B_CTRG_Soldier_urb_3_F"}
		};
		category = "Medical";
	};
	class TornRags_U_B_CTRG_Soldier_urb_2_F: Exile_AbstractCraftingRecipe
	{
		name = "Torn Rags";
		pictureItem = "eXpoch_Rag22_Item";
		returnedItems[] =
		{
			{6, "eXpoch_Rag22_Item"}
		};
		components[] = 
		{
			{1, "U_B_CTRG_Soldier_urb_2_F"}
		};
		category = "Medical";
	};
	class TornRags_U_C_Driver_1_black: Exile_AbstractCraftingRecipe
	{
		name = "Torn Rags";
		pictureItem = "eXpoch_Rag44_Item";
		returnedItems[] =
		{
			{3, "eXpoch_Rag02_Item"},
			{4, "eXpoch_Rag44_Item"}
		};
		components[] = 
		{
			{1, "U_C_Driver_1_black"}
		};
		category = "Medical";
	};
	class TornRags_U_C_Driver_1_blue: Exile_AbstractCraftingRecipe
	{
		name = "Torn Rags";
		pictureItem = "eXpoch_Rag44_Item";
		returnedItems[] =
		{
			{3, "eXpoch_Rag04_Item"},
			{4, "eXpoch_Rag44_Item"}
		};
		components[] = 
		{
			{1, "U_C_Driver_1_blue"}
		};
		category = "Medical";
	};
	class TornRags_U_C_Driver_2: Exile_AbstractCraftingRecipe
	{
		name = "Torn Rags";
		pictureItem = "eXpoch_Rag04_Item";
		returnedItems[] =
		{
			{8, "eXpoch_Rag04_Item"}
		};
		components[] = 
		{
			{1, "U_C_Driver_2"}
		};
		category = "Medical";
	};
	class TornRags_U_C_Driver_1: Exile_AbstractCraftingRecipe
	{
		name = "Torn Rags";
		pictureItem = "eXpoch_Rag44_Item";
		returnedItems[] =
		{
			{4, "eXpoch_Rag22_Item"},
			{3, "eXpoch_Rag44_Item"}
		};
		components[] = 
		{
			{1, "U_C_Driver_1"}
		};
		category = "Medical";
	};
	class TornRags_U_C_Driver_1_green: Exile_AbstractCraftingRecipe
	{
		name = "Torn Rags";
		pictureItem = "eXpoch_Rag44_Item";
		returnedItems[] =
		{
			{3, "eXpoch_Rag22_Item"},
			{4, "eXpoch_Rag44_Item"}
		};
		components[] = 
		{
			{1, "U_C_Driver_1_green"}
		};
		category = "Medical";
	};
	class TornRags_U_C_Driver_1_orange: Exile_AbstractCraftingRecipe
	{
		name = "Torn Rags";
		pictureItem = "eXpoch_Rag44_Item";
		returnedItems[] =
		{
			{3, "eXpoch_Rag36_Item"},
			{4, "eXpoch_Rag44_Item"}
		};
		components[] = 
		{
			{1, "U_C_Driver_1_orange"}
		};
		category = "Medical";
	};
	class TornRags_U_C_Driver_1_red: Exile_AbstractCraftingRecipe
	{
		name = "Torn Rags";
		pictureItem = "eXpoch_Rag44_Item";
		returnedItems[] =
		{
			{3, "eXpoch_Rag39_Item"},
			{4, "eXpoch_Rag44_Item"}
		};
		components[] = 
		{
			{1, "U_C_Driver_1_red"}
		};
		category = "Medical";
	};
	class TornRags_U_C_Driver_3: Exile_AbstractCraftingRecipe
	{
		name = "Torn Rags";
		pictureItem = "eXpoch_Rag02_Item";
		returnedItems[] =
		{
			{8, "eXpoch_Rag02_Item"}
		};
		components[] = 
		{
			{1, "U_C_Driver_3"}
		};
		category = "Medical";
	};
	class TornRags_U_C_Driver_4: Exile_AbstractCraftingRecipe
	{
		name = "Torn Rags";
		pictureItem = "eXpoch_Rag02_Item";
		returnedItems[] =
		{
			{6, "eXpoch_Rag02_Item"},
			{1, "eXpoch_Rag36_Item"}
		};
		components[] = 
		{
			{1, "U_C_Driver_4"}
		};
		category = "Medical";
	};
	class TornRags_U_C_Driver_1_white: Exile_AbstractCraftingRecipe
	{
		name = "Torn Rags";
		pictureItem = "eXpoch_Rag44_Item";
		returnedItems[] =
		{
			{2, "eXpoch_Rag02_Item"},
			{5, "eXpoch_Rag44_Item"}
		};
		components[] = 
		{
			{1, "U_C_Driver_1_white"}
		};
		category = "Medical";
	};
	class TornRags_U_C_Driver_1_yellow: Exile_AbstractCraftingRecipe
	{
		name = "Torn Rags";
		pictureItem = "eXpoch_Rag44_Item";
		returnedItems[] =
		{
			{3, "eXpoch_Rag23_Item"},
			{4, "eXpoch_Rag44_Item"}
		};
		components[] = 
		{
			{1, "U_C_Driver_1_yellow"}
		};
		category = "Medical";
	};
	class TornRags_U_O_T_Soldier_F: Exile_AbstractCraftingRecipe
	{
		name = "Torn Rags";
		pictureItem = "eXpoch_Rag34_Item";
		returnedItems[] =
		{
			{7, "eXpoch_Rag34_Item"}
		};
		components[] = 
		{
			{1, "U_O_T_Soldier_F"}
		};
		category = "Medical";
	};
	class TornRags_U_O_CombatUniform_ocamo: Exile_AbstractCraftingRecipe
	{
		name = "Torn Rags";
		pictureItem = "eXpoch_Rag34_Item";
		returnedItems[] =
		{
			{7, "eXpoch_Rag34_Item"}
		};
		components[] = 
		{
			{1, "U_O_CombatUniform_ocamo"}
		};
		category = "Medical";
	};
	class TornRags_U_O_CombatUniform_oucamo: Exile_AbstractCraftingRecipe
	{
		name = "Torn Rags";
		pictureItem = "eXpoch_Rag28_Item";
		returnedItems[] =
		{
			{7, "eXpoch_Rag28_Item"}
		};
		components[] = 
		{
			{1, "U_O_CombatUniform_oucamo"}
		};
		category = "Medical";
	};
	class TornRags_U_I_FullGhillie_ard: Exile_AbstractCraftingRecipe
	{
		name = "Torn Rags";
		pictureItem = "eXpoch_Rag22_Item";
		returnedItems[] =
		{
			{6, "eXpoch_Rag22_Item"}
		};
		components[] = 
		{
			{1, "U_I_FullGhillie_ard"}
		};
		category = "Medical";
	};
	class TornRags_U_O_FullGhillie_ard: Exile_AbstractCraftingRecipe
	{
		name = "Torn Rags";
		pictureItem = "eXpoch_Rag08_Item";
		returnedItems[] =
		{
			{6, "eXpoch_Rag08_Item"}
		};
		components[] = 
		{
			{1, "U_O_FullGhillie_ard"}
		};
		category = "Medical";
	};
	class TornRags_U_B_FullGhillie_ard: Exile_AbstractCraftingRecipe
	{
		name = "Torn Rags";
		pictureItem = "eXpoch_Rag45_Item";
		returnedItems[] =
		{
			{6, "eXpoch_Rag45_Item"}
		};
		components[] = 
		{
			{1, "U_B_FullGhillie_ard"}
		};
		category = "Medical";
	};
	class TornRags_U_O_T_FullGhillie_tna_F: Exile_AbstractCraftingRecipe
	{
		name = "Torn Rags";
		pictureItem = "eXpoch_Rag34_Item";
		returnedItems[] =
		{
			{6, "eXpoch_Rag34_Item"}
		};
		components[] = 
		{
			{1, "U_O_T_FullGhillie_tna_F"}
		};
		category = "Medical";
	};
	class TornRags_U_B_T_FullGhillie_tna_F: Exile_AbstractCraftingRecipe
	{
		name = "Torn Rags";
		pictureItem = "eXpoch_Rag12_Item";
		returnedItems[] =
		{
			{6, "eXpoch_Rag12_Item"}
		};
		components[] = 
		{
			{1, "U_B_T_FullGhillie_tna_F"}
		};
		category = "Medical";
	};
	class TornRags_U_I_FullGhillie_lsh: Exile_AbstractCraftingRecipe
	{
		name = "Torn Rags";
		pictureItem = "eXpoch_Rag22_Item";
		returnedItems[] =
		{
			{6, "eXpoch_Rag22_Item"}
		};
		components[] = 
		{
			{1, "U_I_FullGhillie_lsh"}
		};
		category = "Medical";
	};
	class TornRags_U_O_FullGhillie_lsh: Exile_AbstractCraftingRecipe
	{
		name = "Torn Rags";
		pictureItem = "eXpoch_Rag13_Item";
		returnedItems[] =
		{
			{6, "eXpoch_Rag13_Item"}
		};
		components[] = 
		{
			{1, "U_O_FullGhillie_lsh"}
		};
		category = "Medical";
	};
	class TornRags_U_B_FullGhillie_lsh: Exile_AbstractCraftingRecipe
	{
		name = "Torn Rags";
		pictureItem = "eXpoch_Rag24_Item";
		returnedItems[] =
		{
			{6, "eXpoch_Rag24_Item"}
		};
		components[] = 
		{
			{1, "U_B_FullGhillie_lsh"}
		};
		category = "Medical";
	};
	class TornRags_U_I_FullGhillie_sard: Exile_AbstractCraftingRecipe
	{
		name = "Torn Rags";
		pictureItem = "eXpoch_Rag22_Item";
		returnedItems[] =
		{
			{6, "eXpoch_Rag22_Item"}
		};
		components[] = 
		{
			{1, "U_I_FullGhillie_sard"}
		};
		category = "Medical";
	};
	class TornRags_U_O_FullGhillie_sard: Exile_AbstractCraftingRecipe
	{
		name = "Torn Rags";
		pictureItem = "eXpoch_Rag13_Item";
		returnedItems[] =
		{
			{6, "eXpoch_Rag13_Item"}
		};
		components[] = 
		{
			{1, "U_O_FullGhillie_sard"}
		};
		category = "Medical";
	};
	class TornRags_U_B_FullGhillie_sard: Exile_AbstractCraftingRecipe
	{
		name = "Torn Rags";
		pictureItem = "eXpoch_Rag24_Item";
		returnedItems[] =
		{
			{6, "eXpoch_Rag24_Item"}
		};
		components[] = 
		{
			{1, "U_B_FullGhillie_sard"}
		};
		category = "Medical";
	};
	class TornRags_U_B_GEN_Commander_F: Exile_AbstractCraftingRecipe
	{
		name = "Torn Rags";
		pictureItem = "eXpoch_Rag04_Item";
		returnedItems[] =
		{
			{8, "eXpoch_Rag04_Item"}
		};
		components[] = 
		{
			{1, "U_B_GEN_Commander_F"}
		};
		category = "Medical";
	};
	class TornRags_U_B_GEN_Soldier_F: Exile_AbstractCraftingRecipe
	{
		name = "Torn Rags";
		pictureItem = "eXpoch_Rag04_Item";
		returnedItems[] =
		{
			{6, "eXpoch_Rag04_Item"}
		};
		components[] = 
		{
			{1, "U_B_GEN_Soldier_F"}
		};
		category = "Medical";
	};
	class TornRags_U_O_T_Sniper_F: Exile_AbstractCraftingRecipe
	{
		name = "Torn Rags";
		pictureItem = "eXpoch_Rag34_Item";
		returnedItems[] =
		{
			{6, "eXpoch_Rag34_Item"}
		};
		components[] = 
		{
			{1, "U_O_T_Sniper_F"}
		};
		category = "Medical";
	};
	class TornRags_U_B_T_Sniper_F: Exile_AbstractCraftingRecipe
	{
		name = "Torn Rags";
		pictureItem = "eXpoch_Rag22_Item";
		returnedItems[] =
		{
			{4, "eXpoch_Rag22_Item"},
			{2, "eXpoch_Rag20_Item"}
		};
		components[] = 
		{
			{1, "U_B_T_Sniper_F"}
		};
		category = "Medical";
	};
	class TornRags_U_I_GhillieSuit: Exile_AbstractCraftingRecipe
	{
		name = "Torn Rags";
		pictureItem = "eXpoch_Rag17_Item";
		returnedItems[] =
		{
			{2, "eXpoch_Rag22_Item"},
			{4, "eXpoch_Rag17_Item"}
		};
		components[] = 
		{
			{1, "U_I_GhillieSuit"}
		};
		category = "Medical";
	};
	class TornRags_U_B_GhillieSuit: Exile_AbstractCraftingRecipe
	{
		name = "Torn Rags";
		pictureItem = "eXpoch_Rag46_Item";
		returnedItems[] =
		{
			{4, "eXpoch_Rag46_Item"},
			{2, "eXpoch_Rag21_Item"}
		};
		components[] = 
		{
			{1, "U_B_GhillieSuit"}
		};
		category = "Medical";
	};
	class TornRags_U_BG_Guerilla1_1: Exile_AbstractCraftingRecipe
	{
		name = "Torn Rags";
		pictureItem = "eXpoch_Rag13_Item";
		returnedItems[] =
		{
			{1, "eXpoch_Rag28_Item"},
			{2, "eXpoch_Rag01_Item"},
			{4, "eXpoch_Rag13_Item"}
		};
		components[] = 
		{
			{1, "U_BG_Guerilla1_1"}
		};
		category = "Medical";
	};
	class TornRags_U_BG_Guerilla2_2: Exile_AbstractCraftingRecipe
	{
		name = "Torn Rags";
		pictureItem = "eXpoch_Rag42_Item";
		returnedItems[] =
		{
			{3, "eXpoch_Rag22_Item"},
			{4, "eXpoch_Rag42_Item"}
		};
		components[] = 
		{
			{1, "U_BG_Guerilla2_2"}
		};
		category = "Medical";
	};
	class TornRags_U_BG_Guerilla2_1: Exile_AbstractCraftingRecipe
	{
		name = "Torn Rags";
		pictureItem = "eXpoch_Rag35_Item";
		returnedItems[] =
		{
			{3, "eXpoch_Rag42_Item"},
			{4, "eXpoch_Rag35_Item"}
		};
		components[] = 
		{
			{1, "U_BG_Guerilla2_1"}
		};
		category = "Medical";
	};
	class TornRags_U_BG_Guerilla2_3: Exile_AbstractCraftingRecipe
	{
		name = "Torn Rags";
		pictureItem = "eXpoch_Rag22_Item";
		returnedItems[] =
		{
			{3, "eXpoch_Rag42_Item"},
			{4, "eXpoch_Rag22_Item"}
		};
		components[] = 
		{
			{1, "U_BG_Guerilla2_3"}
		};
		category = "Medical";
	};
	class TornRags_U_BG_Guerilla3_1: Exile_AbstractCraftingRecipe
	{
		name = "Torn Rags";
		pictureItem = "eXpoch_Rag04_Item";
		returnedItems[] =
		{
			{1, "eXpoch_Rag22_Item"},
			{2, "eXpoch_Rag43_Item"},
			{2, "eXpoch_Rag35_Item"},
			{4, "eXpoch_Rag04_Item"}
		};
		components[] = 
		{
			{1, "U_BG_Guerilla3_1"}
		};
		category = "Medical";
	};
	class TornRags_U_BG_leader: Exile_AbstractCraftingRecipe
	{
		name = "Torn Rags";
		pictureItem = "eXpoch_Rag40_Item";
		returnedItems[] =
		{
			{1, "eXpoch_Rag28_Item"},
			{3, "eXpoch_Rag17_Item"},
			{4, "eXpoch_Rag40_Item"}
		};
		components[] = 
		{
			{1, "U_BG_leader"}
		};
		category = "Medical";
	};
	class TornRags_U_I_HeliPilotCoveralls: Exile_AbstractCraftingRecipe
	{
		name = "Torn Rags";
		pictureItem = "eXpoch_Rag23_Item";
		returnedItems[] =
		{
			{8, "eXpoch_Rag23_Item"}
		};
		components[] = 
		{
			{1, "U_I_HeliPilotCoveralls"}
		};
		category = "Medical";
	};
	class TornRags_U_B_HeliPilotCoveralls: Exile_AbstractCraftingRecipe
	{
		name = "Torn Rags";
		pictureItem = "eXpoch_Rag22_Item";
		returnedItems[] =
		{
			{8, "eXpoch_Rag22_Item"}
		};
		components[] = 
		{
			{1, "U_B_HeliPilotCoveralls"}
		};
		category = "Medical";
	};
	class TornRags_U_C_HunterBody_grn: Exile_AbstractCraftingRecipe
	{
		name = "Torn Rags";
		pictureItem = "eXpoch_Rag04_Item";
		returnedItems[] =
		{
			{1, "eXpoch_Rag28_Item"},
			{2, "eXpoch_Rag23_Item"},
			{2, "eXpoch_Rag44_Item"},
			{4, "eXpoch_Rag04_Item"}
		};
		components[] = 
		{
			{1, "U_C_HunterBody_grn"}
		};
		category = "Medical";
	};
	class TornRags_U_OrestesBody: Exile_AbstractCraftingRecipe
	{
		name = "Torn Rags";
		pictureItem = "eXpoch_Rag18_Item";
		returnedItems[] =
		{
			{1, "eXpoch_Rag18_Item"},
			{1, "eXpoch_Rag39_Item"},
			{1, "eXpoch_Rag42_Item"},
			{1, "eXpoch_Rag23_Item"},
			{1, "eXpoch_Rag04_Item"},
			{1, "eXpoch_Rag44_Item"}
		};
		components[] = 
		{
			{1, "U_OrestesBody"}
		};
		category = "Medical";
	};
	class TornRags_U_C_Journalist: Exile_AbstractCraftingRecipe
	{
		name = "Torn Rags";
		pictureItem = "eXpoch_Rag21_Item";
		returnedItems[] =
		{
			{3, "eXpoch_Rag02_Item"},
			{4, "eXpoch_Rag21_Item"}
		};
		components[] = 
		{
			{1, "U_C_Journalist"}
		};
		category = "Medical";
	};
	class TornRags_U_Marshal: Exile_AbstractCraftingRecipe
	{
		name = "Torn Rags";
		pictureItem = "eXpoch_Rag02_Item";
		returnedItems[] =
		{
			{3, "eXpoch_Rag44_Item"},
			{4, "eXpoch_Rag02_Item"}
		};
		components[] = 
		{
			{1, "U_Marshal"}
		};
		category = "Medical";
	};
	class TornRags_U_O_T_Officer_F: Exile_AbstractCraftingRecipe
	{
		name = "Torn Rags";
		pictureItem = "eXpoch_Rag34_Item";
		returnedItems[] =
		{
			{8, "eXpoch_Rag34_Item"}
		};
		components[] = 
		{
			{1, "U_O_T_Officer_F"}
		};
		category = "Medical";
	};
	class TornRags_U_O_OfficerUniform_ocamo: Exile_AbstractCraftingRecipe
	{
		name = "Torn Rags";
		pictureItem = "eXpoch_Rag34_Item";
		returnedItems[] =
		{
			{8, "eXpoch_Rag34_Item"}
		};
		components[] = 
		{
			{1, "U_O_OfficerUniform_ocamo"}
		};
		category = "Medical";
	};
	class TornRags_U_I_C_Soldier_Para_2_F: Exile_AbstractCraftingRecipe
	{
		name = "Torn Rags";
		pictureItem = "eXpoch_Rag22_Item";
		returnedItems[] =
		{
			{4, "eXpoch_Rag22_Item"},
			{3, "eXpoch_Rag03_Item"},
			{1, "eXpoch_Rag01_Item"}
		};
		components[] = 
		{
			{1, "U_I_C_Soldier_Para_2_F"}
		};
		category = "Medical";
	};
	class TornRags_U_I_C_Soldier_Para_3_F: Exile_AbstractCraftingRecipe
	{
		name = "Torn Rags";
		pictureItem = "eXpoch_Rag03_Item";
		returnedItems[] =
		{
			{3, "eXpoch_Rag22_Item"},
			{4, "eXpoch_Rag03_Item"}
		};
		components[] = 
		{
			{1, "U_I_C_Soldier_Para_3_F"}
		};
		category = "Medical";
	};
	class TornRags_U_I_C_Soldier_Para_5_F: Exile_AbstractCraftingRecipe
	{
		name = "Torn Rags";
		pictureItem = "eXpoch_Rag01_Item";
		returnedItems[] =
		{
			{3, "eXpoch_Rag01_Item"},
			{2, "eXpoch_Rag22_Item"}
		};
		components[] = 
		{
			{1, "U_I_C_Soldier_Para_5_F"}
		};
		category = "Medical";
	};
	class TornRags_U_I_C_Soldier_Para_4_F: Exile_AbstractCraftingRecipe
	{
		name = "Torn Rags";
		pictureItem = "eXpoch_Rag01_Item";
		returnedItems[] =
		{
			{2, "eXpoch_Rag03_Item"},
			{4, "eXpoch_Rag01_Item"}
		};
		components[] = 
		{
			{1, "U_I_C_Soldier_Para_4_F"}
		};
		category = "Medical";
	};
	class TornRags_U_I_C_Soldier_Para_1_F: Exile_AbstractCraftingRecipe
	{
		name = "Torn Rags";
		pictureItem = "eXpoch_Rag03_Item";
		returnedItems[] =
		{
			{4, "eXpoch_Rag03_Item"},
			{3, "eXpoch_Rag29_Item"},
			{1, "eXpoch_Rag22_Item"}
		};
		components[] = 
		{
			{1, "U_I_C_Soldier_Para_1_F"}
		};
		category = "Medical";
	};
	class TornRags_U_I_pilotCoveralls: Exile_AbstractCraftingRecipe
	{
		name = "Torn Rags";
		pictureItem = "eXpoch_Rag22_Item";
		returnedItems[] =
		{
			{8, "eXpoch_Rag22_Item"}
		};
		components[] = 
		{
			{1, "U_I_pilotCoveralls"}
		};
		category = "Medical";
	};
	class TornRags_U_O_PilotCoveralls: Exile_AbstractCraftingRecipe
	{
		name = "Torn Rags";
		pictureItem = "eXpoch_Rag10_Item";
		returnedItems[] =
		{
			{8, "eXpoch_Rag10_Item"}
		};
		components[] = 
		{
			{1, "U_O_PilotCoveralls"}
		};
		category = "Medical";
	};
	class TornRags_U_B_PilotCoveralls: Exile_AbstractCraftingRecipe
	{
		name = "Torn Rags";
		pictureItem = "eXpoch_Rag42_Item";
		returnedItems[] =
		{
			{8, "eXpoch_Rag42_Item"}
		};
		components[] = 
		{
			{1, "U_B_PilotCoveralls"}
		};
		category = "Medical";
	};
	class TornRags_U_Rangemaster: Exile_AbstractCraftingRecipe
	{
		name = "Torn Rags";
		pictureItem = "eXpoch_Rag23_Item";
		returnedItems[] =
		{
			{3, "eXpoch_Rag04_Item"},
			{4, "eXpoch_Rag23_Item"}
		};
		components[] = 
		{
			{1, "U_Rangemaster"}
		};
		category = "Medical";
	};
	class TornRags_U_O_SpecopsUniform_ocamo: Exile_AbstractCraftingRecipe
	{
		name = "Torn Rags";
		pictureItem = "eXpoch_Rag34_Item";
		returnedItems[] =
		{
			{8, "eXpoch_Rag34_Item"}
		};
		components[] = 
		{
			{1, "U_O_SpecopsUniform_ocamo"}
		};
		category = "Medical";
	};
	class TornRags_U_B_CombatUniform_mcam_vest: Exile_AbstractCraftingRecipe
	{
		name = "Torn Rags";
		pictureItem = "eXpoch_Rag46_Item";
		returnedItems[] =
		{
			{6, "eXpoch_Rag46_Item"},
			{2, "eXpoch_Rag21_Item"}
		};
		components[] = 
		{
			{1, "U_B_CombatUniform_mcam_vest"}
		};
		category = "Medical";
	};
	class TornRags_U_B_T_Soldier_SL_F: Exile_AbstractCraftingRecipe
	{
		name = "Torn Rags";
		pictureItem = "eXpoch_Rag22_Item";
		returnedItems[] =
		{
			{6, "eXpoch_Rag22_Item"},
			{2, "eXpoch_Rag21_Item"}
		};
		components[] = 
		{
			{1, "U_B_T_Soldier_SL_F"}
		};
		category = "Medical";
	};
	class TornRags_U_C_Scientist: Exile_AbstractCraftingRecipe
	{
		name = "Torn Rags";
		pictureItem = "eXpoch_Rag44_Item";
		returnedItems[] =
		{
			{8, "eXpoch_Rag44_Item"}
		};
		components[] = 
		{
			{1, "U_C_Scientist"}
		};
		category = "Medical";
	};
	class TornRags_U_O_V_Soldier_Viper_F: Exile_AbstractCraftingRecipe
	{
		name = "Torn Rags";
		pictureItem = "eXpoch_Rag31_Item";
		returnedItems[] =
		{
			{8, "eXpoch_Rag31_Item"}
		};
		components[] = 
		{
			{1, "U_O_V_Soldier_Viper_F"}
		};
		category = "Medical";
	};
	class TornRags_U_O_V_Soldier_Viper_hex_F: Exile_AbstractCraftingRecipe
	{
		name = "Torn Rags";
		pictureItem = "eXpoch_Rag32_Item";
		returnedItems[] =
		{
			{8, "eXpoch_Rag32_Item"}
		};
		components[] = 
		{
			{1, "U_O_V_Soldier_Viper_hex_F"}
		};
		category = "Medical";
	};
	class TornRags_U_C_man_sport_1_F: Exile_AbstractCraftingRecipe
	{
		name = "Torn Rags";
		pictureItem = "eXpoch_Rag04_Item";
		returnedItems[] =
		{
			{2, "eXpoch_Rag04_Item"},
			{1, "eXpoch_Rag22_Item"},
			{2, "eXpoch_Rag02_Item"}
		};
		components[] = 
		{
			{1, "U_C_man_sport_1_F"}
		};
		category = "Medical";
	};
	class TornRags_U_C_man_sport_3_F: Exile_AbstractCraftingRecipe
	{
		name = "Torn Rags";
		pictureItem = "eXpoch_Rag04_Item";
		returnedItems[] =
		{
			{5, "eXpoch_Rag04_Item"}
		};
		components[] = 
		{
			{1, "U_C_man_sport_3_F"}
		};
		category = "Medical";
	};
	class TornRags_U_C_man_sport_2_F: Exile_AbstractCraftingRecipe
	{
		name = "Torn Rags";
		pictureItem = "eXpoch_Rag02_Item";
		returnedItems[] =
		{
			{3, "eXpoch_Rag02_Item"},
			{2, "eXpoch_Rag36_Item"}
		};
		components[] = 
		{
			{1, "U_C_man_sport_2_F"}
		};
		category = "Medical";
	};
	class TornRags_U_C_Man_casual_6_F: Exile_AbstractCraftingRecipe
	{
		name = "Torn Rags";
		pictureItem = "eXpoch_Rag39_Item";
		returnedItems[] =
		{
			{3, "eXpoch_Rag39_Item"},
			{2, "eXpoch_Rag22_Item"}
		};
		components[] = 
		{
			{1, "U_C_Man_casual_6_F"}
		};
		category = "Medical";
	};
	class TornRags_U_C_Man_casual_4_F: Exile_AbstractCraftingRecipe
	{
		name = "Torn Rags";
		pictureItem = "eXpoch_Rag04_Item";
		returnedItems[] =
		{
			{3, "eXpoch_Rag04_Item"},
			{2, "eXpoch_Rag02_Item"}
		};
		components[] = 
		{
			{1, "U_C_Man_casual_4_F"}
		};
		category = "Medical";
	};
	class TornRags_U_C_Man_casual_5_F: Exile_AbstractCraftingRecipe
	{
		name = "Torn Rags";
		pictureItem = "eXpoch_Rag23_Item";
		returnedItems[] =
		{
			{3, "eXpoch_Rag23_Item"},
			{2, "eXpoch_Rag04_Item"}
		};
		components[] = 
		{
			{1, "U_C_Man_casual_5_F"}
		};
		category = "Medical";
	};
	class TornRags_U_B_survival_uniform: Exile_AbstractCraftingRecipe
	{
		name = "Torn Rags";
		pictureItem = "eXpoch_Rag46_Item";
		returnedItems[] =
		{
			{4, "eXpoch_Rag46_Item"},
			{2, "eXpoch_Rag22_Item"}
		};
		components[] = 
		{
			{1, "U_B_survival_uniform"}
		};
		category = "Medical";
	};
	class TornRags_U_I_C_Soldier_Camo_F: Exile_AbstractCraftingRecipe
	{
		name = "Torn Rags";
		pictureItem = "eXpoch_Rag03_Item";
		returnedItems[] =
		{
			{7, "eXpoch_Rag03_Item"}
		};
		components[] = 
		{
			{1, "U_I_C_Soldier_Camo_F"}
		};
		category = "Medical";
	};
	class TornRags_U_I_Protagonist_VR: Exile_AbstractCraftingRecipe
	{
		name = "Torn Rags";
		pictureItem = "eXpoch_Rag02_Item";
		returnedItems[] =
		{
			{7, "eXpoch_Rag02_Item"}
		};
		components[] = 
		{
			{1, "U_I_Protagonist_VR"}
		};
		category = "Medical";
	};
	class TornRags_U_O_Protagonist_VR: Exile_AbstractCraftingRecipe
	{
		name = "Torn Rags";
		pictureItem = "eXpoch_Rag02_Item";
		returnedItems[] =
		{
			{7, "eXpoch_Rag02_Item"}
		};
		components[] = 
		{
			{1, "U_O_Protagonist_VR"}
		};
		category = "Medical";
	};
	class TornRags_U_B_Protagonist_VR: Exile_AbstractCraftingRecipe
	{
		name = "Torn Rags";
		pictureItem = "eXpoch_Rag02_Item";
		returnedItems[] =
		{
			{7, "eXpoch_Rag02_Item"}
		};
		components[] = 
		{
			{1, "U_B_Protagonist_VR"}
		};
		category = "Medical";
	};
	class TornRags_U_I_Wetsuit: Exile_AbstractCraftingRecipe
	{
		name = "Torn Rags";
		pictureItem = "eXpoch_Rag22_Item";
		returnedItems[] =
		{
			{4, "eXpoch_Rag22_Item"}
		};
		components[] = 
		{
			{1, "U_I_Wetsuit"}
		};
		category = "Medical";
	};
	class TornRags_U_O_Wetsuit: Exile_AbstractCraftingRecipe
	{
		name = "Torn Rags";
		pictureItem = "eXpoch_Rag33_Item";
		returnedItems[] =
		{
			{4, "eXpoch_Rag33_Item"}
		};
		components[] = 
		{
			{1, "U_O_Wetsuit"}
		};
		category = "Medical";
	};
	class TornRags_U_B_Wetsuit: Exile_AbstractCraftingRecipe
	{
		name = "Torn Rags";
		pictureItem = "eXpoch_Rag02_Item";
		returnedItems[] =
		{
			{4, "eXpoch_Rag02_Item"}
		};
		components[] = 
		{
			{1, "U_B_Wetsuit"}
		};
		category = "Medical";
	};
	class TornRags_U_C_WorkerCoveralls: Exile_AbstractCraftingRecipe
	{
		name = "Torn Rags";
		pictureItem = "eXpoch_Rag43_Item";
		returnedItems[] =
		{
			{8, "eXpoch_Rag43_Item"}
		};
		components[] = 
		{
			{1, "U_C_WorkerCoveralls"}
		};
		category = "Medical";
	};
	class TornRags_U_C_Poor_1: Exile_AbstractCraftingRecipe
	{
		name = "Torn Rags";
		pictureItem = "eXpoch_Rag04_Item";
		returnedItems[] =
		{
			{7, "eXpoch_Rag04_Item"}
		};
		components[] = 
		{
			{1, "U_C_Poor_1"}
		};
		category = "Medical";
	};
	class TornRags_U_I_G_Story_Protagonist_F: Exile_AbstractCraftingRecipe
	{
		name = "Torn Rags";
		pictureItem = "eXpoch_Rag46_Item";
		returnedItems[] =
		{
			{4, "eXpoch_Rag46_Item"},
			{3, "eXpoch_Rag02_Item"}
		};
		components[] = 
		{
			{1, "U_I_G_Story_Protagonist_F"}
		};
		category = "Medical";
	};
	class TornRags_U_B_CombatUniform_mcam_worn: Exile_AbstractCraftingRecipe
	{
		name = "Torn Rags";
		pictureItem = "eXpoch_Rag46_Item";
		returnedItems[] =
		{
			{6, "eXpoch_Rag46_Item"},
			{2, "eXpoch_Rag21_Item"}
		};
		components[] = 
		{
			{1, "U_B_CombatUniform_mcam_worn"}
		};
		category = "Medical";
	};
	class TornRags_Exile_Uniform_BambiOverall: Exile_AbstractCraftingRecipe
	{
		name = "Torn Rags";
		pictureItem = "eXpoch_Rag36_Item";
		returnedItems[] =
		{
			{8, "eXpoch_Rag36_Item"}
		};
		components[] = 
		{
			{1, "Exile_Uniform_BambiOverall"}
		};
		category = "Medical";
	};
	class TornRags_Exile_Uniform_ExileCustoms: Exile_AbstractCraftingRecipe
	{
		name = "Torn Rags";
		pictureItem = "eXpoch_Rag02_Item";
		returnedItems[] =
		{
			{8, "eXpoch_Rag02_Item"}
		};
		components[] = 
		{
			{1, "Exile_Uniform_ExileCustoms"}
		};
		category = "Medical";
	};
	class TornRags_Exile_Uniform_Woodland: Exile_AbstractCraftingRecipe
	{
		name = "Torn Rags";
		pictureItem = "eXpoch_Rag03_Item";
		returnedItems[] =
		{
			{6, "eXpoch_Rag03_Item"},
			{2, "eXpoch_Rag12_Item"}
		};
		components[] = 
		{
			{1, "Exile_Uniform_Woodland"}
		};
		category = "Medical";
	};
	class TornRags_eXpoch_U_male_prisoner: Exile_AbstractCraftingRecipe
	{
		name = "Torn Rags";
		pictureItem = "eXpoch_Rag36_Item";
		returnedItems[] =
		{
			{8, "eXpoch_Rag36_Item"}
		};
		components[] = 
		{
			{1, "eXpoch_U_male_prisoner"}
		};
		category = "Medical";
	};
	class TornRags_U_ghillie3_uniform: Exile_AbstractCraftingRecipe
	{
		name = "Torn Rags";
		pictureItem = "eXpoch_Rag08_Item";
		returnedItems[] =
		{
			{8, "eXpoch_Rag08_Item"}
		};
		components[] = 
		{
			{1, "U_ghillie3_uniform"}
		};
		category = "Medical";
	};
	class TornRags_U_ghillie2_uniform: Exile_AbstractCraftingRecipe
	{
		name = "Torn Rags";
		pictureItem = "eXpoch_Rag05_Item";
		returnedItems[] =
		{
			{8, "eXpoch_Rag05_Item"}
		};
		components[] = 
		{
			{1, "U_ghillie2_uniform"}
		};
		category = "Medical";
	};
	class TornRags_U_ghillie1_uniform: Exile_AbstractCraftingRecipe
	{
		name = "Torn Rags";
		pictureItem = "eXpoch_Rag06_Item";
		returnedItems[] =
		{
			{8, "eXpoch_Rag06_Item"}
		};
		components[] = 
		{
			{1, "U_ghillie1_uniform"}
		};
		category = "Medical";
	};
	class TornRags_U_Wetsuit_uniform: Exile_AbstractCraftingRecipe
	{
		name = "Torn Rags";
		pictureItem = "eXpoch_Rag02_Item";
		returnedItems[] =
		{
			{4, "eXpoch_Rag02_Item"}
		};
		components[] = 
		{
			{1, "U_Wetsuit_uniform"}
		};
		category = "Medical";
	};
	class TornRags_U_Wetsuit_Blue: Exile_AbstractCraftingRecipe
	{
		name = "Torn Rags";
		pictureItem = "eXpoch_Rag04_Item";
		returnedItems[] =
		{
			{4, "eXpoch_Rag04_Item"}
		};
		components[] = 
		{
			{1, "U_Wetsuit_Blue"}
		};
		category = "Medical";
	};
	class TornRags_U_Wetsuit_Camo: Exile_AbstractCraftingRecipe
	{
		name = "Torn Rags";
		pictureItem = "eXpoch_Rag16_Item";
		returnedItems[] =
		{
			{4, "eXpoch_Rag16_Item"}
		};
		components[] = 
		{
			{1, "U_Wetsuit_Camo"}
		};
		category = "Medical";
	};
	class TornRags_U_Wetsuit_Purp: Exile_AbstractCraftingRecipe
	{
		name = "Torn Rags";
		pictureItem = "eXpoch_Rag38_Item";
		returnedItems[] =
		{
			{4, "eXpoch_Rag38_Item"}
		};
		components[] = 
		{
			{1, "U_Wetsuit_Purp"}
		};
		category = "Medical";
	};
	class TornRags_U_Wetsuit_White: Exile_AbstractCraftingRecipe
	{
		name = "Torn Rags";
		pictureItem = "eXpoch_Rag44_Item";
		returnedItems[] =
		{
			{4, "eXpoch_Rag44_Item"}
		};
		components[] = 
		{
			{1, "U_Wetsuit_White"}
		};
		category = "Medical";
	};
	class TornRags_eXpoch_U_camo_aloha: Exile_AbstractCraftingRecipe
	{
		name = "Torn Rags";
		pictureItem = "eXpoch_Rag42_Item";
		returnedItems[] =
		{
			{4, "eXpoch_Rag42_Item"},
			{3, "eXpoch_Rag04_Item"}
		};
		components[] = 
		{
			{1, "eXpoch_U_camo_aloha"}
		};
		category = "Medical";
	};
	class TornRags_eXpoch_U_camo_biker: Exile_AbstractCraftingRecipe
	{
		name = "Torn Rags";
		pictureItem = "eXpoch_Rag02_Item";
		returnedItems[] =
		{
			{7, "eXpoch_Rag02_Item"}
		};
		components[] = 
		{
			{1, "eXpoch_U_camo_biker"}
		};
		category = "Medical";
	};
	class TornRags_eXpoch_U_camo_bubblegum: Exile_AbstractCraftingRecipe
	{
		name = "Torn Rags";
		pictureItem = "eXpoch_Rag23_Item";
		returnedItems[] =
		{
			{4, "eXpoch_Rag23_Item"},
			{3, "eXpoch_Rag39_Item"}
		};
		components[] = 
		{
			{1, "eXpoch_U_camo_bubblegum"}
		};
		category = "Medical";
	};
	class TornRags_U_Camo_uniform: Exile_AbstractCraftingRecipe
	{
		name = "Torn Rags";
		pictureItem = "eXpoch_Rag03_Item";
		returnedItems[] =
		{
			{7, "eXpoch_Rag03_Item"}
		};
		components[] = 
		{
			{1, "U_Camo_uniform"}
		};
		category = "Medical";
	};
	class TornRags_U_CamoBlue_uniform: Exile_AbstractCraftingRecipe
	{
		name = "Torn Rags";
		pictureItem = "eXpoch_Rag02_Item";
		returnedItems[] =
		{
			{4, "eXpoch_Rag02_Item"},
			{3, "eXpoch_Rag04_Item"}
		};
		components[] = 
		{
			{1, "U_CamoBlue_uniform"}
		};
		category = "Medical";
	};
	class TornRags_U_CamoBrn_uniform: Exile_AbstractCraftingRecipe
	{
		name = "Torn Rags";
		pictureItem = "eXpoch_Rag46_Item";
		returnedItems[] =
		{
			{4, "eXpoch_Rag46_Item"},
			{3, "eXpoch_Rag36_Item"}
		};
		components[] = 
		{
			{1, "U_CamoBrn_uniform"}
		};
		category = "Medical";
	};
	class TornRags_U_CamoRed_uniform: Exile_AbstractCraftingRecipe
	{
		name = "Torn Rags";
		pictureItem = "eXpoch_Rag18_Item";
		returnedItems[] =
		{
			{4, "eXpoch_Rag18_Item"},
			{3, "eXpoch_Rag39_Item"}
		};
		components[] = 
		{
			{1, "U_CamoRed_uniform"}
		};
		category = "Medical";
	};
	class TornRags_eXpoch_U_camo_lumberjack: Exile_AbstractCraftingRecipe
	{
		name = "Torn Rags";
		pictureItem = "eXpoch_Rag04_Item";
		returnedItems[] =
		{
			{4, "eXpoch_Rag04_Item"},
			{3, "eXpoch_Rag39_Item"}
		};
		components[] = 
		{
			{1, "eXpoch_U_camo_lumberjack"}
		};
		category = "Medical";
	};
	class TornRags_eXpoch_U_camo_outback: Exile_AbstractCraftingRecipe
	{
		name = "Torn Rags";
		pictureItem = "eXpoch_Rag04_Item";
		returnedItems[] =
		{
			{4, "eXpoch_Rag04_Item"},
			{3, "eXpoch_Rag29_Item"}
		};
		components[] = 
		{
			{1, "eXpoch_U_camo_outback"}
		};
		category = "Medical";
	};
	class TornRags_eXpoch_U_camo_pink: Exile_AbstractCraftingRecipe
	{
		name = "Torn Rags";
		pictureItem = "eXpoch_Rag38_Item";
		returnedItems[] =
		{
			{4, "eXpoch_Rag38_Item"},
			{3, "eXpoch_Rag37_Item"}
		};
		components[] = 
		{
			{1, "eXpoch_U_camo_pink"}
		};
		category = "Medical";
	};
	class TornRags_eXpoch_U_camo_pinkpolka: Exile_AbstractCraftingRecipe
	{
		name = "Torn Rags";
		pictureItem = "eXpoch_Rag37_Item";
		returnedItems[] =
		{
			{4, "eXpoch_Rag37_Item"},
			{3, "eXpoch_Rag02_Item"}
		};
		components[] = 
		{
			{1, "eXpoch_U_camo_pinkpolka"}
		};
		category = "Medical";
	};
	class TornRags_eXpoch_U_Prisoner_uniform: Exile_AbstractCraftingRecipe
	{
		name = "Torn Rags";
		pictureItem = "eXpoch_Rag36_Item";
		returnedItems[] =
		{
			{8, "eXpoch_Rag36_Item"}
		};
		components[] = 
		{
			{1, "eXpoch_U_Prisoner_uniform"}
		};
		category = "Medical";
	};