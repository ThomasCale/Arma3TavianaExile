class CfgXM8
{
	class apps
	{
		controlID = 4040;
		title = "eXnet";
	};
	class players
	{
		controlID = 4110;
		title = "eXnet Client Terminal";
	};
	class clan
	{
		controlID = 4060;
		title = "Family";
	};
	class settings
	{
		controlID = 4070;
		title = "Settings";
	};
	class hostParty
	{
		controlID = 4080;
		title = "Host Party";
	};
	class party
	{
		controlID = 4100;
		title = "Party";
	};
	class server
	{
		controlID = 4090;
		title = "Server Rules";
	};
	class healthScanner
	{
		controlID = 4120;
		title = "Health Scanner";
	};
	class territory
	{
		controlID = 4130;
		title = "Territory";
	};
	class slothMachine
	{
		controlID = 4140;
		title = "Sloth Machine";
	};
	class mobileXm8
	{
		controlID = 4200;
		title = "Mobile eXnet";
	};
	class extraApps
	{
		controlID = 5000;
		title = "eXnet Apps";
	};
	class extraApps2
	{
		controlID = 82500;
		title = "eXnet Apps";
	};
};