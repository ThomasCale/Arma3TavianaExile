class CfgWorlds
{
	class CAWorld;
	class Altis: CAWorld
	{
		cutscenes[] = {"ExileIntro"};
	};
	class Stratis: CAWorld
	{
		cutscenes[] = {"ExileIntro"};
	};
	class Tanoa: CAWorld
	{
		cutscenes[] = {"ExileIntro"};
	};
	class VR: CAWorld
	{
		cutscenes[] = {"ExileIntro"};
	};
	initWorld = "VR";
	demoWorld = "VR";
};