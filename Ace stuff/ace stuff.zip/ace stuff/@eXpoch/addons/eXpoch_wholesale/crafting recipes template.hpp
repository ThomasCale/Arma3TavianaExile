class Packxxx: Exile_AbstractCraftingRecipe
{
	name = "Pack 6x of xxx";
	pictureItem = "xxx";
	category = "WholeSale Stock";
	returnedItems[] =
	{
		{1, "xxx"}
	};
	tools[] =
	{
		"Exile_Item_Foolbox"
	};
	components[] = 
	{
		{6, "xxx"}
	};
};
class UnPackxxx: Exile_AbstractCraftingRecipe
{
	name = "UnPack 6x of xxx";
	pictureItem = "xxx";
	category = "WholeSale Stock";
	returnedItems[] =
	{
		{6, "xxx"}
	};
	tools[] =
	{
		"Exile_Item_Foolbox"
	};
	components[] = 
	{
		{1, "xxx"}
	};
};