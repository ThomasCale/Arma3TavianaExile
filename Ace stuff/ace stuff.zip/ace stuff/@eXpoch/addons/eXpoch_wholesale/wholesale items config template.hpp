	class eXpoch_WS_6x_Exile_Item_Wrench : Exile_AbstractItem
	{
		scope = 2;
		displayName = "6x xxx";
		descriptionShort = "eXpoch WholeSale Item for marXet player trading";
		picture = "\exile_assets\texture\item\Exile_Construction_Crate.paa";
		model = "\plp_containers\plp_ct_CartonFlat.p3d";
		mass = 50;
	};