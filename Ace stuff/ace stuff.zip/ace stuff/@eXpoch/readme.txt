/////////////////////////////////////////////////////////
////
////
////    DonkeyPunch eXpoch MoD
////	© 2016 DonkeyPunch Dev Team
////	Created by =RAV=MusTanG
////	aka. DirtySancheZ
////
/////////////////////////////////////////////////////////

Installation:

To make epoch compatible, copy and replace the files inside the @Epoch/addons folder to your @Epoch/addons folder in your game library


Teamspeak: TS3.DONKEYPUNCH.INFO
Discord: https://discord.gg/zVjeBRY

or visit our website at http://DONKEYPUNCH.INFO
This will help us fix any issues faster with a tracker.
You will have to register so we can track and respond to bugs!

