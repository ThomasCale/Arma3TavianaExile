name = "eXpoch Mod";
author = "=RAV=MusTanG";
action = "http://www.DonkeyPunch.INFO";
dir = "@eXpoch";
picture = "mod.paa";